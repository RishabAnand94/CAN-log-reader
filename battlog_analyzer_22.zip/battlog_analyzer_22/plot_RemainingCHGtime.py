# -*- coding: utf-8 -*-
"""
Created on Wed Jun 23 08:19:49 2021

@author: josephma
"""

import sys
if 'mpl' not in sys.modules:
    import matplotlib as mpl 
if 'plt' not in sys.modules:
    import matplotlib.pyplot as plt
if 'pd' not in sys.modules:
    import pandas as pd
# if 'os' not in sys.modules:
#     import os

import os

import scipy.integrate
import numpy as np

rcdict02 = {'ytick.labelsize': 14, 'axes.labelsize': 14}

def plot_remChgTime(
    time_secs,
    can_remChgTime,
    actual_chgComplete,
    can_soc,
    savefig = False, fig_dir = '', fname_prefix = '' ):
    
    time_hrs = [tsec/3600 for tsec in time_secs]

    
    
    df_times = pd.DataFrame()
    df_times["timestamp"]=can_remChgTime.index
    df_times["can_remchgtime"]=can_remChgTime.values
    actual_chgComplete_time = actual_chgComplete[actual_chgComplete.values == "CHARGE_COMPLETE"].index[0]
    actual_remChgTime = (actual_chgComplete_time-can_remChgTime.index).total_seconds()/60
    df_times["actual_remchgtime"] = actual_remChgTime
    df_times["actual_remchgtime"] = df_times["actual_remchgtime"].clip(lower=0)
 

    with mpl.rc_context(fname='RA_BMS.rc'):
        remChgfig, remChgfig_timeax = plt.subplots(num = 'Remaining_CHG_time')
        print("\t plotting CAN remaining charge time")
        remChgfig_timeax.plot(
            time_hrs, 
            df_times["can_remchgtime"], 
            label = "Remaining Charge time (CAN)",
            color="r")
        print("\t plotting actual remaining charge time")
        remChgfig_timeax.plot(
            time_hrs, 
            df_times["actual_remchgtime"], 
            label = "Time till CHARGE COMPLETE",
            color="g")


        
        #plt.autoscale(axis = 'y', tight = None)
        
        remChgfig_timeax.set_xlabel('Time (hours)')
        remChgfig_timeax.set_ylabel('Time (minutes)')
        
    with mpl.rc_context(rcdict02):
        print("\t plotting error in remaining charge time")
        errorax = remChgfig_timeax.twinx()   
        errorax.plot(
            time_hrs, 
            df_times["actual_remchgtime"]-df_times["can_remchgtime"],
            label = "CHG time Est. Error",
            color="b")

        errorax.set_ylabel("Estimation Error (minutes)")
        errorax.grid(None)

    with mpl.rc_context(rcdict02):
        print("\t plotting soc in remaining charge time")
        soc_ax = remChgfig_timeax.twinx()   
        soc_ax.plot(
            time_hrs, 
            can_soc, label = "SoC",
            color="violet")

        soc_ax.set_ylabel("State of Charge (%)")
        soc_ax.yaxis.set_ticks_position('right') # set the position of the second x-axis to bottom
        soc_ax.yaxis.set_label_position('right') # set the position of the second x-axis to bottom
        soc_ax.spines['right'].set_position(('outward', 90))
        soc_ax.grid(None)
        


    with mpl.rc_context(fname='RA_BMS.rc'):
        lines, labels = remChgfig_timeax.get_legend_handles_labels()
        lines2, labels2 = errorax.get_legend_handles_labels()
        lines3, labels3 = soc_ax.get_legend_handles_labels()
        remChgfig_timeax.legend(lines , labels)
        #remChgfig_timeax.legend(lines + lines2, labels + labels2)
        remChgfig_timeax.legend(lines + lines2+lines3, labels + labels2+labels3)
    plt.xlim(min(time_hrs), max(time_hrs))
    remChgfig_timeax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)

    plt.title("Remaining Charge time")
    remChgfig.set_size_inches(16, 12)
    plt.show()

    if savefig:
        remChgfig.savefig(
            os.path.join(fig_dir, fname_prefix + 'Remaining_Charge_time.png'),
            format='png',
            dpi=400,
            bbox_inches='tight') 