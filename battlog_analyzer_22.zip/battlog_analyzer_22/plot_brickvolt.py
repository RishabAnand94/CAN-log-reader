# -*- coding: utf-8 -*-
"""
Created on Mon Feb 15 11:20:54 2021

@author: ranand
"""

import sys
if 'mpl' not in sys.modules:
    import matplotlib as mpl 
if 'plt' not in sys.modules:
    import matplotlib.pyplot as plt
# if 'os' not in sys.modules:
#     import os

import os

rcdict02 = {'ytick.labelsize': 14, 'axes.labelsize': 14}

def plot_brick_voltage(
    time_secs, \
    brickvoltages, \
    balance_count = None, \
    sp_war_overvolt = None, cp_war_overvolt = None, \
    sp_mod_overvolt = None, cp_mod_overvolt = None, \
    sp_sev_overvolt = None, cp_sev_overvolt = None, \
    sp_war_undervolt = None, cp_war_undervolt = None, \
    sp_mod_undervolt = None, cp_mod_undervolt = None, \
    sp_sev_undervolt = None, cp_sev_undervolt = None, \
    sp_voltimbalance = None, cp_voltimbalance = None, \
    savefig = False, fig_dir = '', fname_prefix = ''):
    """
    This function plots brick voltages and voltage imbalance vs. time
    
    Parameters
    ----------
    time_secs : TYPE
        DESCRIPTION.
    brickvoltages : TYPE
        DESCRIPTION.
    balance_count : TYPE
        DESCRIPTION.
    sp_war_overvolt : TYPE, optional
        DESCRIPTION. The default is None.
    cp_war_overvolt : TYPE, optional
        DESCRIPTION. The default is None.
    sp_mod_overvolt : TYPE, optional
        DESCRIPTION. The default is None.
    cp_mod_overvolt : TYPE, optional
        DESCRIPTION. The default is None.
    sp_sev_overvolt : TYPE, optional
        DESCRIPTION. The default is None.
    cp_sev_overvolt : TYPE, optional
        DESCRIPTION. The default is None.
    sp_war_undervolt : TYPE, optional
        DESCRIPTION. The default is None.
    cp_war_undervolt : TYPE, optional
        DESCRIPTION. The default is None.
    sp_mod_undervolt : TYPE, optional
        DESCRIPTION. The default is None.
    cp_mod_undervolt : TYPE, optional
        DESCRIPTION. The default is None.
    sp_sev_undervolt : TYPE, optional
        DESCRIPTION. The default is None.
    cp_sev_undervolt : TYPE, optional
        DESCRIPTION. The default is None.
    sp_voltimbalance : TYPE, optional
        DESCRIPTION. The default is None.
    cp_voltimbalance : TYPE, optional
        DESCRIPTION. The default is None.
    savefig : TYPE, optional
        DESCRIPTION. The default is False.
    fig_dir : TYPE, optional
        DESCRIPTION. The default is ''.
    fname_prefix : TYPE, optional
        DESCRIPTION. The default is ''.

    Returns
    -------
    None.

    """
    
    time_hrs = [tsec/3600 for tsec in time_secs]  
    
    # Compute min and max voltages among all readings
    brickvoltage_min_val = brickvoltages.min(axis=1).min(axis = 0)
    brickvoltage_max_val = brickvoltages.max(axis=1).max(axis = 0)

    # For top of charge balancing, imbalance should be minimum at fully charged state - 
    # plot imbalance vs. terminal voltage, soc
    voltagedelta = brickvoltages.max(axis=1) - brickvoltages.min(axis=1)
    voltagedelta_max_val = voltagedelta.max(axis = 0)

    with mpl.rc_context(fname='RA_BMS.rc'):
        brickvoltfig, brickvoltfig_voltax = plt.subplots(num = 'Voltages_Brick')
        for brick in range(0, len(brickvoltages.columns)):
            brickvoltfig_voltax.plot(
                time_hrs, 
                brickvoltages.iloc[:, brick], 
                label = "Brick " + str(brick+1).zfill(2), 
                linewidth = 0.5)

        # Plot warning, moderate and severe levels on the same plot
        if sp_war_overvolt is not None and brickvoltage_max_val >= sp_war_overvolt:
            brickvoltfig_voltax.hlines(
                y = sp_war_overvolt, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'gold')
            brickvoltfig_voltax.hlines(
                y = cp_war_overvolt, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'gold', linestyle = '--')
        
        if sp_mod_overvolt is not None and brickvoltage_max_val >= sp_mod_overvolt:
            brickvoltfig_voltax.hlines(
                y = sp_mod_overvolt, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'darkorange')
            brickvoltfig_voltax.hlines(
                y = cp_mod_overvolt, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'darkorange', linestyle = '--')
            
        if sp_sev_overvolt is not None and brickvoltage_max_val >= sp_sev_overvolt:
            brickvoltfig_voltax.hlines(
                y = sp_sev_overvolt, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'red')
            brickvoltfig_voltax.hlines(
                y = cp_sev_overvolt, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'red', linestyle = '--')

        if sp_war_undervolt is not None and brickvoltage_min_val <= sp_war_undervolt:
            brickvoltfig_voltax.hlines(
                y = sp_war_undervolt, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'lightskyblue')
            brickvoltfig_voltax.hlines(
                y = cp_war_undervolt, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'lightskyblue', linestyle = '--')
        
        if sp_mod_undervolt is not None and brickvoltage_min_val <= sp_mod_undervolt:
            brickvoltfig_voltax.hlines(
                y = sp_mod_undervolt, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'deepskyblue')
            brickvoltfig_voltax.hlines(
                y = cp_mod_undervolt, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'deepskyblue', linestyle = '--')
        
        if sp_sev_undervolt is not None and brickvoltage_min_val <= sp_sev_undervolt:
            brickvoltfig_voltax.hlines(
                y = sp_sev_undervolt, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'royalblue')
            brickvoltfig_voltax.hlines(
                y = cp_sev_undervolt, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'royalblue', linestyle = '--')

        brickvoltfig_voltax.set_xlabel("Time (hrs)")
        brickvoltfig_voltax.set_ylabel("Voltage (V)")
        plt.xlim((min(time_hrs), max(time_hrs)))
        # plt.ylim((2.45, 4.25))

    with mpl.rc_context(rcdict02):
        brickvoltfig_voltagedeltaax = brickvoltfig_voltax.twinx()
        brickvoltfig_voltagedeltaax.spines["left"].set_position(("axes", -0.07))
        brickvoltfig_voltagedeltaax.spines["left"].set_visible(True)
        brickvoltfig_voltagedeltaax.yaxis.set_label_position('left')
        brickvoltfig_voltagedeltaax.yaxis.set_ticks_position('left')
        brickvoltfig_voltagedeltaax.plot(
            time_hrs, 
            voltagedelta, 
            label = 'Cell Voltage Difference')

        if sp_voltimbalance is not None and voltagedelta_max_val >= sp_voltimbalance:
            brickvoltfig_voltagedeltaax.hlines(
                y = sp_voltimbalance, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'red')
            brickvoltfig_voltagedeltaax.hlines(
                y = cp_voltimbalance, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'red', linestyle = '--')

        brickvoltfig_voltagedeltaax.set_ylabel('Cell Voltage Difference (V)')
        brickvoltfig_voltagedeltaax.grid(None)

    #if (PACK_IN_CHARGE):
    if balance_count is not None:
        brickvoltfig_nbalax = brickvoltfig_voltax.twinx()
        brickvoltfig_nbalax.plot(
            time_hrs, 
            balance_count, 
            label = "Balancing Count", 
            color = 'navy')
        brickvoltfig_nbalax.set_ylabel('Cell Balancing Count')
        #brickvoltfig_nbalax.spines['right'].set_position(('outward', 70))
        brickvoltfig_nbalax.grid(None)

    # brickvoltfig_chargestax = brickvoltfig_voltax.twinx()
    # brickvoltfig_chargestax.plot(time_hrs, signal_df.loc[:, 'ESS_BM1_ChgMode_St_enum'], label = "Charge Mode")
    # brickvoltfig_chargestax.set_ylabel('Charge Mode')
    # brickvoltfig_chargestax.spines['right'].set_position(('outward', 70))
    # plt.yticks(rotation='vertical')
    # brickvoltfig_chargestax.grid(None)

    with mpl.rc_context(fname='RA_BMS.rc'):
        lines, labels = brickvoltfig_voltax.get_legend_handles_labels()
        lines2, labels2 = brickvoltfig_voltagedeltaax.get_legend_handles_labels()
        if balance_count is not None:
            lines3, labels3 = brickvoltfig_nbalax.get_legend_handles_labels()
            brickvoltfig_voltax.legend(lines + lines2 + lines3, labels + labels2 + labels3)
        else:
            brickvoltfig_voltax.legend(lines + lines2, labels + labels2)
        #lines4, labels4 = brickvoltfig_chargestax.get_legend_handles_labels()
        #brickvoltfig_voltax.legend(lines + lines2 + lines3 + lines4, labels + labels2 + labels3 + labels4)

    brickvoltfig_voltax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)

    plt.title("Brick Voltages")
    brickvoltfig.set_size_inches(16, 12)
    
    if savefig:
        brickvoltfig.savefig(
            os.path.join(fig_dir, fname_prefix + '_Voltage_Bricks.png'),
            format='png',
            dpi=400,
            bbox_inches='tight')