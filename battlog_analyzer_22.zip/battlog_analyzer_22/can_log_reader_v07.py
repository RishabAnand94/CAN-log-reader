# -*- coding: utf-8 -*-
"""
Created on Mon Aug 31 13:34:43 2020

@author: ranand
"""
#%%

# import os
# if not os.path.exists('my_folder'):
#     os.makedirs('my_folder')

#%% Usage SOP
# CAN DBC file should be provided
# CAN log file in .asc format to be provided
# Chroma log file to be provided


#%%

import os
#import math
import numpy as np
import scipy.integrate

import matplotlib as mpl
import matplotlib.pyplot as plt
#from matplotlib.pyplot import text
plt.style.use("RA01")

# from pprint import pprint
from IPython import get_ipython
get_ipython().run_line_magic('matplotlib', 'qt')
# get_ipython().run_line_magic('matplotlib', 'inline')

import pandas as pd
import datetime as dt

import cantools
#import can
#import operator

import easygui as eg

import openpyxl as op
#from openpyxl.utils.dataframe import dataframe_to_rows
#from openpyxl.styles import Border, Side, Font
from openpyxl import load_workbook


from helperfunc import pad
from helperfunc import strip
from helperfunc import isNaN

import warnings
warnings.filterwarnings("ignore")


#%%
HW_VER = 2.1
SW_VER = ''


#%% RC parameter dictionaries for plots
rcdict02 = {'ytick.labelsize': 14, 'axes.labelsize': 14}

#%%
#def can_log_reader_v07_f(testid, batterySN, testdesc, testtemp, calver, canlog_filename, testerlog_filename):  
print('Reading test details ...')

TSTR_PR = 1
PACK_IN_CCDISCH = 0

msg = "Enter test details ..."
title = "BAL Traction Battery Testing"
fieldNames = ["Test #", "Battery Serial Number", "Test Description", "Test Temperature"]
default_fieldValues = ["", "SN01", "1C_Dch", "25degC"]
fieldValues = default_fieldValues
fieldValues = eg.multenterbox(msg, title, fieldNames, default_fieldValues)

# fieldValues[0] = str(testid)
# fieldValues[1] = batterySN
# fieldValues[2] = testdesc
# fieldValues[3] = testtemp

print("Reply was: %s" % str(fieldValues))

fname_prefix = 'Test#' + fieldValues[0] + '_' + fieldValues[1] + '_' + fieldValues[2] + '_' + fieldValues[3]

# Create directory to save generated figures and test report
fig_dir = "results\\" + fname_prefix
os.makedirs(fig_dir)
print("Directory '% s' created" % fname_prefix)

del msg, title, fieldNames, default_fieldValues

print("Reading CAN log file path ...")
# Show dialog box to select input data log file(s)
canlog_filePath = eg.fileopenbox(
    msg = 'Select CAN log file', 
    title = 'Charge / Discharge Test', 
    default = '*', 
    filetypes = ['*.asc'], 
    multiple = True)
# # Sort file names in ascending order so that merging is correct
# canlog_filePath.sort()
# print(canlog_filename)
# canlog_filePath = canlog_filename

# Read tester log file only if pack tester is present
if TSTR_PR:
    print("Reading tester log file path ...")
    # Show dialog box to select input data log file(s)
    testerlog_filePath = eg.fileopenbox(msg = 'Select data log file', title = 'Charge / Discharge Test', default = '*', filetypes = ['*.xls', '*.xlsx'], multiple = True)
    # # Sort file names in ascending order so that merging is correct
    # testerlog_filePath.sort();
    # print(testerlog_filename)
    # testerlog_filePath = testerlog_filename

# print("Calibration Version ", calver)
# global cal_ver
# cal_ver = calver
    
import cellcalib

#%% Load CAN log file
import canfunc
# Returns a timestamp indexed dataframe containing can messages
candf = canfunc.read_canlog(canlog_filePath, logtype = 'log')

#%% Load CAN message database
print("Loading CAN DBC file ...")

# Select appropriate dbc files
candb_relfilepath = '\\candbc\\pack\\'
diagdbc_relfilepath = '\\candbc\\debug\\'

# Find app version and cal version
appvermsg_id = 0x15700000
appvermsgdf = candf.loc[candf['arbitration_id'] == appvermsg_id]
if len(appvermsgdf) == 0:
    appvermsg_id = 0x15700010
    appvermsgdf = candf.loc[candf['arbitration_id'] == appvermsg_id]
appver = str(appvermsgdf['data'][1][0]) + '_' + str(appvermsgdf['data'][1][1]) + '_' + str(appvermsgdf['data'][1][2])
del appvermsgdf

SOC_TRIM = 0
SOC_TRIM_PACK = 0
DCH_POWAVL = 0
MOD = 1

print('Application Version ' + appver)

if appver in ['0_4_13', '0_4_14']:
    candb_filename = "dbc_BMS_v0.3.0.dbc"
    diagdbc_filename = "amp_debug_v5.dbc"
elif appver in ['0_4_15', '0_4_16', '0_4_17', '0_4_18', '0_4_19']:
    candb_filename = "dbc_BMS_v0.3.0.dbc"
    diagdbc_filename = "amp_debug_v6.dbc"
elif appver in ['0_4_24', '0_5_0']:
    candb_filename = "dbc_BMS_v0.3.0.dbc"
    diagdbc_filename = "amp_debug_v7.dbc"
    DCH_POWAVL = 1
elif appver in ['0_5_1', '0_5_2', '0_5_3']:
    candb_filename = "dbc_BMS_v0.3.0.dbc"
    diagdbc_filename = "amp_debug_v8.dbc"
    SOC_TRIM = 1
    DCH_POWAVL = 1
elif appver in ['0_5_11', '0_5_12', '0_5_13']:
    candb_filename = "dbc_BMS_v0.3.2.dbc"
    diagdbc_filename = "amp_debug_v9.dbc"
    SOC_TRIM = 1
    DCH_POWAVL = 1
elif appver in ['0_5_16', '0_5_17', '0_5_18', '0_5_19']:
    candb_filename = "dbc_BAL_BMS_v0.4.6.dbc"
    diagdbc_filename = "amp_debug_v9.dbc"
    SOC_TRIM_PACK = 1
    DCH_POWAVL = 1
    
else:
   candb_filename = "dbc_BMS_v0.3.0.dbc"
   diagdbc_filename = "amp_debug_v5.dbc"

# Read BMS DBC file
candb = cantools.database.load_file(os.getcwd()+candb_relfilepath+candb_filename)
# Read BMS diagnostics DBC file
with open (os.getcwd()+diagdbc_relfilepath+diagdbc_filename, 'r') as diagdbc:
    candb.add_dbc(diagdbc)

del diagdbc
#del candb_filename, diagdbc_filename

print("CAN DBC file loaded.")

#%% Extract pack current, pack voltage, CAN SoC, module temperatures, FET temperatures
print('Extracting signal values ...')
#TODO - Put rampdown timer under state change tracker

signal_list = [
               {'message': 'VCU_Command_BMS',               'signal': ['ETS_VCU_VCUBMSReqMode_Req_enum', 'ETS_VCU_VCUDchgPwrExp_Act_W', 'ETS_VCU_VCULoadCurrent_Act_A', 'ETS_VCU_VCUChargerPwrLimit_Act_A']},
               
               {'message': 'BMS_Charge',                    'signal': ['ESS_BMS_ChgLimit_Max_V', 'ESS_BMS_ChgLimitCont_Max_A', 'ESS_BMS_ChgLimit10sec_Max_A', 'ESS_BMS_ChgMode_St_enum', 'ESS_BMS_ChgRemainingTime_Est_min']},
               {'message': 'BMS_Discharge',                 'signal': ['ESS_BMS_DchgLimit_Max_V', 'ESS_BMS_DchgLimitCont_Max_A', 'ESS_BMS_DchgLimit10sec_Max_A']},
               {'message': 'BMS_Health',                    'signal': ['ESS_BMS_EnergyFulCharge_Est_kWh', 'ESS_BMS_CapFulCharge_Est_Ah',
                                                                       'ESS_BMS_ShortCircuit_Act_count',
                                                                       'ESS_BMS_InitImpedance_Act_mohm', 'ESS_BMS_CurrImpedance_Act_mohm', 'ESS_BMS_ChgCycle_Act_count']},
               {'message': 'BMS_MinMaxState',               'signal': ['ESS_BMS_nBal_Act_count']},
                                                                       #'ESS_BMS_MinCell_Act_V', 'ESS_BMS_MinVMod_Act_ID', 'ESS_BMS_MaxCell_Act_V', 'ESS_BMS_MaxVMod_Act_ID', \
                                                                       #'ESS_BMS_TempMin_Act_degC', 'ESS_BMS_MinTempMod_Act_ID', 'ESS_BMS_TempMax_Act_degC', 'ESS_BMS_MaxTempMod_Act_ID']}, \
               {'message': 'BMS_Overview',                  'signal': ['ESS_BMS_State_St_enum', 'ESS_BMS_Voltage_Act_V', 'ESS_BMS_iPack_Act_A', 'ESS_BMS_Temperature_Act_degC']},
               {'message': 'BMS_Sox',                       'signal': ['ESS_BMS_Soc_Est_perc', 'ESS_BMS_Sohc_Est_perc', 'ESS_BMS_Sohr_Est_perc', 'ESS_BMS_Soe_Est_perc', 'ESS_BMS_BalErr_Act_perc']},
               {'message': 'BMS_TerminalState',             'signal': ['ESS_BMS_roctPerMin_Act_degC', 'ESS_BMS_vLoad_Act_V', 'ESS_BMS_EnergyAvailable_Est_kWh', 'ESS_BMS_CapAvailable_Est_Ah']},   
                   
               {'message': 'BM1_Charge',                    'signal': ['ESS_BM1_ChgLimit_Max_V', 'ESS_BM1_ChgLimitCont_Max_A', 'ESS_BM1_ChgLimit10sec_Max_A', 'ESS_BM1_ChgMode_St_enum', 'ESS_BM1_ChgRemainingTime_Est_min']}, \
               {'message': 'BM1_Discharge',                 'signal': ['ESS_BM1_DchgLimit_Max_V', 'ESS_BM1_DchgLimitCont_Max_A', 'ESS_BM1_DchgLimit10sec_Max_A']}, \
               {'message': 'BM1_Health',                    'signal': ['ESS_BM1_EnergyFulCharge_Est_kWh', 'ESS_BM1_CapFulCharge_Est_Ah', \
                                                                       'ESS_BM1_ShortCircuit_Act_count', \
                                                                       'ESS_BM1_InitImpedance_Act_mohm', 'ESS_BM1_CurrImpedance_Act_mohm', 'ESS_BM1_ChgCycle_Act_count']}, \
               {'message': 'BM1_MinMaxState',               'signal': ['ESS_BM1_nBal_Act_count', 
                                                                       'ESS_BM1_MinCell_Act_V', 'ESS_BM1_MaxCell_Act_V', 
                                                                       'ESS_BM1_TempMin_Act_degC', 'ESS_BM1_TempMax_Act_degC']}, \
                                                                       #, 'ESS_BM1_MinVCell_Act_ID', , 'ESS_BM1_MaxVCell_Act_ID', 
                                                                       #, 'ESS_BM1_MinTempCell_Act_ID', 'ESS_BM1_MaxTempCell_Act_ID', \
               {'message': 'BM1_Overview',                  'signal': ['ESS_BM1_State_St_enum', 'ESS_BM1_Voltage_Act_V', 'ESS_BM1_iMod_Act_A', 'ESS_BM1_Temperature_Act_degC']}, \
               {'message': 'BM1_Sox',                       'signal': ['ESS_BM1_Soc_Est_perc', 'ESS_BM1_Sohc_Est_perc', 'ESS_BM1_Sohr_Est_perc', 'ESS_BM1_Soe_Est_perc', 'ESS_BM1_BalErr_Act_perc']}, \
               {'message': 'BM1_TerminalState',             'signal': ['ESS_BM1_roctPerMin_Act_degC', 'ESS_BM1_vLoad_Act_V', 'ESS_BM1_EnergyAvailable_Est_kWh', 'ESS_BM1_CapAvailable_Est_Ah']}, \
               {'message': 'BM1_Throughput',                'signal': ['ESS_BM1_AccChgEnergy_Est_kWh', 'ESS_BM1_AccDchgEnergy_Est_kWh']}, \
               
               {'message': 'BATT_appVersion',               'signal': ['BATT_appMajor', 'BATT_appMinor', 'BATT_appRevision', 'BATT_calMajor', 'BATT_calMinor', 'BATT_calRevision']}, \
               {'message': 'BATT_batteryTemperaturesA',     'signal': ['BATT_tModule1', 'BATT_tModule2', 'BATT_tModule3']}, \
               {'message': 'BATT_batteryTemperaturesB',     'signal': ['BATT_tModule4', 'BATT_tModule5', 'BATT_tModule6']}, \
               {'message': 'BATT_batteryTemperaturesC',     'signal': ['BATT_tFET', 'BATT_tAmbient', 'BATT_tShunt', 'BATT_tPrecharge']},   \
               {'message': 'BATT_boardADC_1',               'signal': ['BATT_boardADC_PACK', 'BATT_boardADC_COMMON_DRAIN', 'BATT_boardADC_LOAD', 'BATT_boardADC_PACK_PF']}, \
               {'message': 'BATT_BrickTempEstA',            'signal': ['BATT_tBrick01', 'BATT_tBrick02', 'BATT_tBrick03', 'BATT_tBrick04']}, \
               {'message': 'BATT_BrickTempEstB',            'signal': ['BATT_tBrick05', 'BATT_tBrick06', 'BATT_tBrick07', 'BATT_tBrick08']}, \
               {'message': 'BATT_BrickTempEstC',            'signal': ['BATT_tBrick09', 'BATT_tBrick10', 'BATT_tBrick11', 'BATT_tBrick12']}, \
               {'message': 'BATT_BrickTempEstD',            'signal': ['BATT_tBrick13', 'BATT_tBrick14']}, \
               {'message': 'BATT_diagnosticAhTotal',        'signal': ['BATT_ahChgTotal', 'BATT_ahDchTotal']}, \
               {'message': 'BATT_diagnosticBalStatusBrick', 'signal': ['BATT_balStatusBrick01', 'BATT_balStatusBrick02', 'BATT_balStatusBrick03', 'BATT_balStatusBrick04', \
                                                                       'BATT_balStatusBrick05', 'BATT_balStatusBrick06', 'BATT_balStatusBrick07', 'BATT_balStatusBrick08', \
                                                                       'BATT_balStatusBrick09', 'BATT_balStatusBrick10', 'BATT_balStatusBrick11', 'BATT_balStatusBrick12', \
                                                                       'BATT_balStatusBrick13', 'BATT_balStatusBrick14']}, \
               {'message': 'BATT_diagnosticCapBricksA',     'signal': ['BATT_capBrick01', 'BATT_capBrick02', 'BATT_capBrick03', 'BATT_capBrick04']}, \
               {'message': 'BATT_diagnosticCapBricksB',     'signal': ['BATT_capBrick05', 'BATT_capBrick06', 'BATT_capBrick07', 'BATT_capBrick08']}, \
               {'message': 'BATT_diagnosticCapBricksC',     'signal': ['BATT_capBrick09', 'BATT_capBrick10', 'BATT_capBrick11', 'BATT_capBrick12']}, \
               {'message': 'BATT_diagnosticCapBricksD',     'signal': ['BATT_capBrick13', 'BATT_capBrick14']}, \
               {'message': 'BATT_diagnosticChgFet',         'signal': ['BATT_fetChgDiagClosedResult', 'BATT_fetChgDiagOpenResult', 'BATT_fetChgDiagState', 'BATT_fetChgFailToCloseRetryCnt', 'BATT_fetChgShortedRetryCnt', \
                                                                       'BATT_fetChgDiagVMeas', 'BATT_fetChgDiagVMeasPrime', 'BATT_fetChgDiagIMeas']}, \
               {'message': 'BATT_diagnosticDsgFet',         'signal': ['BATT_fetDsgDiagClosedResult', 'BATT_fetDsgDiagOpenResult', 'BATT_fetDsgDiagState', 'BATT_fetDsgFailToCloseRetryCnt', 'BATT_fetDsgShortedRetryCnt', \
                                                                       'BATT_fetDsgDiagVMeas', 'BATT_fetDsgDiagVMeasPrime', 'BATT_fetDsgDiagIMeas']}, \
               {'message': 'BATT_diagnosticResBricksA',     'signal': ['BATT_resBrick01', 'BATT_resBrick02', 'BATT_resBrick03', 'BATT_resBrick04']}, \
               {'message': 'BATT_diagnosticResBricksB',     'signal': ['BATT_resBrick05', 'BATT_resBrick06', 'BATT_resBrick07', 'BATT_resBrick08']}, \
               {'message': 'BATT_diagnosticResBricksC',     'signal': ['BATT_resBrick09', 'BATT_resBrick10', 'BATT_resBrick11', 'BATT_resBrick12']}, \
               {'message': 'BATT_diagnosticResBricksD',     'signal': ['BATT_resBrick13', 'BATT_resBrick14']}, \
               {'message': 'BATT_diagnosticRunTime',        'signal': ['BATT_totalRunTime']}, \
               {'message': 'BATT_diagnosticSleepWake',      'signal': ['BATT_timeWakeCycle', 'BATT_timeSleepCycle']}, \
               {'message': 'BATT_diagnosticSOCBricksA',     'signal': ['BATT_socBrick01', 'BATT_socBrick02', 'BATT_socBrick03', 'BATT_socBrick04']}, \
               {'message': 'BATT_diagnosticSOCBricksB',     'signal': ['BATT_socBrick05', 'BATT_socBrick06', 'BATT_socBrick07', 'BATT_socBrick08']}, \
               {'message': 'BATT_diagnosticSOCBricksC',     'signal': ['BATT_socBrick09', 'BATT_socBrick10', 'BATT_socBrick11', 'BATT_socBrick12']}, \
               {'message': 'BATT_diagnosticSOCBricksD',     'signal': ['BATT_socBrick13', 'BATT_socBrick14']}, \
               {'message': 'BATT_diagnosticVBricksA',       'signal': ['BATT_vBrick01', 'BATT_vBrick02', 'BATT_vBrick03', 'BATT_vBrick04']}, \
               {'message': 'BATT_diagnosticVBricksB',       'signal': ['BATT_vBrick05', 'BATT_vBrick06', 'BATT_vBrick07', 'BATT_vBrick08']}, \
               {'message': 'BATT_diagnosticVBricksC',       'signal': ['BATT_vBrick09', 'BATT_vBrick10', 'BATT_vBrick11', 'BATT_vBrick12']}, \
               {'message': 'BATT_diagnosticVBricksD',       'signal': ['BATT_vBrick13', 'BATT_vBrick14']}, \
               {'message': 'BATT_hardwareVersion',          'signal': ['BATT_hardwareVersion']}, \
               {'message': 'BATT_iLimitInst',               'signal': ['BATT_iDchInst', 'BATT_iChgInst']}, \
               {'message': 'BATT_rtcTimeDate',              'signal': ['BATT_rtcYear', 'BATT_rtcMonth', 'BATT_rtcDay', 'BATT_rtcHour', 'BATT_rtcMinutes', 'BATT_rtcSeconds']}, \
               ]

if candb_filename in ["dbc_BMS_v0.3.0.dbc", "dbc_BMS_v0.3.2.dbc"]:
    # Signals in dbc_BMS_v0.3.0
    signal_list = signal_list + [{'message': 'VCU_Command_BMS',               'signal': ['ETS_VCU_VCUMaxChrgSOC_Ref_enum']}, \
                                 {'message': 'BM1_Health',                    'signal': ['ESS_BM1_PcbTempAmbient_Act_degC']},
                                 {'message': 'BMS_Health',                    'signal': ['ESS_BMS_PcbTempAmbient_Act_degC']  }]

elif candb_filename in ["dbc_BMS_v0.4.6.dbc"]:
    # Signals renamed in dbc_BAL_BMS_v0.4.6.dbc (or AMP dbc_BMS_v0.3.2 dbc)
    signal_list = signal_list + [{'message': 'VCU_Command_BMS',               'signal': ['ETS_VCU_UsrDfMaxChrgSOC_Ref_enum']}, \
                                 {'message': 'BM1_Health',                    'signal': ['ESS_BM1_PcbTemp_Act_degC']},
                                 {'message': 'BMS_Health',                    'signal': ['ESS_BMS_PcbTemp_Act_degC']}]


if diagdbc_filename in ["amp_debug_v7.dbc", "amp_debug_v8.dbc", "amp_debug_v9.dbc"]:
    # Debug dbc V7 additional signal
    signal_list = signal_list + [{'message': 'BATT_iLimitInst',              'signal': ['BATT_dch_pwr_available_W']}]

if diagdbc_filename in ["amp_debug_v8.dbc", "amp_debug_v9.dbc"]:
    # Debug dbc V8 additional signal
    signal_list = signal_list + [{'message': 'BATT_diagnosticSOCBricksD',     'signal': ['BATT_soc_trim_max', 'BATT_soc_trim_min']}]

# Debug dbc V9 additional signal
#TODO
# Debug dbc V9 instanced changes 
#TODO

# # Functionality not available
#

# Create an array of time indices by looking at the min and max times
min_time = candf.index.min().ceil(freq = '1S') #+ pd.Timedelta('1S')
max_time = candf.index.max().floor(freq = '1S') #- pd.Timedelta('1S')

time_sec = pd.date_range(start = min_time, end = max_time, freq = '1S')
# Create a dataframe to save extracted signal values
signal_df = pd.DataFrame(index = time_sec)
del time_sec

for sig_num in range(0, len(signal_list)):
    # print(signal_list[sig_num]['message'])
    print(signal_list[sig_num]['signal'])
    signal_df_seg = canfunc.get_sigval_ts(candf, candb, signal_list[sig_num]['message'], signal_list[sig_num]['signal'], min_time, max_time)
    signal_df = signal_df.join(signal_df_seg, how='outer')

del signal_df_seg

# Remove date information from timestamps
signal_df.index = signal_df.index - (signal_df.index[0] - pd.to_datetime(0)).floor('1D')

# Find time instants for beginning and end of cycle in the CAN log
curr_diff = np.diff(signal_df.loc[:, 'ESS_BM1_iMod_Act_A'])
currdelta_vals = [x for x in curr_diff if abs(x) > 0.5]
if len(currdelta_vals) > 0:
    index_can_cyclebegin = np.where(curr_diff == currdelta_vals[0])[0][0] + 1
    index_can_cyclebegin = signal_df.index[index_can_cyclebegin]
    index_can_cycleend = np.where(curr_diff == currdelta_vals[-1])[0][-1]
    index_can_cycleend = signal_df.index[index_can_cycleend]
else:
    index_can_cyclebegin = signal_df.index[1]
    index_can_cycleend = signal_df.index[-2]
#TODO

del curr_diff, currdelta_vals

print('Signal value extraction complete.')

#%% Load Chroma Log File
if(TSTR_PR):
    import excelreader
    
    print("Calling tester log file reader ... ")

    # Data column names
    colname_datetime = "TEST TIME"
    colname_time = "Real Time(ms)"                  # Time elapsed in ms
    colname_stepmode = "Step Mode"                  # Step mode
    colname_terminalvoltage = "Voltage(V)"          # Terminal voltage
    colname_current = "Current(A)"                  # Cell current
    colname_totalcapacity = "Total Capacity(Ah)"    # Cumulative capacity
    colname_energy = "Total KWh(KWh)"               # Cumulative energy

    collist = [colname_datetime, colname_time, colname_stepmode, \
                colname_terminalvoltage, colname_current, \
                colname_totalcapacity, colname_energy]

    # Function to parse tester log files and put data into a pandas dataframe
    tester_df = excelreader.read_excel(testerlog_filePath, collist, timestampIndex = True)

    # Eliminate date information from tester log timestamp
    date_tester = tester_df.index[0] - (tester_df.index[0] - tester_df.index[0].floor('1D'))
    tester_df.index = tester_df.index - (tester_df.index[0] - pd.to_datetime(0)).floor('1D')

    # tester_df['time_sec_tester'] = (tester_df.index - tester_df.index[0].floor('1D')).total_seconds()

    print("Extracting start/stop points from tester data ... ")
    # Determine cycle start and cycle end points
    # Determine first start point only and last end point
    index_tester_cyclebegin = tester_df.index[0]
    start_detected = False
    for index in range(len(tester_df)-1):
        if tester_df[colname_stepmode][index] == 'REST' and \
            (   (tester_df[colname_stepmode][index + 1] == 'CC Discharge') \
             or (tester_df[colname_stepmode][index + 1] == 'CC-CV Discharge') \
             or (tester_df[colname_stepmode][index + 1]== 'CC Charge') \
             or (tester_df[colname_stepmode][index + 1] == 'CC-CV Charge') \
             or (tester_df[colname_stepmode][index + 1] == 'Waveform(A)')):
            if (start_detected == False):       # Record the begining of the first pulse only
                index_tester_cyclebegin = tester_df.index[index + 1]    # Beginning of cycle
                start_detected = True

        elif (abs(tester_df[colname_current][index]) > 0.5 and tester_df[colname_stepmode][index + 1] == 'REST'):
                index_tester_cycleend = tester_df.index[index]    # End of cycle
    
    if (abs(tester_df[colname_current][len(tester_df)-1]) > 0.5):
        # Last entry in tester log has non-zero current
        index_tester_cycleend = tester_df.index[len(tester_df)-1]    # End of cycle not in log

    del start_detected

else:
    print("Pack tester not present.")
    date_tester = signal_df.index[0].date()
    colname_current = "ESS_BM1_iMod_Act_A"
    colname_terminalvoltage = "ESS_BM1_Voltage_Act_V"
    colname_totalcapacity = "cum_Ah_can" # Cumulative capacity
    colname_energy = "cum_kWh_can"
    index_tester_cyclebegin = index_can_cyclebegin
    index_tester_cycleend = index_can_cycleend

#%% Time synchronize and merge CAN and pack tester logs
if(TSTR_PR):
    print('Merging CAN and pack tester logs ...')

    # Additional logic in case the time stamps are skewed - adjust tester log to match CAN timestamps
    clock_skew = index_can_cyclebegin - index_tester_cyclebegin
    clock_skew2 = index_can_cycleend - index_tester_cycleend

    tester_df.index = tester_df.index + clock_skew
    index_tester_cyclebegin += clock_skew
    index_tester_cycleend += clock_skew

    signal_df = signal_df.join(tester_df, how = 'outer')
    del tester_df

    print('CAN and pack tester log merge complete.')

# Drop rows for which BMS state or VCU command is missing
print('Deleting rows with missing state signals ...')
signal_df.dropna(axis = 0, subset = ['ETS_VCU_VCUBMSReqMode_Req_enum', 'ESS_BMS_State_St_enum', 'ESS_BM1_State_St_enum'], inplace = True)

# Index one sample before beginning of cycle
index_beforecycle = index_tester_cyclebegin - pd.Timedelta('1S')

# Determine end of rest period after cycle for determining "at rest" quantities
if max(signal_df.index) > (index_tester_cycleend +  pd.Timedelta('60 min')):
    index_tester_rested = min(signal_df[signal_df.index > (index_tester_cycleend +  pd.Timedelta('60 min'))].index)
else:
    index_tester_rested = max(signal_df.index) - pd.Timedelta('1S')

signal_df['time_sec_can'] = (signal_df.index - signal_df.index[0]).total_seconds()

# Adjust offset in the CAN log so that cycle begins at t = 0
if TSTR_PR:
    signal_df['time_sec_can'] -= signal_df.loc[index_tester_cyclebegin, 'time_sec_can']

# Use for time axis in all plots
time_hrs = [i/3600 for i in signal_df['time_sec_can']]

# Compute accumulated capacity using can current
print('Computing accumulated capacity using CAN current ...')
cum_Ah_can = scipy.integrate.cumtrapz(signal_df['ESS_BM1_iMod_Act_A'], x = signal_df['time_sec_can'])/3600
cum_Ah_can = np.append(cum_Ah_can, cum_Ah_can[-1])
signal_df['cum_Ah_can'] = cum_Ah_can
del cum_Ah_can

# Compute accumulated energy using can voltage and current
print('Computing accumulated energy using CAN voltage and current ...')
dkWh = [a*b/1000 for a,b in zip(signal_df['ESS_BM1_Voltage_Act_V'], signal_df['ESS_BM1_iMod_Act_A'])]
cum_kWh_can = scipy.integrate.cumtrapz(dkWh, x = signal_df['time_sec_can'])/3600
cum_kWh_can = np.append(cum_kWh_can, cum_kWh_can[-1])
signal_df['cum_kWh_can'] = cum_kWh_can
del dkWh, cum_kWh_can

PACK_IN_CHARGE = 0
if (strip(signal_df.loc[index_can_cyclebegin, 'ESS_BM1_State_St_enum']) == 'CHARGE'):
    PACK_IN_CHARGE = 1
    PACK_IN_CCDISCH = 0

if TSTR_PR == 0:
    PACK_IN_CCDISCH = 0

# Remove SoC trim from estimated SoC signal in SoX message
print('Computing true SoC from trimmed SoC ...')
if SOC_TRIM:
    if not isNaN(signal_df.loc[index_tester_cyclebegin, 'BATT_soc_trim_max']):
        signal_df['PackSoC_Trimmed'] = signal_df['ESS_BM1_Soc_Est_perc']
        signal_df['ESS_BM1_Soc_Est_perc'] = 0.01*signal_df['PackSoC_Trimmed']*(signal_df['BATT_soc_trim_max'] - signal_df['BATT_soc_trim_min']) + signal_df['BATT_soc_trim_min']

if SOC_TRIM_PACK:
    if not isNaN(signal_df.loc[index_tester_cyclebegin, 'BATT_soc_trim_max']):
        signal_df['PackSoC_Trimmed'] = signal_df['ESS_BMS_Soc_Est_perc']
    
#%% Save parameters of interest as time-series for comparison among tests
print('Saving pack parameters as time-series ...')
save_filename = fig_dir + '\\' + fname_prefix + '_rsdata.xlsx'
signal_df.to_excel(
    excel_writer = save_filename, 
    sheet_name='Sheet1', 
    na_rep='nan',
    inf_rep='inf',
    float_format=None, 
    columns=[
        'time_sec_can', 
        'ETS_VCU_VCUBMSReqMode_Req_enum', 'ESS_BM1_State_St_enum', 
        'ESS_BM1_Voltage_Act_V', 'ESS_BM1_vLoad_Act_V', 'ESS_BM1_iMod_Act_A',
        'ESS_BM1_ChgLimitCont_Max_A', 'ESS_BM1_ChgLimit10sec_Max_A', 'BATT_iChgInst', 
        'ESS_BM1_DchgLimitCont_Max_A', 'ESS_BM1_DchgLimit10sec_Max_A', 'BATT_iDchInst',
        'ESS_BM1_Soc_Est_perc', 'ESS_BM1_nBal_Act_count',
        'ESS_BM1_MinCell_Act_V', 'ESS_BM1_MaxCell_Act_V',
        'ESS_BM1_TempMin_Act_degC', 'ESS_BM1_TempMax_Act_degC',
        'BATT_tFET', 'BATT_tAmbient'], 
    header=True, 
    index=True, index_label=None, 
    merge_cells=True
    )

#%% Decode fault message without resampling
print('Extracting error flag values ...')

# Core list
signal_list = [
                {'message': 'BM1_FaultEventMatrix',       'signal': ['ESS_BM1_vBrickUnderWar_St_B', 'ESS_BM1_vBrickUnderMod_St_B', 'ESS_BM1_vBrickUnderSev_St_B', \
                                                                     'ESS_BM1_vBrickOverWar_St_B', 'ESS_BM1_vBrickOverMod_St_B', 'ESS_BM1_vBrickOverSev_St_B', \
                                                                     'ESS_BM1_BrickOvercharge_St_B', 'ESS_BM1_BrickOverdischarge_St_B', \
                                                                     'ESS_BM1_vBrickImbalance_St_B', \
                                                                     'ESS_BM1_SenseBrickVoltError_St_B', 'ESS_BM1_SenseHrnssVoltErr_St_B', 'ESS_BM1_SenseLoadVoltError_St_B' , \
                                                                     'ESS_BM1_TempBrickImbalance_St_B', \
                                                                     'ESS_BM1_BrickTempOpen_St_B', 'ESS_BM1_BrickTempShort_St_B', \
                                                                     'ESS_BM1_FEToverheat_St_B', \
                                                                     'ESS_BM1_iOverdischarge_St_B', 'ESS_BM1_iOvercharge_St_B', 'ESS_BM1_iOverRegen_St_B', 'ESS_BM1_iUndercharge_St_B', \
                                                                     'ESS_BM1_iOverHardware_St_B', 'ESS_BM1_extFuseBlown_St_B', \
                                                                     'ESS_BM1_SenseCurrentError_St_B', \
                                                                     'ESS_BM1_PrechgTimeout_St_B', 'ESS_BM1_PrechgFETFailClose_St_B', \
                                                                     'ESS_BM1_VCUCmdMsgTimeout_St_B', 'ESS_BM1_AFEfault_St_B', 'ESS_BM1_AFEcommError_St_B', 'ESS_BM1_BMSProcessorError_St_B', \
                                                                     'ESS_BM1_FETopenReqVCU_St_B', \
                                                                     'ESS_BM1_CapPackLow_St_B', 'ESS_BM1_PowerpackInsuffErr_St_B', \
                                                                     'ESS_BM1_EvntLoggerNearFull_St_B', 'ESS_BM1_EvntLoggerFull_St_B', \
                                                                     'ESS_BM1_ModuleMIA_St_B', 'ESS_BM1_ModuleSlctDisagree_St_B', 'ESS_BM1_ModuleImbalance_St_B', 'ESS_BM1_ModuleConnectFault_St_B']}, \
                {'message': 'BATT_afeStatusA',           'signal': ['BATT_afeCellOV', 'BATT_afeCellUV', 'BATT_afeCellOpen']}, \
                {'message': 'BATT_afeStatusB',           'signal': ['BATT_afeBalOpen', 'BATT_afeBalShort', 'BATT_afeGpioOT', 'BATT_afeGpioUT', 'BATT_afeGpioOpen', 'BATT_afeGpioShort']}, \
                {'message': 'BATT_afeStatusC',           'signal': ['BATT_afeEepromCrcErrRam', 'BATT_afeEepromCrcErrSect0', 'BATT_afeEobTimerErr', 'BATT_afeEofBal', \
                                                                    'BATT_afeLossAGnd', 'BATT_afeLossCGnd', 'BATT_afeLossDGnd', 'BATT_afeLossGndRef', \
                                                                    'BATT_afeOTChip', 'BATT_afeOvrLatch', 'BATT_afeRamCrcErr', 'BATT_afeSenseMinusOpen', 'BATT_afeSensePlusOpen', \
                                                                    'BATT_afeTCycleOvf', 'BATT_afeVanaOV', 'BATT_afeVbatCompBISTFail', 'BATT_afeVbattCritOV', 'BATT_afeVbattCritUV', \
                                                                    'BATT_afeVbattWrnOV', 'BATT_afeVbattWrnUV', 'BATT_afeVcomCompBISTFail', 'BATT_afeVcomOV', 'BATT_afeVcomUV', \
                                                                    'BATT_afeVdigOV', 'BATT_afeVregCompBISTFail', 'BATT_afeVregOV', 'BATT_afeVregUV', 'BATT_afeVSumOV', 'BATT_afeVSumUV', \
                                                                    'BATT_afeVtrefCompBISTFail', 'BATT_afeVtrefOV', 'BATT_afeVtrefUV', 'BATT_afeCocOvf', 'BATT_afeCommTimeoutFlt', \
                                                                    'BATT_afeEepromCrcErrCalFF', 'BATT_afeHeartbeatFault', 'BATT_afeOscFail', 'BATT_afeVbatOpen']}, \
                {'message': 'BATT_boardIO',              'signal': ['BATT_boardIO_RTC_WAKE_LATCH', 'BATT_boardIO_L9963_FAULT', 'BATT_boardIO_DIS_OC_FLT_LA']}, \
                {'message': 'BATT_inhibitions',          'signal': ['BATT_inhCharge', 'BATT_inhChargeEntry', 'BATT_inhContPower', 'BATT_inhDrive', 'BATT_inhDriveEntry', 'BATT_inhFullPower', 'BATT_inhRegen']}, \
                {'message': 'VCU_Command_BMS',           'signal': ['ETS_VCU_BMStimeoutCAN_St_B', 'ETS_VCU_BMSsoftMismatch_St_B', 'ETS_VCU_BMSauthError_St_B']}
                ]
                # 'BATT_boardIO_CAN_WAKE_LATCH'

if candb_filename in ["dbc_BMS_v0.3.0.dbc"]:
    # Signals removed from dbc_BMS_v0.3.0
    signal_list = signal_list + [{'message': 'BM1_FaultEventMatrix',       'signal': [ 'ESS_BM1_TempModuleUnderWar_St_B', 'ESS_BM1_TempModuleUnderMod_St_B', 'ESS_BM1_TempModuleUnderSev_St_B', \
                                                                                      'ESS_BM1_TempModuleOverWar_St_B', 'ESS_BM1_TempModuleOverMod_St_B', 'ESS_BM1_TempModuleOverSev_St_B', \
                                                                                      'ESS_BM1_SenseThermistorErr_St_B', \
                                                                                      'ESS_BM1_TempAmbientOverWar_St_B', 'ESS_BM1_TempAmbientOverMod_St_B', 'ESS_BM1_TempAmbientOverSev_St_B', \
                                                                                      'ESS_BM1_iOverFuse_St_B', \
                                                                                      'ESS_BM1_PrechgFETshort_St_B', \
                                                                                      'ESS_BM1_MainFETfailClose_St_B', 'ESS_BM1_MainFETstuckOpen_St_B', 'ESS_BM1_MainFETshorted_St_B', \
                                                                                      'ESS_BM1_ModuleCellSoftShort_St_B']}]
  
if candb_filename in ["dbc_BMS_v0.3.2.dbc", "dbc_BMS_v0.4.6.dbc"]:       
    # dbc_BMS_v0.3.1 changes 
    signal_list = signal_list + [{'message': 'BM1_FaultEventMatrix',       'signal': [  'ESS_BM1_SensePackVoltError_St_B', \
                                                                                        'ESS_BM1_DchFETfailClose_St_B', 'ESS_BM1_DchFETshorted_St_B', 'ESS_BM1_DchFETshortedAux_St_B', \
                                                                                        'ESS_BM1_ChgFETfailClose_St_B', 'ESS_BM1_ChgFETshorted_St_B', 'ESS_BM1_ChgFETshortedAux_St_B', \
                                                                                        'ESS_BM1_ModuleDchFetWelded_St_B', 'ESS_BM1_ModuleChgFetWelded_St_B', \
                                                                                        'ESS_BM1_ModuleNumMismatch_St_B', \
                                                                                        'ESS_BM1_TempDchgUnderWar_St_B', 'ESS_BM1_TempDchgUnderMod_St_B', 'ESS_BM1_TempDchgUnderSev_St_B', \
                                                                                        'ESS_BM1_TempDchgOverWar_St_B', 'ESS_BM1_TempDchgOverMod_St_B', 'ESS_BM1_TempDchgOverSev_St_B', \
                                                                                        'ESS_BM1_TempChgUnderWar_St_B', 'ESS_BM1_TempChgUnderMod_St_B', 'ESS_BM1_TempChgUnderSev_St_B', \
                                                                                        'ESS_BM1_TempChgOverWar_St_B', 'ESS_BM1_TempChgOverMod_St_B', 'ESS_BM1_TempChgOverSev_St_B', \
                                                                                        'ESS_BM1_TempPCBHigh_St_B', 
                                                                                        'ESS_BM1_PrechgLoadShort_St_B', 
                                                                                        'ESS_BM1_iLoadCurrentFault_St_B' 
                                                                                        ]}]
                                                                                        #, 'ESS_BM1_ModuleExitedFromBus_St_B'

    
# Empty list of error frames
error_df = []

for sig_num in range(0, len(signal_list)):
    print(signal_list[sig_num]['signal'])
    error_df = error_df + canfunc.get_errorlog(candf, candb, signal_list[sig_num]['message'], signal_list[sig_num]['signal'])

# Map error log timestamp to test time
date_can = (candf.index.min().ceil('1S') - pd.to_datetime(0)).floor('1D')
for error in error_df:
    error[0] = pd.to_datetime(error[0], unit = 's')
    error.append((pd.to_datetime(error[0], unit = 's') - date_can - index_can_cyclebegin).total_seconds()/60)
    error[0] = error[0].time()

# Sort in increasing order of event time
error_df.sort(key = lambda x: x[-1])

del date_can, error

print('Error flag value extraction complete.')

#%% Need to decode messages containing VCU state request, BMS State, Charge State, Main and Precharge FET states at actual rates
print("Extracting state change instances ...")

signal_list = [{'message': 'VCU_Command_BMS',   'signal': ['ETS_VCU_VCUBMSReqMode_Req_enum', 'ETS_VCU_VCUErrEmerOff_Req_enum']},
               
               {'message': 'BM1_Overview',      'signal': ['ESS_BM1_MainFETState_St_B', 'ESS_BM1_State_St_enum', 'ESS_BM1_PreChgFETState_St_B',
                                                           'ESS_BM1_MinVSevere_St_enum', 'ESS_BM1_MinVModerate_St_enum', 'ESS_BM1_MinVWarning_St_enum', 'ESS_BM1_MinVOA_St_enum',
                                                           'ESS_BM1_MaxVSevere_St_enum', 'ESS_BM1_MaxVModerate_St_enum', 'ESS_BM1_MaxVWarning_St_enum', 'ESS_BM1_MaxVOA_St_enum' ]},
               {'message': 'BMS_Overview',      'signal': ['ESS_BMS_MainFETState_St_B', 'ESS_BMS_State_St_enum', 'ESS_BMS_PreChgFETState_St_B',
                                                           'ESS_BMS_MinVSevere_St_enum', 'ESS_BMS_MinVModerate_St_enum', 'ESS_BMS_MinVWarning_St_enum', 'ESS_BMS_MinVOA_St_enum',
                                                           'ESS_BMS_MaxVSevere_St_enum', 'ESS_BMS_MaxVModerate_St_enum', 'ESS_BMS_MaxVWarning_St_enum', 'ESS_BMS_MaxVOA_St_enum']},
               
               {'message': 'BM1_Charge',        'signal': ['ESS_BM1_ChgEnable_St_enum', 'ESS_BM1_ChgMode_St_enum', 'ESS_BM1_ChgDerateFlag_St_enum']},
               {'message': 'BMS_Charge',        'signal': ['ESS_BMS_ChgEnable_St_enum', 'ESS_BMS_ChgMode_St_enum', 'ESS_BMS_ChgDerateReason_St_enum']},
               
               {'message': 'BM1_Discharge',     'signal': ['ESS_BM1_DchgDerateFlag_St_enum']},  
               {'message': 'BMS_Discharge',     'signal': ['ESS_BMS_DchgDerateReason_St_enum']}, 
               
               {'message': 'BM1_Sox',           'signal': ['ESS_BM1_RampDownTime_Act_sec']},
               {'message': 'BMS_Sox',           'signal': ['ESS_BMS_RampDownTime_Act_sec']},
               
               {'message': 'BM1_TerminalState', 'signal': ['ESS_BM1_ParallelConnMode_St_B', 'ESS_BM1_ParallelConnection_St_B']},
               {'message': 'BMS_TerminalState', 'signal': ['ESS_BMS_ParallelDet_Act_count', 'ESS_BMS_ParallelCon_Act_count']},
             
               {'message': 'BM1_Throughput',    'signal': ['ESS_BM1_PrechargeChgID_Act_ID', 'ESS_BM1_PrechargeDchgID_Act_ID']},    
               
               {'message': 'BATT_sleepWake',    'signal': ['BATT_wakeReason']}, \
              ]
  
statechange_df = []

for sig_num in range(0, len(signal_list)):
    print(signal_list[sig_num]['signal'])
    statechange_df = statechange_df + canfunc.get_statechangelog(candf, candb, signal_list[sig_num]['message'], signal_list[sig_num]['signal'])

# Map error log timestamp to test time
date_can = (candf.index.min().ceil('1S') - pd.to_datetime(0)).floor('1D')
for statechange in statechange_df:
    statechange[0] = pd.to_datetime(statechange[0], unit = 's')
    statechange.append((pd.to_datetime(statechange[0], unit = 's') - date_can - index_can_cyclebegin).total_seconds()/60)
    statechange[0] = statechange[0].time()

# # Sort in increasing order of event time
# statechange_df.sort(key = lambda x: x[-1])

#del date_can
del statechange

# Separate out VCU commands, BMS states and FET states
temp_df = {}
for sig_num in range(0, len(signal_list)):
    for signal in signal_list[sig_num]['signal']:
        temp_df[signal] = []
        for statechange in statechange_df:
            if statechange[1] == signal:
                temp_df[signal].append(statechange)

statechange_df = temp_df
del temp_df

print("State change instance extraction complete.")

# Monitor critical transition times
# Discharge request on VCU command to drive (< 500 ms)

# Precharge Time (< 300 ms)

#%% Need visual indication of cycle begin and end time for assurance
print("Plotting pack voltage and current ...")
import plot_packvoltcurr

plot_packvoltcurr.plot_pack_volt_current(
    time_secs = signal_df['time_sec_can'],
    can_packvoltage = pad(signal_df['ESS_BMS_Voltage_Act_V']),
    can_loadvoltage = pad(signal_df['ESS_BMS_vLoad_Act_V']),
    can_packcurrent = pad(signal_df['ESS_BMS_iPack_Act_A']),
    
    can_modvoltage1 = pad(signal_df['ESS_BM1_Voltage_Act_V']),
    can_loadvoltage1 = pad(signal_df['ESS_BM1_vLoad_Act_V']),
    can_modcurrent1 = signal_df['ESS_BM1_iMod_Act_A'],
    
    can_modvoltage2 = pad(signal_df['ESS_BM2_Voltage_Act_V']) if MOD >= 2 else None,
    can_loadvoltage2 = pad(signal_df['ESS_BM2_vLoad_Act_V']) if MOD >= 2 else None,
    can_modcurrent2 = signal_df['ESS_BM2_iMod_Act_A'] if MOD >= 2 else None,
    
    can_modvoltage3 = pad(signal_df['ESS_BM3_Voltage_Act_V']) if MOD >= 3 else None,
    can_loadvoltage3 = pad(signal_df['ESS_BM3_vLoad_Act_V']) if MOD >= 3 else None,
    can_modcurrent3 = signal_df['ESS_BM3_iMod_Act_A'] if MOD >= 3 else None,
    
    can_modvoltage4 = pad(signal_df['ESS_BM4_Voltage_Act_V']) if MOD >= 4 else None,
    can_loadvoltage4 = pad(signal_df['ESS_BM4_vLoad_Act_V']) if MOD >= 4 else None,
    can_modcurrent4 = signal_df['ESS_BM4_iMod_Act_A'] if MOD >= 4 else None,
    
    tester_voltage = signal_df[colname_terminalvoltage] if TSTR_PR else None, 
    tester_current = signal_df[colname_current] if TSTR_PR else None,
    index_cyclebegin = index_tester_cyclebegin,
    index_cycleend = index_tester_cycleend,
    index_rv_postcycle = index_tester_rested,
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )

#%% Plot of brick voltages
print("Plotting brick voltages ...")
import plot_brickvolt

event_df = cellcalib.event_df

#TODO - Plot brick voltages for all modules
bricklist = ['BATT_vBrick' + str(brick).zfill(2) for brick in range(1, 14+1)]

plot_brickvolt.plot_brick_voltage(
    time_secs = signal_df['time_sec_can'],
    brickvoltages = signal_df[bricklist],
    balance_count = signal_df.loc[:, 'ESS_BM1_nBal_Act_count'],
    sp_war_overvolt = event_df.loc[event_df['Event Name'] == 'Brick Overvoltage Warning']['Set Point Value'].iloc[0],
    cp_war_overvolt = event_df.loc[event_df['Event Name'] == 'Brick Overvoltage Warning']['Clearpoint'].iloc[0],
    sp_mod_overvolt = event_df.loc[event_df['Event Name'] == 'Brick Overvoltage Moderate']['Set Point Value'].iloc[0],
    cp_mod_overvolt = event_df.loc[event_df['Event Name'] == 'Brick Overvoltage Moderate']['Clearpoint'].iloc[0],
    sp_sev_overvolt = event_df.loc[event_df['Event Name'] == 'Brick Overvoltage Severe']['Set Point Value'].iloc[0],
    cp_sev_overvolt = event_df.loc[event_df['Event Name'] == 'Brick Overvoltage Severe']['Clearpoint'].iloc[0],
    sp_war_undervolt = event_df.loc[event_df['Event Name'] == 'Brick Undervoltage Warning' ]['Set Point Value'].iloc[0],
    cp_war_undervolt = event_df.loc[event_df['Event Name'] == 'Brick Undervoltage Warning']['Clearpoint'].iloc[0],
    sp_mod_undervolt = event_df.loc[event_df['Event Name'] == 'Brick Undervoltage Moderate']['Set Point Value'].iloc[0],
    cp_mod_undervolt = event_df.loc[event_df['Event Name'] == 'Brick Undervoltage Moderate']['Clearpoint'].iloc[0],
    sp_sev_undervolt = event_df.loc[event_df['Event Name'] == 'Brick Undervoltage Severe']['Set Point Value'].iloc[0],
    cp_sev_undervolt = event_df.loc[event_df['Event Name'] == 'Brick Undervoltage Severe']['Clearpoint'].iloc[0],
    sp_voltimbalance = event_df.loc[event_df['Event Name'] == 'Battery Brick Voltage Imbalance']['Set Point Value'].iloc[0],
    cp_voltimbalance = event_df.loc[event_df['Event Name'] == 'Battery Brick Voltage Imbalance']['Clearpoint'].iloc[0],
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )

del bricklist

#%% Plot VCU requested state, BMS state and error 
print("Plotting bms states ...")
import plot_bmsst

plot_bmsst.plot_bms_state(
    time_secs = signal_df['time_sec_can'], 
    vcu_streq = signal_df['ETS_VCU_VCUBMSReqMode_Req_enum'], 
    bms_st = signal_df['ESS_BMS_State_St_enum'],
    bm1_st = signal_df['ESS_BM1_State_St_enum'],
    bm2_st = signal_df['ESS_BM2_State_St_enum'] if MOD >= 2 else None,
    bm3_st = signal_df['ESS_BM3_State_St_enum'] if MOD >= 3 else None,
    bm4_st = signal_df['ESS_BM4_State_St_enum'] if MOD >= 4 else None,
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )
  
#%% If in charge, monitor charge state
#TODO - Get rid of excess grid lines
print("Plotting charge state ...")
import plot_chgst

bricklist = ['BATT_vBrick' + str(brick).zfill(2) for brick in range(1, 14+1)]

plot_chgst.plot_charge_state(
    time_secs = signal_df['time_sec_can'], 
    bms_chmode = signal_df['ESS_BM1_ChgMode_St_enum'], 
    brickvoltages = signal_df[bricklist], 
    can_packcurrent = signal_df['ESS_BM1_iMod_Act_A'],
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix)

#%% Plot of pack temperature sensor readings vs. time
print("Plotting pack tempearture readings ...")
import plot_packtemp

event_df = cellcalib.event_df
tempsensorlist = ['BATT_tModule' + str(sensor).zfill(1) for sensor in range(1, 6+1)]

# if candb_filename == "dbc_BMS_v0.3.0.dbc":
#     sp_war_overtemp = event_df.loc[event_df['Event Name'] == 'Module Over Temp Warning']['Set Point Value'].iloc[0]
#     cp_war_overtemp = event_df.loc[event_df['Event Name'] == 'Module Over Temp Warning']['Clearpoint'].iloc[0]
#     sp_mod_overtemp = event_df.loc[event_df['Event Name'] == 'Module Over Temp Moderate']['Set Point Value'].iloc[0]
#     cp_mod_overtemp = event_df.loc[event_df['Event Name'] == 'Module Over Temp Moderate']['Clearpoint'].iloc[0]
#     sp_sev_overtemp = event_df.loc[event_df['Event Name'] == 'Module Over Temp Severe ']['Set Point Value'].iloc[0]
#     cp_sev_overtemp = event_df.loc[event_df['Event Name'] == 'Module Over Temp Severe ']['Clearpoint'].iloc[0]
#     sp_war_undertemp = event_df.loc[event_df['Event Name'] == 'Module Under Temp Warning ' ]['Set Point Value'].iloc[0]
#     cp_war_undertemp = event_df.loc[event_df['Event Name'] == 'Module Under Temp Warning ']['Clearpoint'].iloc[0]
#     sp_mod_undertemp = event_df.loc[event_df['Event Name'] == 'Module Under Temp Moderate ']['Set Point Value'].iloc[0]
#     cp_mod_undertemp = event_df.loc[event_df['Event Name'] == 'Module Under Temp Moderate ']['Clearpoint'].iloc[0]
#     sp_sev_undertemp = event_df.loc[event_df['Event Name'] == 'Module Under Temp Severe ']['Set Point Value'].iloc[0]
#     cp_sev_undertemp = event_df.loc[event_df['Event Name'] == 'Module Under Temp Severe ']['Clearpoint'].iloc[0]

# elif candb_filename in ["dbc_BMS_v0.3.2.dbc", "dbc_BMS_v0.4.6.dbc"]:   
#     if PACK_IN_CHARGE:
#         sp_war_overtemp = event_df.loc[event_df['Event Name'] == 'Module Charge Over Temp Warning']['Set Point Value'].iloc[0]
#         cp_war_overtemp = event_df.loc[event_df['Event Name'] == 'Module Charge Over Temp Warning']['Clearpoint'].iloc[0]
#         sp_mod_overtemp = event_df.loc[event_df['Event Name'] == 'Module Charge Over Temp Moderate']['Set Point Value'].iloc[0]
#         cp_mod_overtemp = event_df.loc[event_df['Event Name'] == 'Module Charge Over Temp Moderate']['Clearpoint'].iloc[0]
#         sp_sev_overtemp = event_df.loc[event_df['Event Name'] == 'Module Charge Over Temp Severe ']['Set Point Value'].iloc[0]
#         cp_sev_overtemp = event_df.loc[event_df['Event Name'] == 'Module Charge Over Temp Severe ']['Clearpoint'].iloc[0]
#         sp_war_undertemp = event_df.loc[event_df['Event Name'] == 'Module Charge Under Temp Warning ' ]['Set Point Value'].iloc[0]
#         cp_war_undertemp = event_df.loc[event_df['Event Name'] == 'Module Charge Under Temp Warning ']['Clearpoint'].iloc[0]
#         sp_mod_undertemp = event_df.loc[event_df['Event Name'] == 'Module Charge Under Temp Moderate ']['Set Point Value'].iloc[0]
#         cp_mod_undertemp = event_df.loc[event_df['Event Name'] == 'Module Charge Under Temp Moderate ']['Clearpoint'].iloc[0]
#         sp_sev_undertemp = event_df.loc[event_df['Event Name'] == 'Module Charge Under Temp Severe ']['Set Point Value'].iloc[0]
#         cp_sev_undertemp = event_df.loc[event_df['Event Name'] == 'Module Charge Under Temp Severe ']['Clearpoint'].iloc[0]
    
#     else:
#         sp_war_overtemp = event_df.loc[event_df['Event Name'] == 'Module Discharge Over Temp Warning']['Set Point Value'].iloc[0]
#         cp_war_overtemp = event_df.loc[event_df['Event Name'] == 'Module Discharge Over Temp Warning']['Clearpoint'].iloc[0]
#         sp_mod_overtemp = event_df.loc[event_df['Event Name'] == 'Module Discharge Over Temp Moderate']['Set Point Value'].iloc[0]
#         cp_mod_overtemp = event_df.loc[event_df['Event Name'] == 'Module Discharge Over Temp Moderate']['Clearpoint'].iloc[0]
#         sp_sev_overtemp = event_df.loc[event_df['Event Name'] == 'Module Discharge Over Temp Severe ']['Set Point Value'].iloc[0]
#         cp_sev_overtemp = event_df.loc[event_df['Event Name'] == 'Module Discharge Over Temp Severe ']['Clearpoint'].iloc[0]
#         sp_war_undertemp = event_df.loc[event_df['Event Name'] == 'Module Discharge Under Temp Warning ' ]['Set Point Value'].iloc[0]
#         cp_war_undertemp = event_df.loc[event_df['Event Name'] == 'Module Discharge Under Temp Warning ']['Clearpoint'].iloc[0]
#         sp_mod_undertemp = event_df.loc[event_df['Event Name'] == 'Module Discharge Under Temp Moderate ']['Set Point Value'].iloc[0]
#         cp_mod_undertemp = event_df.loc[event_df['Event Name'] == 'Module Discharge Under Temp Moderate ']['Clearpoint'].iloc[0]
#         sp_sev_undertemp = event_df.loc[event_df['Event Name'] == 'Module Discharge Under Temp Severe ']['Set Point Value'].iloc[0]
#         cp_sev_undertemp = event_df.loc[event_df['Event Name'] == 'Module Discharge Under Temp Severe ']['Clearpoint'].iloc[0]
    

# print(sp_war_overtemp)
# print(cp_war_overtemp)
# print(sp_mod_overtemp)
# print(cp_mod_overtemp)
# print(sp_sev_overtemp)
# print(cp_sev_overtemp)
# print(sp_war_undertemp)
# print(cp_war_undertemp)
# print(sp_mod_undertemp)
# print(cp_mod_undertemp)
# print(sp_sev_undertemp)
# print(cp_sev_undertemp)
    
# plot_packtemp.plot_packtemperatures(   
#     time_secs = signal_df['time_sec_can'],
#     tempsensorvals = signal_df[tempsensorlist],
#     can_packcurrent = signal_df['ESS_BM1_iMod_Act_A'], 
#     can_packsoc = signal_df['ESS_BM1_Soc_Est_perc'],
#     sp_war_overtemp = sp_war_overtemp,
#     cp_war_overtemp = cp_war_overtemp,
#     sp_mod_overtemp = sp_mod_overtemp,
#     cp_mod_overtemp = cp_mod_overtemp,
#     sp_sev_overtemp = sp_sev_overtemp,
#     cp_sev_overtemp = cp_sev_overtemp,
#     sp_war_undertemp = sp_war_undertemp,
#     cp_war_undertemp = cp_war_undertemp,
#     sp_mod_undertemp = sp_mod_undertemp,
#     cp_mod_undertemp = cp_mod_undertemp,
#     sp_sev_undertemp = sp_sev_undertemp,
#     cp_sev_undertemp = cp_sev_undertemp,
#     savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )

plot_packtemp.plot_packtemperatures(   
    time_secs = signal_df['time_sec_can'],
    tempsensorvals = signal_df[tempsensorlist],
    can_packcurrent = signal_df['ESS_BM1_iMod_Act_A'], 
    can_packsoc = signal_df['ESS_BM1_Soc_Est_perc'],
    sp_war_overtemp = None,
    cp_war_overtemp = None,
    sp_mod_overtemp = None,
    cp_mod_overtemp = None,
    sp_sev_overtemp = None,
    cp_sev_overtemp = None,
    sp_war_undertemp = None,
    cp_war_undertemp = None,
    sp_mod_undertemp = None,
    cp_mod_undertemp = None,
    sp_sev_undertemp = None,
    cp_sev_undertemp = None,
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )

del tempsensorlist

#%% Estimated brick temperatures vs. time
if (HW_VER >= 2.1):
    print("Plotting estimated brick temperatures ...")
    tempsensorlist = ['BATT_tModule' + str(sensor).zfill(1) for sensor in range(1, 6+1)]
    bricklist = ['BATT_tBrick' + str(brick).zfill(2) for brick in range(1, 14+1)]
    
    plot_packtemp.plot_estbricktemp(
            time_secs = signal_df['time_sec_can'],
            tempsensorvals = signal_df[tempsensorlist],
            estbricktemps = signal_df[bricklist], 
            savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )

#%% Predicted ROCT vs. "true" ROCT
# if (HW_VER >= 2.1) :
#     roctfig, roctfig_roctax = plt.subplots()
#     roctfig_roctax.plot(time_hrs, pad(signal_df['ESS_BM1_roctPerMin_Act_degC']), label = 'Predicted ROCT')

#     roctfig_roctax.set_xlabel('Time (hours)')
#     roctfig_roctax.set_ylabel('Rate of change of temperature (degC/min)')

#%% Temperature vs. SoC
print("Plotting temperature at each SoC ...")
with mpl.rc_context(fname='RA_BMS.rc'):
    soctempfig, soctempfig_tempax = plt.subplots(num = 'Temperatures_SoC')
    for tsensor in range(1, 6+1):
        soctempfig_tempax.plot(
            pad(signal_df.loc[:, 'ESS_BM1_Soc_Est_perc']), 
            pad(signal_df['BATT_tModule' + str(tsensor).zfill(1)]), 
            label = "Sensor " + str(tsensor).zfill(1))

    soctempfig_tempax.set_xlabel("SoC (%)")
    soctempfig_tempax.set_ylabel(r"Temperature ($\degree$C)")

plt.xlim(0, 100)
soctempfig_tempax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)

plt.show()

#%% Plot of other temperature sensor readings
#TODO Limits for ambient temperature
print("Plotting PCB temperatures ...")
import plot_bmstemp

plot_bmstemp.plot_othertemperatures(
    time_secs = signal_df['time_sec_can'], \
    fettemp = pad(signal_df['BATT_tFET']), \
    ambtemp = pad(signal_df['BATT_tAmbient']), \
    shunttemp = pad(signal_df['BATT_tShunt']), \
    prechargetemp = pad(signal_df['BATT_tPrecharge']) if (HW_VER >= 2.1) else None, \
    sp_fetovertemp = cellcalib.event_df.loc[event_df['Event Name'] == 'FET Overheated']['Set Point Value'].iloc[0], \
    cp_fetovertemp = cellcalib.event_df.loc[event_df['Event Name'] == 'FET Overheated']['Clearpoint'].iloc[0], \
    can_packcurrent = signal_df['ESS_BM1_iMod_Act_A'], \
    balance_count = signal_df['ESS_BM1_nBal_Act_count'] if PACK_IN_CHARGE else None, \
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )

#%% Plot actual pack current vs. charge and discharge current limits
print("Plotting pack current limits ...")
import plot_limits

bricklist = ['BATT_socBrick' + str(brick).zfill(2) for brick in range(1, 14+1)]
tempsensorlist = ['BATT_tModule' + str(sensor).zfill(1) for sensor in range(1, 6+1)]

plot_limits.plot_currentlim(
    time_secs = signal_df['time_sec_can'], \
    bricksocs = signal_df[bricklist], \
    tempsensorvals = signal_df[tempsensorlist], \
    idch_inst = pad(signal_df.loc[:, 'BATT_iDchInst']), \
    idch_10s = pad(signal_df.loc[:, 'ESS_BM1_DchgLimit10sec_Max_A']), \
    idch_cont = pad(signal_df.loc[:, 'ESS_BM1_DchgLimitCont_Max_A']), \
    ichg_inst = pad(signal_df.loc[:, 'BATT_iChgInst']), \
    ichg_10s = pad(signal_df.loc[:, 'ESS_BM1_ChgLimit10sec_Max_A']), \
    ichg_cont = pad(signal_df.loc[:, 'ESS_BM1_ChgLimitCont_Max_A']), \
    can_packcurrent = pad(signal_df.loc[:, 'ESS_BM1_iMod_Act_A']), \
    can_packsoc = pad(signal_df.loc[:, 'ESS_BM1_Soc_Est_perc']), \
    can_packvoltage = pad(signal_df['ESS_BMS_Voltage_Act_V']), \
    can_vdch_min = signal_df.loc[:, 'ESS_BM1_DchgLimit_Max_V'], \
    can_vchg_max = signal_df.loc[:, 'ESS_BM1_ChgLimit_Max_V'], \
    can_vcupowerreq = signal_df.loc[:, 'ETS_VCU_VCUDchgPwrExp_Act_W'], \
    can_poweravl = signal_df.loc[:, 'BATT_dch_pwr_available_W'] if DCH_POWAVL else None, \
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )

#%% Plot of CAN current vs. tester current
print("Plotting pack current comparison ...")
import plot_currcomp
if(TSTR_PR):
    plot_currcomp.compare_current(
        time_secs = signal_df['time_sec_can'], \
        can_packcurrent = pad(signal_df['ESS_BM1_iMod_Act_A']), \
        tester_packcurrent = signal_df['Current(A)'], \
        tshunt = pad(signal_df['BATT_tShunt']), \
        savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )
              
# Check capacity from Ah discharged and SoC at begining and end of 
plot_currcomp.plot_ahcomp(
    time_secs = signal_df['time_sec_can'], \
    cancurr_ah = signal_df['cum_Ah_can'], \
    can_capavl = signal_df['ESS_BM1_CapAvailable_Est_Ah'], \
    index_can_cyclebegin = index_can_cyclebegin, \
    tester_ah = signal_df[colname_totalcapacity] if TSTR_PR else None, \
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )

#%% Check estimated SoC against that calculated from CAN reported pack current and battery tester current
# Compute SoC from OCV before and after cycle
# TODO - Fix hysteresis assumptions
print("Computing brick metrics ...")

soccheck_df = pd.DataFrame(columns = ['AhCellCAN_init', 'AhCellCAN_end', \
                                      'voltCell_init', 'socCellOCV_init', 'socCellCAN_init', \
                                      'voltCell_rested', 'socCellOCV_cycleEnd', 'socCellCAN_cycleEnd', 'socCellCAN_corrected', \
                                      'AhCellEst_CANCurr', 'AhCellEst_tester', \
                                      'WhCellCycle', \
                                      'tempCellEst_min', 'tempCellEst_init', 'tempCellEst_max', 'tempCellEst_cycleEnd', 'tempCellEst_rested', \
                                     ], index = range(1, 14+1))

tempsensorlist = ['BATT_tModule' + str(sensor).zfill(1) for sensor in range(1, 6+1)]
temperature_min_val = signal_df.loc[index_tester_cyclebegin: index_tester_cycleend, tempsensorlist].min(axis=1).min(axis=0)
temperature_max_val = signal_df.loc[index_tester_cyclebegin: index_tester_cycleend, tempsensorlist].max(axis=1).max(axis=0)

for brick in range(1, 14+1):
    # Temperature variation
    if(HW_VER >= 2.1):
        soccheck_df.loc[brick, 'tempCellEst_min'] =  signal_df.loc[index_tester_cyclebegin: index_tester_cycleend, 'BATT_tBrick' + str(brick).zfill(2)].min(axis=0)
        soccheck_df.loc[brick, 'tempCellEst_max'] =  signal_df.loc[index_tester_cyclebegin: index_tester_cycleend, 'BATT_tBrick' + str(brick).zfill(2)].max(axis=0)
        soccheck_df.loc[brick, 'tempCellEst_init'] =  strip(signal_df.loc[index_beforecycle, 'BATT_tBrick' + str(brick).zfill(2)])
        soccheck_df.loc[brick, 'tempCellEst_cycleEnd'] =  strip(signal_df.loc[index_tester_cycleend, 'BATT_tBrick' + str(brick).zfill(2)])
        soccheck_df.loc[brick, 'tempCellEst_rested'] = strip(signal_df.loc[index_tester_rested, 'BATT_tBrick' + str(brick).zfill(2)])
        soccheck_df.loc[brick, 'tempCellEst_avg'] = signal_df.loc[index_tester_cyclebegin: index_tester_cycleend, 'BATT_tBrick' + str(brick).zfill(2)].mean(axis=0)
    else:
        soccheck_df.loc[brick, 'tempCellEst_min'] =  temperature_min_val
        soccheck_df.loc[brick, 'tempCellEst_max'] =  temperature_max_val
        # OCV calculation using the max temperature is inferior to using average temperature
        soccheck_df.loc[brick, 'tempCellEst_init'] =  strip(signal_df.loc[index_beforecycle, tempsensorlist]).max(axis = 1)
        soccheck_df.loc[brick, 'tempCellEst_cycleEnd'] =  strip(signal_df.loc[index_tester_cycleend, tempsensorlist]).max(axis = 1)
        soccheck_df.loc[brick, 'tempCellEst_rested'] = strip(signal_df.loc[index_tester_rested, tempsensorlist]).max(axis = 1)
        soccheck_df.loc[brick, 'tempCellEst_avg'] = signal_df.loc[index_tester_rested, tempsensorlist].max(axis = 1).mean(axis=0)

    soccheck_df.loc[brick, 'AhCellCAN_init'] = (1/18)*strip(signal_df.loc[index_beforecycle, 'BATT_capBrick' + str(brick).zfill(2)])
    soccheck_df.loc[brick, 'AhCellCAN_end'] = (1/18)*signal_df['BATT_capBrick' + str(brick).zfill(2)][len(signal_df)-2]

    soccheck_df.loc[brick, 'voltCell_init'] = strip(signal_df.loc[index_beforecycle, 'BATT_vBrick' + str(brick).zfill(2)])
    soccheck_df.loc[brick, 'socCellOCV_init'] = round(100*cellcalib.soc_from_restvolt(soccheck_df.loc[brick, 'tempCellEst_init'], soccheck_df.loc[brick, 'voltCell_init'], 1), 3)
    soccheck_df.loc[brick, 'socCellCAN_init'] = strip(signal_df.loc[index_beforecycle, 'BATT_socBrick' + str(brick).zfill(2)])

    soccheck_df.loc[brick, 'voltCell_cycleEnd'] = strip(signal_df.loc[index_tester_cycleend, 'BATT_vBrick' + str(brick).zfill(2)])
    # SoC from terminal voltage after rest following end of cycle
    soccheck_df.loc[brick, 'voltCell_rested'] = strip(signal_df.loc[index_tester_rested, 'BATT_vBrick' + str(brick).zfill(2)])
    soccheck_df.loc[brick, 'socCellOCV_cycleEnd'] = round(100*cellcalib.soc_from_restvolt(soccheck_df.loc[brick, 'tempCellEst_rested'], soccheck_df.loc[brick, 'voltCell_rested'], 1), 3)
    soccheck_df.loc[brick, 'socCellCAN_cycleEnd'] = strip(signal_df.loc[index_tester_cycleend, 'BATT_socBrick' + str(brick).zfill(2)])
    soccheck_df.loc[brick, 'socCellCAN_corrected'] = signal_df['BATT_socBrick' + str(brick).zfill(2)][len(signal_df)-2]

    # SoH from Ah discharged between two rest voltages
    soccheck_df.loc[brick, 'AhCellEst_CANCurr'] = 100*(1/18)*(strip(signal_df.loc[index_beforecycle, 'cum_Ah_can']) - strip(signal_df.loc[index_tester_cycleend, 'cum_Ah_can']))/(soccheck_df.loc[brick, 'socCellCAN_init'] - soccheck_df.loc[brick, 'socCellCAN_corrected'])
    if TSTR_PR:
        soccheck_df.loc[brick, 'AhCellEst_tester'] = 100*(1/18)*(strip(signal_df.loc[index_beforecycle, colname_totalcapacity]) - strip(signal_df.loc[index_tester_cycleend, colname_totalcapacity]))\
                                                            /(soccheck_df.loc[brick, 'socCellOCV_init'] - soccheck_df.loc[brick, 'socCellOCV_cycleEnd'])
    else:
        soccheck_df.loc[brick, 'AhCellEst_tester'] = 'NA'

    # Energy added / removed
    temp_df = signal_df[['time_sec_can', 'BATT_balStatusBrick' + str(brick).zfill(2)]].copy()
    temp_df['denergy'] = [a*b for a,b in zip(signal_df['BATT_vBrick' + str(brick).zfill(2)], signal_df['ESS_BM1_iMod_Act_A'])]
    temp_df['dbalAh'] = [(1/113)*a*b for a,b in zip(signal_df['BATT_vBrick' + str(brick).zfill(2)], signal_df['BATT_balStatusBrick' + str(brick).zfill(2)])]
    temp_df['dbalWh'] = [(1/113)*a*a*b for a,b in zip(signal_df['BATT_vBrick' + str(brick).zfill(2)], signal_df['BATT_balStatusBrick' + str(brick).zfill(2)])]
    temp_df.dropna(axis = 0, subset = ['denergy', 'dbalAh', 'dbalWh', 'BATT_balStatusBrick' + str(brick).zfill(2)], inplace = True)
    soccheck_df.loc[brick, 'WhCellCycle'] = scipy.integrate.trapz(temp_df['denergy'], x = temp_df['time_sec_can'])/3600

    # Available Ah
    soccheck_df.loc[brick, 'InitialAhfromCANSoC'] = (1/100)*soccheck_df.loc[brick, 'socCellCAN_init']*18*soccheck_df.loc[brick, 'AhCellCAN_init']
    soccheck_df.loc[brick, 'InitialAhfromOCVSoC'] = (1/100)*soccheck_df.loc[brick, 'socCellOCV_init']*18*soccheck_df.loc[brick, 'AhCellCAN_init']
    soccheck_df.loc[brick, 'CycleEndAh'] = (1/100)*soccheck_df.loc[brick, 'socCellCAN_cycleEnd']*18*soccheck_df.loc[brick, 'AhCellCAN_init']
    soccheck_df.loc[brick, 'CorrectedAh'] = (1/100)*soccheck_df.loc[brick, 'socCellCAN_corrected']*18*soccheck_df.loc[brick, 'AhCellCAN_end']

    # Balancing figures
    soccheck_df.loc[brick, 'balMinutesCell'] = scipy.integrate.trapz(temp_df['BATT_balStatusBrick' + str(brick).zfill(2)], x = temp_df['time_sec_can'])/60
    soccheck_df.loc[brick, 'balAhCell'] = scipy.integrate.trapz(temp_df['dbalAh'], x = temp_df['time_sec_can'])/3600
    soccheck_df.loc[brick, 'balWhCell'] = scipy.integrate.trapz(temp_df['dbalWh'], x = temp_df['time_sec_can'])/3600

del temp_df

# Monitor imbalance propagation
InitialMinBrickAh = soccheck_df.loc[:, 'InitialAhfromCANSoC'].min(axis = 0)
InitialMinBrickAh1 = soccheck_df.loc[:, 'InitialAhfromOCVSoC'].min(axis = 0)
FinalMinBrickAh = soccheck_df.loc[:, 'CycleEndAh'].min(axis = 0)
EndMinBrickAh = soccheck_df.loc[:, 'CorrectedAh'].min(axis = 0)

for brick in range(1, 14+1):
    # Coulomb difference from cell with least Ah
    soccheck_df.loc[brick, 'balCoulDiffCellCANSoc_init'] = (soccheck_df.loc[brick, 'InitialAhfromCANSoC'] - InitialMinBrickAh)*3600
    soccheck_df.loc[brick, 'balCoulDiffCellOCVSoc_init'] = (soccheck_df.loc[brick, 'InitialAhfromOCVSoC'] - InitialMinBrickAh1)*3600
    # TODO Imbalance perceived by the BMS at cycle end as per its own metrics - !! balancing continues in rest period
    soccheck_df.loc[brick, 'balCoulDiffCellCANSoc_cycleEnd'] = (soccheck_df.loc[brick, 'CycleEndAh'] - FinalMinBrickAh)*3600
    # Actual imbalance - to be compared against perceived imbalance
    soccheck_df.loc[brick, 'balCoulDiffCellCANSoc_corrected'] = (soccheck_df.loc[brick, 'CorrectedAh'] - EndMinBrickAh)*3600

# soccheck_df.to_excel('key_metrics.xlsx', sheet_name = 'Sheet1', startrow = 2, startcol = 2, header = True)

#%% Charge / Discharge Times
print("Computing pack metrics ...")

df_hist = pd.DataFrame()
df_psoc = pd.DataFrame()
df_ptime = pd.DataFrame()
df_pbal = pd.DataFrame()
df_psohc = pd.DataFrame()
df_psoe = pd.DataFrame()
df_ptemp = pd.DataFrame()

df_csoc = pd.DataFrame()
df_csohc = pd.DataFrame()
df_cbal = pd.DataFrame()
df_ctemp = pd.DataFrame()

#packmetrics_df2 = pd.DataFrame()

# Pack history data
# --------------------------------------------------------------------------------------------------------------------------------
# "Test #", "Battery Serial Number", "Test Description", "Test Temperature"
m_id = 'ESS_BM1'
i_id = ''

df_hist.loc[1, 'test#'] = fieldValues[0]
df_hist.loc[1, 'testDesc'] = fieldValues[2]
df_hist.loc[1, 'testTemp'] = fieldValues[3]
df_hist.loc[1, 'packSN'] = fieldValues[1]

# TODO - Extract HW, App and Cal versions for a single sample
df_hist.loc[1, 'bmsHWVer'] = signal_df.loc[index_tester_cyclebegin, 'BATT_hardwareVersion']

if signal_df.loc[index_tester_cyclebegin, 'BATT_appMajor'] != signal_df.loc[index_tester_cyclebegin, 'BATT_appMajor']:  # is nan
    df_hist.loc[1, 'bmsAppVer'] = str(float('nan'))
else:   # not nan
    df_hist.loc[1, 'bmsAppVer'] = str(int(signal_df.loc[index_tester_cyclebegin, 'BATT_appMajor'])) + '-' \
                                + str(int(signal_df.loc[index_tester_cyclebegin, 'BATT_appMinor'])) + '-' \
                                + str(int(signal_df.loc[index_tester_cyclebegin, 'BATT_appRevision']))

if signal_df.loc[index_tester_cyclebegin, 'BATT_calMajor'] != signal_df.loc[index_tester_cyclebegin, 'BATT_calMajor']:
    df_hist.loc[1, 'bmsAppVer'] = str(float('nan'))
else:
    df_hist.loc[1, 'bmsCalVer'] = str(int(signal_df.loc[index_tester_cyclebegin, 'BATT_calMajor'])) + '-' \
                                + str(int(signal_df.loc[index_tester_cyclebegin, 'BATT_calMinor'])) + '-' \
                                + str(int(signal_df.loc[index_tester_cyclebegin, 'BATT_calRevision']))

df_hist.loc[1, 'accChgCyclesCAN'] = signal_df.loc[index_beforecycle, m_id+'_ChgCycle_Act_count']
df_hist.loc[1, 'Cycle#'] = ' '

if PACK_IN_CHARGE:
    df_hist.loc[1, 'dirCurr'] = 'CHG'
else:
    df_hist.loc[1, 'dirCurr'] = 'DCH'

df_hist.loc[1, 'dateTime_start'] = str(date_tester + (index_tester_cyclebegin - pd.to_datetime(0)))
df_hist.loc[1, 'dateTime_end'] = str(date_tester + (index_tester_cycleend - pd.to_datetime(0)))

# Signal not populated on diagnostic CAN message
# temp_df = pd.DataFrame(data = {'year': signal_df.loc[index_tester_cyclebegin, 'BATT_rtcYear'], \
#                                'month': signal_df.loc[index_tester_cyclebegin, 'BATT_rtcMonth'], \
#                                'day': signal_df.loc[index_tester_cyclebegin, 'BATT_rtcDay'], \
#                                'hour': signal_df.loc[index_tester_cyclebegin, 'BATT_rtcHour'], \
#                                'minute': signal_df.loc[index_tester_cyclebegin, 'BATT_rtcMinutes'], \
#                                'second': signal_df.loc[index_tester_cyclebegin, 'BATT_rtcSeconds']}, \
#                                index = [1])
# df_hist.loc[1, 'dateTimeRTC_start']  = str(pd.to_datetime(temp_df)[1])
# temp_df = pd.DataFrame(data = {'year': signal_df.loc[index_tester_cycleend, 'BATT_rtcYear'], \
#                                'month': signal_df.loc[index_tester_cycleend, 'BATT_rtcMonth'], \
#                                'day': signal_df.loc[index_tester_cycleend, 'BATT_rtcDay'], \
#                                'hour': signal_df.loc[index_tester_cycleend, 'BATT_rtcHour'], \
#                                'minute': signal_df.loc[index_tester_cycleend, 'BATT_rtcMinutes'], \
#                                'second': signal_df.loc[index_tester_cycleend, 'BATT_rtcSeconds']}, \
#                                index = [1])
# df_hist.loc[1, 'dateTimeRTC_end']  = str(pd.to_datetime(temp_df)[1])

df_hist.loc[1, 'dateTimeRTC_start'] = ' '
df_hist.loc[1, 'dateTimeRTC_end'] = ' '

df_hist.loc[1, 'sleepTimeMinutes'] = signal_df.loc[index_beforecycle, 'BATT_timeSleepCycle']/60

# Pack SoC data
# --------------------------------------------------------------------------------------------------------------------------------
df_psoc.loc[1, 'voltPackCAN_init'] = signal_df.loc[index_beforecycle, m_id+'_Voltage_Act_V']
df_psoc.loc[1, 'voltPackCAN_cycleEnd'] = signal_df.loc[index_tester_cycleend, m_id+'_Voltage_Act_V']
df_psoc.loc[1, 'voltPackCAN_rested'] = signal_df.loc[index_tester_rested, m_id+'_Voltage_Act_V']
df_psoc.loc[1, 'restMinutes_cycleEnd'] = (index_tester_rested - index_tester_cycleend).total_seconds()/60

df_psoc.loc[1, 'socPackCAN_init'] = signal_df.loc[index_beforecycle, m_id+'_Soc_Est_perc']
df_psoc.loc[1, 'socPackCAN_cycleEnd'] = signal_df.loc[index_tester_cycleend, m_id+'_Soc_Est_perc']
df_psoc.loc[1, 'socPackCAN_corrected'] = signal_df.loc[index_tester_rested, m_id+'_Soc_Est_perc']

# TODO - Subtract interrupt durations 
df_ptime.loc[1, 'cycleMinutes'] = (index_tester_cycleend - index_tester_cyclebegin).total_seconds()/60

df_ptime.loc[1, 'chgMinutesEst_init'] = signal_df.loc[index_tester_cyclebegin, m_id+'_ChgRemainingTime_Est_min']

# Pack SoHC data
# --------------------------------------------------------------------------------------------------------------------------------
df_psohc.loc[1, 'accChgAhCAN'] = signal_df.loc[index_beforecycle, 'BATT_ahChgTotal']
df_psohc.loc[1, 'accDchAhCAN'] = signal_df.loc[index_beforecycle, 'BATT_ahDchTotal']

df_psohc.loc[1, 'sohcCANPack_init'] = signal_df.loc[index_beforecycle, m_id+'_Sohc_Est_perc']

df_psohc.loc[1, 'AhFullChgPack_init'] = signal_df.loc[index_beforecycle, m_id+'_CapFulCharge_Est_Ah']

df_psohc.loc[1, 'AhAvlPack_init'] = signal_df.loc[index_tester_cyclebegin, m_id+'_CapAvailable_Est_Ah']
df_psohc.loc[1, 'AhAvlPack_cycleEnd'] = signal_df.loc[index_tester_cycleend, m_id+'_CapAvailable_Est_Ah']
df_psohc.loc[1, 'AhCyclePack'] = abs(signal_df.loc[index_tester_cycleend, colname_totalcapacity] \
                                     - signal_df.loc[index_tester_cyclebegin, colname_totalcapacity])

if (~PACK_IN_CHARGE):
    df_psohc.loc[1, 'AhDchPack'] = abs(scipy.integrate.trapz(
        [a*b for a,b in zip((signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current] <= 0),
                             signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current])], 
        x = signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, 'time_sec_can'])/3600)
    
    df_psohc.loc[1, 'AhRegPack'] = abs(scipy.integrate.trapz(
        [a*b for a,b in zip((signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current] > 0),
                             signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current])], 
        x = signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, 'time_sec_can'])/3600)
else:
    df_psohc.loc[1, 'AhDchPack'] = 'NA'
    df_psohc.loc[1, 'AhRegPack'] = 'NA'

# Pack SoE data
# --------------------------------------------------------------------------------------------------------------------------------
df_psoe.loc[1, 'accChgkWhCAN'] = signal_df.loc[index_beforecycle, m_id+'_AccChgEnergy_Est_kWh']
df_psoe.loc[1, 'accDchkWhCAN'] = signal_df.loc[index_beforecycle, m_id+'_AccDchgEnergy_Est_kWh']

df_psoe.loc[1, 'kWhFullChgPack_init'] = signal_df.loc[index_tester_cyclebegin, m_id+'_EnergyFulCharge_Est_kWh']

df_psoe.loc[1, 'kWhAvlPack_init'] = signal_df.loc[index_tester_cyclebegin, m_id+'_EnergyAvailable_Est_kWh']
df_psoe.loc[1, 'kWhAvlPack_cycleEnd'] = signal_df.loc[index_tester_cycleend, m_id+'_EnergyAvailable_Est_kWh']
df_psoe.loc[1, 'kWhCyclePack'] = abs(signal_df.loc[index_tester_cycleend, colname_energy] \
                                     - signal_df.loc[index_tester_cyclebegin, colname_energy])

if (~PACK_IN_CHARGE):
    df_psoe.loc[1, 'kWhDchPack'] = (1/1000)*abs(scipy.integrate.trapz(
        [a*b*c for a,b,c in zip((signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current] <= 0),
                                 signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current],
                                 signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_terminalvoltage])], 
        x = signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, 'time_sec_can'])/3600)
    df_psoe.loc[1, 'kWhRegPack'] = (1/1000)*abs(scipy.integrate.trapz(
        [a*b*c for a,b,c in zip((signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current] > 0),
                                 signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current], \
                                 signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_terminalvoltage])], 
        x = signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, 'time_sec_can'])/3600)
else:
    df_psoe.loc[1, 'kWhDchPack'] = 'NA'
    df_psoe.loc[1, 'kWhRegPack'] = 'NA'

df_psoe.loc[1, 'soePackCAN_init'] = signal_df.loc[index_tester_cyclebegin, m_id+'_Soe_Est_perc']
df_psoe.loc[1, 'soePackCAN_cycleEnd'] = signal_df.loc[index_tester_cycleend, m_id+'_Soe_Est_perc']

if (PACK_IN_CHARGE):
    index_CCend = index_tester_cycleend
    for index in signal_df.index[1:len(signal_df)-1]:
        if ((signal_df.loc[index, m_id+'_ChgMode_St_enum'] == 'CC') and \
            (signal_df.loc[index + pd.Timedelta('1s'), m_id+'_ChgMode_St_enum'] == 'CV')):
            index_CCend = index

    # CV Start SoC
    df_psoc.loc[1, 'chgCVStSocPackCAN'] = signal_df.loc[index_CCend, m_id+'_Soc_Est_perc']
    
    df_ptime.loc[1, 'chgMinutesCC'] = (index_CCend - index_tester_cyclebegin).total_seconds()/60
    df_ptime.loc[1, 'chgMinutesCV'] = (index_tester_cycleend - index_CCend + pd.Timedelta('1s')).total_seconds()/60
    
    df_psohc.loc[1, 'chgAhCC'] = abs(signal_df.loc[index_CCend, colname_totalcapacity] \
                                     - signal_df.loc[index_tester_cyclebegin, colname_totalcapacity])
    df_psohc.loc[1, 'chgAhCV'] = abs(signal_df.loc[index_tester_cycleend, colname_totalcapacity] \
                                     - signal_df.loc[index_CCend + pd.Timedelta('1s'), colname_totalcapacity])
    
    df_psoe.loc[1, 'chgkWhCC'] = abs(signal_df.loc[index_CCend, colname_energy] \
                                     - signal_df.loc[index_tester_cyclebegin, colname_energy])
    df_psoe.loc[1, 'chgkWhCV'] = abs(signal_df.loc[index_tester_cycleend, colname_energy] \
                                     - signal_df.loc[index_CCend + pd.Timedelta('1s'), colname_energy])

else: # Battery not in charge mode
    df_psoc.loc[1, 'chgCVStSocPackCAN'] = 'NA'
    df_ptime.loc[1, 'chgMinutesCC'] = 'NA'
    df_ptime.loc[1, 'chgMinutesCV'] = 'NA'
    df_psohc.loc[1, 'chgAhCC'] = 'NA'
    df_psohc.loc[1, 'chgAhCV'] = 'NA'
    df_psoe.loc[1, 'chgkWhCC'] = 'NA'
    df_psoe.loc[1, 'chgkWhCV'] = 'NA'

bricklist = ['BATT_vBrick' + str(brick).zfill(2) for brick in range(1,14+1)]
# TODO - This probably results in large apparent voltage deltas  
voltagedelta = signal_df[bricklist].max(axis=1) - signal_df[bricklist].min(axis=1)
voltagedelta_max_val = voltagedelta.max(axis = 0)

df_pbal.loc[1, 'balErr_max'] = signal_df[m_id+'_BalErr_Act_perc'].max()
df_pbal.loc[1, 'balVoltDelta_init'] = voltagedelta[index_beforecycle]
df_pbal.loc[1, 'balVoltDelta_max'] = voltagedelta_max_val
df_pbal.loc[1, 'balCount_max'] = signal_df[m_id+'_nBal_Act_count'].max()

# Pack temperature data
# --------------------------------------------------------------------------------------------------------------------------------
df_ptemp.loc[1, 'currPack_avg'] = signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current].mean(axis=0)
df_ptemp.loc[1, 'currPack_rms'] = np.sqrt(sum(n*n for n in signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current])\
                                          /len(signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current]))
df_ptemp.loc[1, 'curPack_max'] = signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current].max(axis=0)
df_ptemp.loc[1, 'curPack_min'] = signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current].min(axis=0)

df_ptemp.loc[1, 'impPackBoL'] = signal_df.loc[index_beforecycle, m_id+'_InitImpedance_Act_mohm']
df_ptemp.loc[1, 'sohrPackCAN_init'] = signal_df.loc[index_beforecycle, m_id+'_Sohr_Est_perc']
df_ptemp.loc[1, 'sohrPackCAN_min'] = signal_df.loc[:, m_id+'_Sohr_Est_perc'].min(axis=0)
df_ptemp.loc[1, 'sohrPackCAN_max'] = signal_df.loc[:, m_id+'_Sohr_Est_perc'].max(axis=0)

# Compute min and max temperatures among all readings
tempsensorlist = ['BATT_tModule' + str(sensor).zfill(1) for sensor in range(1, 6+1)]

df_ptemp.loc[1, 'tempPackMax_init'] = signal_df.loc[index_tester_cyclebegin, tempsensorlist].max(axis=0)
df_ptemp.loc[1, 'tempPackMax_min'] = signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, tempsensorlist].min(axis=1).min(axis=0)
df_ptemp.loc[1, 'tempPackMax_max'] = signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, tempsensorlist].max(axis=1).max(axis=0)
df_ptemp.loc[1, 'tempPackDelta_max'] = (signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, tempsensorlist].max(axis=1) \
                                        - signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, tempsensorlist].min(axis=1)).max(axis=0)
df_ptemp.loc[1, 'tempPackMax_cycleEnd'] = signal_df.loc[index_tester_cycleend, tempsensorlist].max(axis=0)
df_ptemp.loc[1, 'tempPackMax_avg'] = signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, tempsensorlist].mean(axis=1).mean(axis=0)
df_ptemp.loc[1, 'tempPackMax_rested'] = signal_df.loc[index_tester_rested, tempsensorlist].max(axis=0)

df_ptemp.loc[1, 'roctPack_max'] = signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, m_id+'_roctPerMin_Act_degC'].max(axis=0)

df_ptemp.loc[1, 'tempFET_init'] = signal_df.loc[index_tester_cyclebegin, 'BATT_tFET']
df_ptemp.loc[1, 'tempFET_max'] = signal_df['BATT_tFET'].max()
df_ptemp.loc[1, 'tempPCB_init'] = signal_df.loc[index_beforecycle, 'BATT_tAmbient']
df_ptemp.loc[1, 'tempPCB_max'] = signal_df['BATT_tAmbient'].max()

if PACK_IN_CCDISCH:
    # Discharge current is negative by convention
    threshold_disch_curr = signal_df.loc[index_can_cyclebegin + pd.Timedelta('1S'), colname_current] + 0.1
    index_fullcurrdischend = index_tester_cycleend
    for index in signal_df.index[1:len(signal_df)-1]:
        if (strip(signal_df.loc[index, colname_current]) < threshold_disch_curr) \
            and (strip(signal_df.loc[index + pd.Timedelta('1s'), colname_current]) > threshold_disch_curr):
            index_fullcurrdischend = index
            
    # Derate start SoC and temperature
    df_ptime.loc[1, 'dchMinutesDerated'] = (index_tester_cycleend - index_fullcurrdischend).total_seconds()/60
    
    df_psohc.loc[1, 'dchAhFullCurr'] = -(signal_df.loc[index_fullcurrdischend, colname_totalcapacity] \
                                         - signal_df.loc[index_tester_cyclebegin, colname_totalcapacity])
    df_psohc.loc[1, 'dchAhDerated'] = -(signal_df.loc[index_tester_cycleend, colname_totalcapacity] \
                                        - signal_df.loc[index_fullcurrdischend + pd.Timedelta('1s'), colname_totalcapacity])
    
    df_psoe.loc[1, 'dchkWhFullCurr'] = -(signal_df.loc[index_fullcurrdischend, colname_energy] \
                                         - signal_df.loc[index_tester_cyclebegin, colname_energy])
    df_psoe.loc[1, 'dchkWhDerated'] = -(signal_df.loc[index_tester_cycleend, colname_energy] \
                                        - signal_df.loc[index_fullcurrdischend + pd.Timedelta('1s'), colname_energy])
    
    df_psoc.loc[1, 'dchSocDerate'] = signal_df.loc[index_fullcurrdischend, m_id+'_Soc_Est_perc']
    
    tempsensorlist = ['BATT_tModule' + str(sensor).zfill(1) for sensor in range(1, 6+1)]
    df_ptemp.loc[1, 'dchTempDerate'] = signal_df.loc[index_fullcurrdischend, tempsensorlist].max(axis=0)

else:
    df_ptime.loc[1, 'dchMinutesDerated'] = 'NA'
    
    df_psohc.loc[1, 'dchAhFullCurr'] = 'NA'
    df_psohc.loc[1, 'dchAhDerated'] = 'NA'
    
    df_psoe.loc[1, 'dchkWhFullCurr'] = 'NA'
    df_psoe.loc[1, 'dchkWhDerated'] = 'NA'
    
    df_psoc.loc[1, 'dchSocDerate'] = 'NA'
    
    df_ptemp.loc[1, 'dchTempDerate'] = 'NA'


df_psohc.loc[1, 'effCoul'] = ' '     # To be computed in the excel sheet
df_psohc.loc[1, 'accChgAhCAN_end'] = signal_df.loc[index_tester_rested, 'BATT_ahChgTotal']
df_psohc.loc[1, 'accDchAhCAN_end'] = signal_df.loc[index_tester_rested, 'BATT_ahDchTotal']
df_psoe.loc[1, 'effEner'] = ' '     # To be computed in the excel sheet
df_psoe.loc[1, 'accChgkWhCAN_end'] = signal_df.loc[index_tester_rested, m_id+'_AccChgEnergy_Est_kWh']
df_psoe.loc[1, 'accDchkWhCAN_end'] = signal_df.loc[index_tester_rested, m_id+'_AccDchgEnergy_Est_kWh']

# Populate cell level metrics
for brick in range(1, 14+1):
    df_csoc.loc[1, 'voltCell_init_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'voltCell_init']
    df_csoc.loc[1, 'voltCell_cycleEnd_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'voltCell_cycleEnd']
    df_csoc.loc[1, 'voltCell_rested_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'voltCell_rested']
    df_csoc.loc[1, 'socCellOCV_init_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'socCellOCV_init']
    df_csoc.loc[1, 'socCellCAN_init_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'socCellCAN_init']
    df_csoc.loc[1, 'socCellCAN_cycleEnd_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'socCellCAN_cycleEnd']
    df_csoc.loc[1, 'socCellOCV_cycleEnd_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'socCellOCV_cycleEnd']
    df_csoc.loc[1, 'socCellCAN_corrected_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'socCellCAN_corrected']

    df_csohc.loc[1, 'AhCellCAN_init_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'AhCellCAN_init']
    # df_csohc.loc[1, 'AhCellCAN_end_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'AhCellCAN_end']
    df_csohc.loc[1, 'AhCellEst_CANCurr_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'AhCellEst_CANCurr']
    df_csohc.loc[1, 'AhCellEst_tester_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'AhCellEst_tester']
    df_csohc.loc[1, 'WhCellCycle_CANCurr_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'WhCellCycle']

    df_cbal.loc[1, 'balMinutesCell_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'balMinutesCell']
    df_cbal.loc[1, 'balAhCell_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'balAhCell']
    df_cbal.loc[1, 'balWhCell_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'balWhCell']
    df_cbal.loc[1, 'balCoulDiffCellCANSoc_init_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'balCoulDiffCellCANSoc_init']
    df_cbal.loc[1, 'balCoulDiffCellOCVSoc_init_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'balCoulDiffCellOCVSoc_init']
    df_cbal.loc[1, 'balCoulDiffCellCANSoc_cycleEnd' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'balCoulDiffCellCANSoc_cycleEnd']
    df_cbal.loc[1, 'balCoulDiffCellCANSoc_corrected_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'balCoulDiffCellCANSoc_corrected']
    #df_cbal.loc[1, 'balCoulDiffCellOCVSoc_cycleEnd_c' + str(brick).zfill(2)] = ''

    df_ctemp.loc[1, 'resCellCAN_init_c' + str(brick).zfill(2)] = signal_df.loc[index_beforecycle, 'BATT_resBrick' + str(brick).zfill(2)]
    df_ctemp.loc[1, 'resCellCAN_min_c' + str(brick).zfill(2)] = signal_df.loc[:, 'BATT_resBrick' + str(brick).zfill(2)].min(axis=0)
    df_ctemp.loc[1, 'resCellCAN_max_c' + str(brick).zfill(2)] = signal_df.loc[:, 'BATT_resBrick' + str(brick).zfill(2)].max(axis=0)
    df_ctemp.loc[1, 'resCellCAN_avg_c' + str(brick).zfill(2)] = signal_df.loc[:, 'BATT_resBrick' + str(brick).zfill(2)].mean(axis=0)

    df_ctemp.loc[1, 'tempCellEst_init_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'tempCellEst_init']
    df_ctemp.loc[1, 'tempCellEst_min_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'tempCellEst_min']
    df_ctemp.loc[1, 'tempCellEst_max_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'tempCellEst_max']
    df_ctemp.loc[1, 'tempCellEst_cycleEnd_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'tempCellEst_cycleEnd']
    df_ctemp.loc[1, 'tempCellEst_avg_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'tempCellEst_avg']
    df_ctemp.loc[1, 'tempCellEst_rested_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'tempCellEst_rested']

# packmetrics_df.to_excel('key_metrics2.xlsx', sheet_name = 'Sheet1', startrow = 2, startcol = 2, header = True)

book = load_workbook('BatteryPack_CycleLife_TestSummary.xlsx')
writer = pd.ExcelWriter('BatteryPack_CycleLife_TestSummary.xlsx', engine='openpyxl')
writer.book = book
writer.sheets = {ws.title: ws for ws in book.worksheets}

HEADER_WR = False

df_hist.to_excel(
    writer, 
    sheet_name='PackHistory', startrow=writer.sheets['PackHistory'].max_row, 
    index = False, header = HEADER_WR)

df_hist[['test#']].join(df_psoc.join(df_ptime).join(df_pbal)).to_excel(
    writer, 
    sheet_name='PackSoC', startrow=writer.sheets['PackSoC'].max_row, 
    index = False, header = HEADER_WR)

df_hist[['test#']].join(df_psohc).to_excel(
    writer, 
    sheet_name='PackSoHC', startrow=writer.sheets['PackSoHC'].max_row, 
    index = False, header = HEADER_WR)

df_hist[['test#']].join(df_psoe).to_excel(
    writer, 
    sheet_name='PackSoE', startrow=writer.sheets['PackSoE'].max_row, 
    index = False, header = HEADER_WR)

df_hist[['test#']].join(df_ptemp).to_excel(
    writer, 
    sheet_name='PackTemp', startrow=writer.sheets['PackTemp'].max_row, 
    index = False, header = HEADER_WR)

templist = ['voltCell_init_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['voltCell_cycleEnd_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['voltCell_rested_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['socCellOCV_init_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['socCellCAN_init_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['socCellCAN_cycleEnd_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['socCellOCV_cycleEnd_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['socCellCAN_corrected_c' + str(brick).zfill(2) for brick in range(1, 14+1)]
df_hist[['test#']].join(df_csoc[templist]).transpose().to_excel(
    writer, 
    sheet_name='CellSoC', 
    startrow=writer.sheets['CellSoC'].min_row-1, 
    startcol=writer.sheets['CellSoC'].max_column, 
    index = HEADER_WR, header = False)

templist = ['AhCellCAN_init_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['AhCellEst_CANCurr_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['AhCellEst_tester_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['WhCellCycle_CANCurr_c' + str(brick).zfill(2) for brick in range(1, 14+1)]
df_hist[['test#']].join(df_csohc[templist]).transpose().to_excel(
    writer, 
    sheet_name='CellSoHC', 
    startrow=writer.sheets['CellSoHC'].min_row-1, 
    startcol=writer.sheets['CellSoHC'].max_column, 
    index = HEADER_WR, header = False)

templist = ['balMinutesCell_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['balAhCell_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['balWhCell_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['balCoulDiffCellCANSoc_init_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['balCoulDiffCellOCVSoc_init_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['balCoulDiffCellCANSoc_cycleEnd' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['balCoulDiffCellCANSoc_corrected_c' + str(brick).zfill(2) for brick in range(1, 14+1)]
df_hist[['test#']].join(df_cbal[templist]).transpose().to_excel(
    writer, 
    sheet_name='CellBal', 
    startrow=writer.sheets['CellBal'].min_row-1, 
    startcol=writer.sheets['CellBal'].max_column, 
    index = HEADER_WR, header = False)

templist = ['resCellCAN_init_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['resCellCAN_min_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['resCellCAN_max_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['resCellCAN_avg_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['tempCellEst_init_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['tempCellEst_min_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['tempCellEst_max_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['tempCellEst_cycleEnd_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['tempCellEst_avg_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['tempCellEst_rested_c' + str(brick).zfill(2) for brick in range(1, 14+1)]
df_hist[['test#']].join(df_ctemp[templist]).transpose().to_excel(
    writer, 
    sheet_name='CellTemp', 
    startrow=writer.sheets['CellTemp'].min_row-1, 
    startcol=writer.sheets['CellTemp'].max_column, 
    index = HEADER_WR, header = False)

# Error flags
res_ws = writer.sheets['ErrorLog']
r_idx = writer.sheets['ErrorLog'].max_row+1

df_hist[['test#']].to_excel(
    writer, 
    sheet_name='ErrorLog', startrow=writer.sheets['ErrorLog'].max_row, 
    index = False, header = HEADER_WR)

c_idx = 2
res_ws.cell(row=r_idx, column=c_idx, value='Time')
res_ws.cell(row=r_idx, column=c_idx+1, value='RelTime')
res_ws.cell(row=r_idx, column=c_idx+2, value='ErrorFlag')
res_ws.merge_cells(start_row=r_idx, start_column=c_idx+2, end_row=r_idx, end_column=c_idx+4)
res_ws.cell(row=r_idx, column=c_idx+5, value='State')

r_idx += 1
for error in error_df:
    c_idx = 2
    res_ws.cell(row=r_idx, column=c_idx, value=error[0])
    c_idx += 1
    res_ws.cell(row=r_idx, column=c_idx, value=error[3])
    c_idx += 1
    res_ws.merge_cells(start_row=r_idx, start_column=c_idx, end_row=r_idx, end_column=c_idx+2)
    res_ws.cell(row=r_idx, column=c_idx, value=error[1])
    c_idx += 3
    res_ws.cell(row=r_idx, column=c_idx, value=error[2])
    r_idx += 1


# State change log
res_ws = writer.sheets['StateLog']

r_idx = writer.sheets['StateLog'].max_row+1
write_row = r_idx + 1

df_hist[['test#']].to_excel(
    writer, 
    sheet_name='StateLog', startrow=writer.sheets['StateLog'].max_row, 
    index = False, header = HEADER_WR)

c_idx = 2
col_offset = 0
for key in statechange_df.keys():
    res_ws.cell(row=r_idx, column=c_idx+col_offset, value=key)
    res_ws.merge_cells(start_row=r_idx, start_column=c_idx+col_offset, end_row=r_idx, end_column=c_idx+col_offset+2)
    col_offset += 3

col_offset = 0
for key in statechange_df.keys():
    r_idx = write_row
    for state in statechange_df[key]:
        c_idx = 2 + col_offset
        res_ws.cell(row=r_idx, column=c_idx, value=state[0])
        res_ws.cell(row=r_idx, column=c_idx+1, value=state[2])
        res_ws.cell(row=r_idx, column=c_idx+2, value=state[3])
        r_idx += 1
    col_offset += 3

writer.save()

del templist

#%% Plot of brick SoCs and pack SoC
print("Plotting SoC comparison ...")
import plot_soccomp

bricklist = ['BATT_socBrick' + str(brick).zfill(2) for brick in range(1, 14+1)]

plot_soccomp.plot_socs(
    time_secs = signal_df['time_sec_can'], \
    can_packvolt = signal_df.loc[:, 'ESS_BM1_Voltage_Act_V'], \
    bricksocs = signal_df[bricklist], \
    can_packsoc = pad(signal_df.loc[:, 'ESS_BM1_Soc_Est_perc']), \
    soctrim_min = (signal_df.loc[:, 'BATT_soc_trim_min']) if SOC_TRIM else None, \
    soctrim_max = (signal_df.loc[:, 'BATT_soc_trim_max']) if SOC_TRIM else None, \
    trimmed_packsoc = (signal_df.loc[:, 'PackSoC_Trimmed'] if SOC_TRIM else None), \
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )
    
#%% Check estimated SoC against that calculated from CAN reported pack current and battery tester current
print("Plotting Ah comparison ...")
bricklist = ['BATT_socBrick' + str(brick).zfill(2) for brick in range(1, 14+1)]

plot_soccomp.plot_compsoc(
    time_secs = signal_df['time_sec_can'], \
    bricksocs = signal_df[bricklist], \
    init_ocvsocs = soccheck_df.loc[:, 'socCellOCV_init'], \
    init_cellcaps = soccheck_df.loc[:, 'AhCellCAN_init'], \
    can_ah = signal_df['cum_Ah_can'], \
    tester_ah = signal_df[colname_totalcapacity] if TSTR_PR else None, \
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )

#%% Check estimated SoE against actual energy available
print("Plotting energy comparison ...")
import plot_energyavl   
    
plot_energyavl.plot_energyavl(
    time_secs = signal_df['time_sec_can'],
    can_fullchgenergy = signal_df['ESS_BM1_EnergyFulCharge_Est_kWh'],
    can_energyavl = signal_df['ESS_BM1_EnergyAvailable_Est_kWh'],
    tester_kwh = signal_df[colname_energy],
    index_rested = index_tester_rested,
    can_packvolt = pad(signal_df['ESS_BM1_Voltage_Act_V']),
    can_packcurrent = signal_df['ESS_BM1_iMod_Act_A'],
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )

#%% Plot estimated cell capacities
print("Plotting cell capacities ...")
import plot_cellparams

bricklist = ['BATT_capBrick' + str(brick).zfill(2) for brick in range(1, 14+1)]

plot_cellparams.plot_cellcap(
    time_secs = signal_df['time_sec_can'], \
    brickcaps = signal_df[bricklist], \
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )

#%% Plot estimated cell resistances
print("Plotting cell resistances ...")
bricklist = ['BATT_resBrick' + str(brick).zfill(2) for brick in range(1, 14+1)]

plot_cellparams.plot_cellres(
    time_secs = signal_df['time_sec_can'], \
    brickres = signal_df[bricklist], \
    packres = pad(signal_df['ESS_BM1_CurrImpedance_Act_mohm']), \
    can_packsoc = pad(signal_df.loc[:, 'ESS_BM1_Soc_Est_perc']), \
    packtemp = pad(signal_df.loc[:, 'BATT_tModule1']), \
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix)

# Check resistance from BM1 Health and BM1 SoX
#['ESS_BM1_EnergyFulCharge_Est_kWh', 'ESS_BM1_CapFulCharge_Est_Ah', 'ESS_BM1_InitImpedance_Act_mohm', 'ESS_BM1_CurrImpedance_Act_mohm', 'ESS_BM1_ChgCycle_Act_count']

#%% Diagnostics measurements on the FETs
print("Plotting FET diagnostic measurements ...")
with mpl.rc_context(fname='RA_BMS.rc'):
    fetdiagfig, fetdiagfig_currax = plt.subplots(num = 'FET current measurement')
    fetdiagfig_currax.plot(time_hrs, signal_df.loc[:, 'BATT_fetChgDiagIMeas'], label = "ChgFET DiagI")
    fetdiagfig_currax.plot(time_hrs, signal_df.loc[:, 'BATT_fetDsgDiagIMeas'], label = "DsgFET DiagI")
    #fetdiagfig_currax.plot(time_hrs, (signal_df.loc[:, 'BATT_fetChgDiagVMeasPrime'] - signal_df.loc[:, 'BATT_fetChgDiagVMeas'])/signal_df.loc[:, 'BATT_fetChgDiagIMeas'], label = "ChgFET I Comp")

    fetdiagfig_currax.set_xlabel("Time (sec)")
    fetdiagfig_currax.set_ylabel("Current (A)")

with mpl.rc_context(rcdict02):
    fetdiagfig_voltax = fetdiagfig_currax.twinx()
    fetdiagfig_voltax.plot(time_hrs, signal_df.loc[:, 'BATT_fetChgDiagVMeas'], label = "ChgFET DiagV")
    fetdiagfig_voltax.plot(time_hrs, signal_df.loc[:, 'BATT_fetChgDiagVMeasPrime'], label = "ChgFET DiagVPrime")
    fetdiagfig_voltax.plot(time_hrs, signal_df.loc[:, 'BATT_fetDsgDiagVMeas'], label = "DsgFET DiagV")
    fetdiagfig_voltax.plot(time_hrs, signal_df.loc[:, 'BATT_fetDsgDiagVMeasPrime'], label = "DsgFET DiagVPrime")
    fetdiagfig_voltax.set_ylabel("Voltage (V)")

plt.xlim((min(time_hrs), max(time_hrs)))
fetdiagfig_currax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)
lines, labels = fetdiagfig_currax.get_legend_handles_labels()
lines2, labels2 = fetdiagfig_voltax.get_legend_handles_labels()
fetdiagfig_currax.legend(lines + lines2, labels + labels2)
plt.title("FET Diagnostic Measurements")
fetdiagfig.set_size_inches(16, 12)
plt.show()
fetdiagfig.savefig(os.path.join(fig_dir, fname_prefix + '_FET_Diags.png'),
        format='png',
        dpi=400,
        bbox_inches='tight')

#%% Raw voltage measurements from the ADC
#TODO
print("Plotting ADC raw measurements ...")
with mpl.rc_context(fname='RA_BMS.rc'):
    adcmeasfig, adcmeasfig_voltax = plt.subplots(num = 'Raw ADC Measurements')
    adcmeasfig_voltax.plot(time_hrs, signal_df.loc[:, 'BATT_boardADC_PACK'], label = "Pack")
    adcmeasfig_voltax.plot(time_hrs, signal_df.loc[:, 'BATT_boardADC_COMMON_DRAIN'], label = "Common Drain")
    adcmeasfig_voltax.plot(time_hrs, signal_df.loc[:, 'BATT_boardADC_LOAD'], label = "Load")
    adcmeasfig_voltax.plot(time_hrs, signal_df.loc[:, 'BATT_boardADC_PACK_PF'], label = "Pack PF")
    adcmeasfig_voltax.set_xlabel("Time (sec)")
    adcmeasfig_voltax.set_ylabel("Voltage (V)")

plt.xlim((min(time_hrs), max(time_hrs)))
adcmeasfig_voltax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)
lines, labels = adcmeasfig_voltax.get_legend_handles_labels()
adcmeasfig_voltax.legend(lines, labels)
plt.title("ADC Raw Measurements")
adcmeasfig.set_size_inches(16, 12)
plt.show()
adcmeasfig.savefig(os.path.join(fig_dir, fname_prefix + '_ADC_Raw.png'),
        format='png',
        dpi=400,
        bbox_inches='tight')

#%% Power supply voltage measurements
#TODO


#%%

#%% Multi-pack operation parameters
#TODO
# Detected parallel packs
# Connected parallel packs

# BMS Overview - Voltage
# BMS TermSt - Load V
# Charge / discharge current and voltage limits

#%% Voltage rank analysis

# #%% Ah discharged per cell by balancing
# with mpl.rc_context(fname='RA_BMS.rc'):
#     fig2, balancingStat_ax = plt.subplots()

#     for brick in range(1, 14+1):
#         balancingStat_ax.plot(time_hrs, signal_df.loc[:, 'BATT_balStatusBrick' + str(brick).zfill(2)], label = "Brick " + str(brick).zfill(2), linewidth = 0.5)

#     #balancingStat_ax.plot(time_hrs, signal_df.loc[:, 'ESS_BM1_nBal_Act_count'])
#     balancingStat_ax.set_xlabel("Time (hrs)")
#     balancingStat_ax.set_ylabel("Balancing FET Status")
#     plt.xlim((min(time_hrs), max(time_hrs)))
#     plt.legend()

# balancingStat_ax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)

# baltime_secs = [0 for i in range(1, 14+1)]
# for index in signal_df.index:
#     for brick in range(1, 14+1):
#         if(signal_df.loc[index, 'BATT_balStatusBrick' + str(brick).zfill(2)] == 1):
#             baltime_secs[brick - 1] = baltime_secs[brick - 1] + 1


# ballist = ['BATT_balStatusBrick' + str(brick).zfill(2) for brick in range(1, 14+1)]
# signal_df[ballist].astype(bool).sum(axis=0)/3600

#%% Brief Report Generation for Cycle Life Test
#TODO



