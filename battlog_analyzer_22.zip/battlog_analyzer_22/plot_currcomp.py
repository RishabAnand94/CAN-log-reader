# -*- coding: utf-8 -*-
"""
Created on Mon Feb 15 17:24:38 2021

@author: ranand
"""

import sys
if 'mpl' not in sys.modules:
    import matplotlib as mpl 
if 'plt' not in sys.modules:
    import matplotlib.pyplot as plt
# if 'os' not in sys.modules:
#     import os

import os


rcdict02 = {'ytick.labelsize': 14, 'axes.labelsize': 14}

def compare_current(
    time_secs,
    can_packcurrent,
    can_modcurrent = None,
    tester_packcurrent = None,
    tshunt = None,
    savefig = False, fig_dir = '', fname_prefix = '' ):
    
    time_hrs = [tsec/3600 for tsec in time_secs]
    
    with mpl.rc_context(fname='RA_BMS.rc'):
        currentcompfig, currentcompfig_currax = plt.subplots(num = 'Current_Val_Comparison')
        currentcompfig_currax.plot(time_hrs, can_packcurrent, label = "Pack Current - CAN")
        if can_modcurrent is not None:
            currentcompfig_currax.plot(time_hrs, can_modcurrent, label = "Module Current - CAN")
        currentcompfig_currax.plot(time_hrs, tester_packcurrent, label = "Tester Current")

        currentcompfig_currax.set_xlabel("Time (hours)")
        currentcompfig_currax.set_ylabel("Current (A)")

    # Compute difference in tester and CAN current
    deltacurr = tester_packcurrent - can_packcurrent

    with mpl.rc_context(rcdict02):
        currentcompfig_currerrax = currentcompfig_currax.twinx()
        currentcompfig_currerrax.plot(time_hrs, deltacurr, label = "Current Difference", color = 'black')
        #plt.ylim(-0.5, 0.5)
        plt.ylim(-3, 0.5)
        currentcompfig_currerrax.set_ylabel("Current Difference (A)")
        currentcompfig_currerrax.grid(None)

        currentcompfig_tshuntax = currentcompfig_currax.twinx()
        currentcompfig_tshuntax.plot(time_hrs, tshunt, label = "Shunt Temperature")
        currentcompfig_tshuntax.set_ylabel('Shunt Temperature')
        currentcompfig_tshuntax.spines['right'].set_position(('outward', 60))
        currentcompfig_tshuntax.grid(None)

    with mpl.rc_context(fname='RA_BMS.rc'):
        lines, labels = currentcompfig_currax.get_legend_handles_labels()
        lines2, labels2 = currentcompfig_currerrax.get_legend_handles_labels()
        lines3, labels3 = currentcompfig_tshuntax.get_legend_handles_labels()
        currentcompfig_currax.legend(lines + lines2 + lines3, labels + labels2 + labels3)

    plt.xlim((min(time_hrs), max(time_hrs)))
    currentcompfig_currax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)

    plt.title("CAN Current Accuracy Comparison")
    currentcompfig.set_size_inches(16, 12)
    plt.show()
    
    if savefig:
        currentcompfig.savefig(os.path.join(fig_dir, fname_prefix + '_Comparison_Current.png'),
                format='png',
                dpi=400,
                bbox_inches='tight')
        
def plot_ahcomp(
    time_secs, \
    cancurr_ah, \
    can_capavl = None, \
    index_can_cyclebegin = None, \
    tester_ah = None, \
    savefig = False, fig_dir = '', fname_prefix = ''    ):
    
    time_hrs = [tsec/3600 for tsec in time_secs]
    
    with mpl.rc_context(fname='RA_BMS.rc'):
        cumAhfig, cumAhfig_Ahax = plt.subplots(num = 'Ah_Comparison')
        cumAhfig_Ahax.plot(time_hrs, cancurr_ah, label = 'Ah from CAN current')
        if tester_ah is not None:
            cumAhfig_Ahax.plot(time_hrs, tester_ah, label = 'Ah from tester current')
        if can_capavl is not None:
            cumAhfig_Ahax.plot(time_hrs, (can_capavl - can_capavl[index_can_cyclebegin]), label = 'Ah from available capacity signal')
    
        cumAhfig_Ahax.set_xlabel("Time (hours)")
        cumAhfig_Ahax.set_ylabel("Accumulated Capacity (Ah)")
    
    if tester_ah is not None:
        with mpl.rc_context(rcdict02):
            cumAhfig_Ahdiffax = cumAhfig_Ahax.twinx()
            cumAhfig_Ahdiffax.plot(time_hrs, tester_ah - cancurr_ah, label = 'Ah difference (Tester and CAN current)')
            if can_capavl is not None:
                cumAhfig_Ahdiffax.plot(time_hrs, tester_ah - (can_capavl - can_capavl[index_can_cyclebegin]), label = 'Ah difference (Tester and CAN avl. cap.)')
            # cumAhfig_Ahdiffax.plot(time_hrs, cum_Ah_can - (signal_df['ESS_BM1_CapAvailable_Est_Ah'] - signal_df['ESS_BM1_CapAvailable_Est_Ah'][0]), label = 'Ah difference (CAN avl. cap. and tester)')
            cumAhfig_Ahdiffax.set_ylabel("Difference in Accumulated Capacity (Ah)")
            cumAhfig_Ahdiffax.grid(None)
    
    with mpl.rc_context(fname='RA_BMS.rc'):
        lines, labels = cumAhfig_Ahax.get_legend_handles_labels()
        if tester_ah is not None:
            lines2, labels2 = cumAhfig_Ahdiffax.get_legend_handles_labels()
            cumAhfig_Ahax.legend(lines + lines2, labels + labels2)
        else:
            cumAhfig_Ahax.legend(lines, labels)
    
    plt.xlim((min(time_hrs), max(time_hrs)))
    cumAhfig_Ahax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)
    
    plt.title("Accumulated Ah Comparison")
    cumAhfig.set_size_inches(16, 12)
    plt.show()
    
    if savefig:
        cumAhfig.savefig(os.path.join(fig_dir, fname_prefix + '_Comparison_Ah.png'),
                format='png',
                dpi=400,
                bbox_inches='tight')
