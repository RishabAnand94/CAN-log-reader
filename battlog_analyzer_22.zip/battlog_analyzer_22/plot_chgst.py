# -*- coding: utf-8 -*-
"""
Created on Mon Jan 25 15:46:10 2021

@author: ranand
"""

def plot_charge_state(
    time_secs, 
    bms_chgen,
    bm1_chgen,
    bms_chmode,
    bm1_chmode,
    brickvoltages, 
    can_packcurrent, 
    savefig = False, fig_dir = '', fname_prefix = ''):
    """
    

    Parameters
    ----------
    time_sec : TYPE
        DESCRIPTION.
    bms_chmode : TYPE
        DESCRIPTION.
    brickvoltages : TYPE
        DESCRIPTION.
    can_packcurrent : TYPE
        DESCRIPTION.
    savefig : TYPE, optional
        DESCRIPTION. The default is True.
    fig_dir : TYPE, optional
        DESCRIPTION. The default is ''.
    fname_prefix : TYPE, optional
        DESCRIPTION. The default is ''.

    Returns
    -------
    None.

    """
    
    import sys
    if 'mpl' not in sys.modules:
        import matplotlib as mpl 
    if 'plt' not in sys.modules:
        import matplotlib.pyplot as plt
    # if 'os' not in sys.modules:
    #     import os
    #     print('os not found')
    if 'pd' not in sys.modules:
        import pandas as pd
        
    import os
    
    rcdict02 = {'ytick.labelsize': 14, 'axes.labelsize': 14}
    
    temp_df = pd.concat([time_secs, bms_chgen, bm1_chgen, bms_chmode, bm1_chmode], axis = 1)
    # Drop rows with missing BMS charge mode values 
    temp_df.dropna(axis = 0, subset = [bms_chmode.name], inplace = True)
    
    brickvoltage_max_vals = brickvoltages.max(axis=1)
        
    with mpl.rc_context(fname='RA_BMS.rc'):
        chgstfig, chgstfig_voltax = plt.subplots(num = 'Charge_State')
        chgstfig_voltax.plot(
            [i/3600 for i in time_secs], 
            brickvoltage_max_vals, 
            label = 'Max Brick Voltage')
        chgstfig_voltax.set_xlabel('Time (hours)')
        chgstfig_voltax.set_ylabel('Max Brick Voltage (V)')
        
        # Another axis on the left to plot pack current
        chgstfig_currax = chgstfig_voltax.twinx()
        chgstfig_currax.spines["left"].set_position(("axes", -0.07))
        chgstfig_currax.spines["left"].set_visible(True)
        chgstfig_currax.yaxis.set_label_position('left')
        chgstfig_currax.yaxis.set_ticks_position('left')
        chgstfig_currax.plot(
            [i/3600 for i in time_secs], 
            can_packcurrent, 
            label = "Pack Current - CAN", 
            color = 'black') 
        chgstfig_currax.set_ylabel("Pack Current (A)")
        chgstfig_currax.grid(False)
    
    with mpl.rc_context(rcdict02): 
        chgstfig_stax = chgstfig_voltax.twinx()
        chgstfig_stax.plot(
            [i/3600 for i in temp_df[time_secs.name]], 
            temp_df[bms_chmode.name], 
            label = 'Pack Charge State')
        chgstfig_stax.plot(
            [i/3600 for i in temp_df[time_secs.name]], 
            temp_df[bm1_chmode.name], 
            label = 'Module 1 Charge State')
        chgstfig_stax.set_ylabel('Charge State')
        chgstfig_stax.grid(False)
        
        chgenax = chgstfig_voltax.twinx()
        chgenax.plot(
            [i/3600 for i in temp_df[time_secs.name]], 
            temp_df[bms_chgen.name], 
            label = "Pack Charge Enable")
        chgenax.plot(
            [i/3600 for i in temp_df[time_secs.name]], 
            temp_df[bm1_chgen.name], 
            label = "Module 1 Charge Enable")
        chgenax.set_ylabel('Charge Enable')
        chgenax.spines['right'].set_position(('outward', 60))
        chgenax.grid(None)
    
        lines, labels = chgstfig_voltax.get_legend_handles_labels()
        lines2, labels2 = chgstfig_currax.get_legend_handles_labels()
        lines3, labels3 = chgstfig_stax.get_legend_handles_labels()
        lines4, labels4 = chgenax.get_legend_handles_labels()
        chgstfig_voltax.legend(lines + lines2 + lines3 + lines4, labels + labels2 + labels3 + labels4)
    
    plt.xlim(min([i/3600 for i in temp_df[time_secs.name]]), max([i/3600 for i in temp_df[time_secs.name]]))    
    chgstfig_voltax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)
    
    del temp_df
    
    plt.title("BMS Charge State")
    chgstfig.set_size_inches(16, 12)
    plt.show()
    
    if savefig:
        chgstfig.savefig(
            os.path.join(fig_dir, fname_prefix + '_State_Charge.png'),
            format='png',
            dpi=400,
            bbox_inches='tight')