# -*- coding: utf-8 -*-
"""
Created on Tue Feb 16 11:08:36 2021

@author: ranand
"""

import sys
if 'mpl' not in sys.modules:
    import matplotlib as mpl 
if 'plt' not in sys.modules:
    import matplotlib.pyplot as plt
# if 'os' not in sys.modules:
#     import os

import os
from helperfunc import pad

rcdict02 = {'ytick.labelsize': 14, 'axes.labelsize': 14}


def plot_cellcap(
    time_secs, \
    brickcaps, \
    savefig = False, fig_dir = '', fname_prefix = '' ):
    
    time_hrs = [tsec/3600 for tsec in time_secs]
    
    with mpl.rc_context(fname='RA_BMS.rc'):
        brickcapfig, capax = plt.subplots(num = 'Brick_Capacities')
        for brick in range(0, len(brickcaps.columns)):
            capax.plot(
                time_hrs, 
                pad(brickcaps.iloc[:, brick]), 
                label = "Brick " + str(brick+1).zfill(2), 
                linewidth = 0.5)
    
        capax.set_xlabel("Time (hrs)")
        capax.set_ylabel("Brick Capacity (Ah)")
        plt.legend()
    
    plt.xlim(min(time_hrs), max(time_hrs))
    capax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)
    
    plt.title("Brick Capacities")
    brickcapfig.set_size_inches(16, 12)
    
    if savefig:
        brickcapfig.savefig(
            os.path.join(fig_dir, fname_prefix + '_Capacity_Bricks.png'),
            format='png',
            dpi=400,
            bbox_inches='tight')
        
        
def plot_celldcr(
    r0_at_soc, \
    bricksoc, \
    bricktemp, \
    time_secs, \
    brickres, \
    can_packsoc, \
    packtemp, \
    savefig = False, fig_dir = '', fname_prefix = ''):
    
    time_hrs = [tsec/3600 for tsec in time_secs]
    
    calib_r0 =  [[] for _ in range(0, 14)] 
    
    for brick in range(0, 14):
        for index in range(1, len(time_secs)):
            calib_r0[brick].append((1/18)*1000*r0_at_soc(bricktemp.iloc[index, brick], bricksoc.iloc[index, brick]/100))

        calib_r0[brick].append(calib_r0[brick][-1])

    
    with mpl.rc_context(fname='RA_BMS.rc'):
        brickresfig, brickresfig_resax = plt.subplots(num = 'Brick_Resistances')
    
        for brick in range(0, len(brickres.columns)):
            brickresfig_resax.plot(
                time_hrs, 
                pad(brickres.iloc[:, brick]), 
                label = "Brick " + str(brick).zfill(2), 
                linewidth = 0.5)
        
            brickresfig_resax.plot(
                    time_hrs, 
                    calib_r0[brick], 
                    label = "Calib - Brick " + str(brick).zfill(2), 
                    linewidth = 0.5)
    
        brickresfig_resax.set_xlabel("Time (hrs)")
        brickresfig_resax.set_ylabel(r"Resistance ($\Omega$)")
        plt.xlim(min(time_hrs), max(time_hrs))
    
    with mpl.rc_context(rcdict02):
        brickresfig_socax = brickresfig_resax.twinx()
        brickresfig_socax.plot(
            time_hrs, 
            can_packsoc, 
            label = "BM1 SoC")
        brickresfig_socax.set_ylabel("SoC (%)")
    
        brickresfig_temperatureax = brickresfig_resax.twinx()
        brickresfig_temperatureax.plot(
            time_hrs, 
            packtemp, 
            label = "Pack Temperature")
        brickresfig_temperatureax.set_ylabel(r"Pack Temperature ($\degree$C)")
        brickresfig_temperatureax.spines['right'].set_position(('outward', 60))
    
    with mpl.rc_context(fname='RA_BMS.rc'):
        lines, labels = brickresfig_resax.get_legend_handles_labels()
        lines2, labels2 = brickresfig_socax.get_legend_handles_labels()
        lines3, labels3 = brickresfig_temperatureax.get_legend_handles_labels()
        brickresfig_resax.legend(lines + lines2 + lines3, labels + labels2 + labels3)
    
    brickresfig_resax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)
    
    plt.title("Brick Resistances")
    
    brickresfig.set_size_inches(16, 12)
    
    if savefig:
        brickresfig.savefig(
            os.path.join(fig_dir, fname_prefix + '_Resistance_Bricks.png'),
            format='png',
            dpi=400,
            bbox_inches='tight' )
        
def plot_cellimpedance(
    time_secs, \
    brickres, \
    init_packimp, \
    packimp, \
    can_packsoc, \
    packtemp, \
    savefig = False, fig_dir = '', fname_prefix = ''):
    
    time_hrs = [tsec/3600 for tsec in time_secs]
    
    with mpl.rc_context(fname='RA_BMS.rc'):
        fig, fig_sohrax = plt.subplots(num = 'Brick_Impedances')
    
        for brick in range(0, len(brickres.columns)):
            fig_sohrax.plot(
                time_hrs, 
                pad(brickres.iloc[:, brick]), 
                label = "Brick " + str(brick).zfill(2), 
                linewidth = 0.5)
       
        fig_impax = fig_sohrax.twinx()
        
        fig_impax.plot(
            time_hrs, 
            init_packimp, 
            label = 'Initial Impedance')
        
        fig_impax.plot(
            time_hrs, 
            packimp, 
            label = 'Current Impedance')
        
        fig_impax.set_ylabel(r"Pack Temperature ($\degree$C)")
        fig_impax.spines['right'].set_position(('outward', 120))
        
    
        fig_sohrax.set_xlabel("Time (hrs)")
        fig_sohrax.set_ylabel("SoHR (%)")
        plt.xlim(min(time_hrs), max(time_hrs))
    
    with mpl.rc_context(rcdict02):
        fig_socax = fig_sohrax.twinx()
        fig_socax.plot(
            time_hrs, 
            can_packsoc, 
            label = "BM1 SoC")
        fig_socax.set_ylabel("SoC (%)")
    
        fig_temperatureax = fig_sohrax.twinx()
        fig_temperatureax.plot(
            time_hrs, 
            packtemp, 
            label = "Pack Temperature")
        fig_temperatureax.set_ylabel(r"Pack Temperature ($\degree$C)")
        fig_temperatureax.spines['right'].set_position(('outward', 60))
    
    with mpl.rc_context(fname='RA_BMS.rc'):
        lines, labels = fig_sohrax.get_legend_handles_labels()
        lines2, labels2 = fig_socax.get_legend_handles_labels()
        lines3, labels3 = fig_temperatureax.get_legend_handles_labels()
        fig_sohrax.legend(lines + lines2 + lines3, labels + labels2 + labels3)
    
    fig_sohrax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)
    
    plt.title("Brick Impedances")
    
    fig.set_size_inches(16, 12)
    
    if savefig:
        fig.savefig(
            os.path.join(fig_dir, fname_prefix + '_Impedance_Bricks.png'),
            format='png',
            dpi=400,
            bbox_inches='tight' )