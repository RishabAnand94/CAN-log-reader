# -*- coding: utf-8 -*-
"""
Created on Mon Jan 25 11:40:58 2021

@author: ranand
"""
import sys
if 'pd' not in sys.modules:
    import pandas as pd

import scipy.interpolate

#from can_log_reader_v07_f import cal_ver
#cal_ver = '1_2_42'

import warnings
warnings.filterwarnings("ignore")

import os
#%%
def cell_calib(cal_ver):
    cellcalib_relfilepath = '\\calib\\Cell_Config\\BD\\'
    eventcalib_relfilepath = '\\calib\\Event_Config\\'
    tsensecalib_relfilepath = '\\calib\\Temp_Config\\'
    
    calib_lookup_file = "\\calib\\cal_lookup.csv"
    calib_lookup = pd.read_csv(os.getcwd()+calib_lookup_file)
    
    #initialising 
    cellcalib_filename = ""
    eventcalib_filename = ""
    
    try:

        cellcalib_filename  = list(calib_lookup[calib_lookup["cal_ver"]==cal_ver]["cellcalib_filename"])[0]
        eventcalib_filename = list(calib_lookup[calib_lookup["cal_ver"]==cal_ver]["eventcalib_filename"])[0]
        print("Loaded calibration:",cal_ver)
    
    except IndexError:
        print("Matching cal not found !")
        
    cellcalib_fileobj = pd.ExcelFile(os.getcwd() + cellcalib_relfilepath + cellcalib_filename)
    eventcalib_fileobj = pd.ExcelFile(os.getcwd() + eventcalib_relfilepath + eventcalib_filename)
    #tsensecalib_fileobj = pd.ExcelFile('Temp_Config_BAL_v0_1_0.xlsx')
    tsensecalib_fileobj = pd.ExcelFile(os.getcwd() + tsensecalib_relfilepath + 'Temp_Config_BAL_v0_1_1.xlsx')
    
    #%% Read BMS calibration files
    print("Reading BMS calibration files ...")
    
    #=============================================================================#
    # Cell calibration file 
    #=============================================================================#
    # OCV
    ocv_df = cellcalib_fileobj.parse('OCV', header = 1, index_col = 1)
    ocv_df.dropna(axis = 1, inplace = True)
    
    # Hysteresis
    hyst_df = cellcalib_fileobj.parse('HYST', header = 1, index_col = 1)
    hyst_df.dropna(axis = 1, inplace = True)
    
    # Rest voltage at given SoC
    def restvolt_from_soc(temperature_val, soc_val, prevcurrent_dir):
        # # With a zero order hysteresis model, compute rest voltage for given current history
        # if prevcurrent_dir <= 0:   # Cell last discharged 
        #     restvolt_df = ocv_df.sub(hyst_df)
        # elif prevcurrent_dir > 0:  # Cell last charged 
        #     restvolt_df = ocv_df.add(hyst_df)
        restvolt_df = ocv_df
        
        # Now use linear interpolation to compute rest voltage for given SoC
        restvolt_from_soc_f = scipy.interpolate.interp2d(restvolt_df.columns, restvolt_df.index, restvolt_df.values, kind='linear')
        restvolt_val = restvolt_from_soc_f(temperature_val, soc_val)
        
        return restvolt_val 
    
    # SoC at given rest voltage
    def soc_from_restvolt(temperature_val, restvolt_val, prevcurrent_dir):
        # # With a zero order hysteresis model, compute rest voltage for given current history 
        # if prevcurrent_dir <= 0:   # Cell last discharged 
        #     restvolt_df = ocv_df.sub(hyst_df)
        # elif prevcurrent_dir > 0:  # Cell last charged 
        #     restvolt_df = ocv_df.add(hyst_df)
        restvolt_df = ocv_df
        
        # Reduce a 2d inverse interpolation problem to 1d
        restvolt_at_temp_f = scipy.interpolate.interp1d(restvolt_df.columns, restvolt_df.values)
        restvolt_vals_at_temp = restvolt_at_temp_f(temperature_val)
        
        # With the now known rest voltage at temperature, use 1d inverse interpolation to compute SoC
        soc_from_restvolt_at_temp = scipy.interpolate.interp1d(restvolt_vals_at_temp, restvolt_df.index)
        if restvolt_val > max(restvolt_vals_at_temp):
            print("Rest voltage value is greater than max rest voltage at given temperature !")
            restvolt_val = max(restvolt_vals_at_temp)
        elif restvolt_val < min(restvolt_vals_at_temp):
            print("Rest voltage value is less than min rest voltage at given temperature !")
            restvolt_val = min(restvolt_vals_at_temp)
        soc_val = soc_from_restvolt_at_temp(restvolt_val)
        
        return float(soc_val)

    # Resistance R0
    r0_df = cellcalib_fileobj.parse('RES_INST', header = 1, index_col = 1)
    r0_df.dropna(axis = 1, inplace = True)
    
    # Resistance R0 at given SoC
    def r0_at_soc(temperature_val, soc_val):
        # Use linear interpolation to compute resistance r0 for given SoC
        r0_at_soc_f = scipy.interpolate.interp2d(r0_df.columns, r0_df.index, r0_df.values, kind='linear')
        r0_val = r0_at_soc_f(temperature_val, soc_val)
        return r0_val 
    
    # Resistance R1
    r1_df = cellcalib_fileobj.parse('RES_CONT', header = 1, index_col = 1)
    r1_df.dropna(axis = 1, inplace = True)
    
    # Resistance R1 at given SoC
    def r1_at_soc(temperature_val, soc_val):
        # Use linear interpolation to compute resistance r0 for given SoC
        r1_at_soc_f = scipy.interpolate.interp2d(r1_df.columns, r1_df.index, r1_df.values, kind='linear')
        r1_val = r1_at_soc_f(temperature_val, soc_val)
        return r1_val 
    
    # Current Limits 
    chginst_df = cellcalib_fileobj.parse('CHG_INST', header = 1, index_col = 1)
    chginst_df.dropna(axis = 1, inplace = True)
    chginst_from_soc_f = scipy.interpolate.interp2d(chginst_df.columns, chginst_df.index, chginst_df.values, kind='linear')
    
    chg10s_df = cellcalib_fileobj.parse('CHG_10_SEC', header = 1, index_col = 1)
    chg10s_df.dropna(axis = 1, inplace = True)
    chg10s_from_soc_f = scipy.interpolate.interp2d(chg10s_df.columns, chg10s_df.index, chg10s_df.values, kind='linear')
    
    chgcont_df = cellcalib_fileobj.parse('CHG_CONT', header = 1, index_col = 1)
    chgcont_df.dropna(axis = 1, inplace = True)
    chgcont_from_soc_f = scipy.interpolate.interp2d(chgcont_df.columns, chgcont_df.index, chgcont_df.values, kind='linear')
       
    dchinst_df = cellcalib_fileobj.parse('DCH_INST', header = 1, index_col = 1)
    dchinst_df.dropna(axis = 1, inplace = True)
    dchinst_from_soc_f = scipy.interpolate.interp2d(dchinst_df.columns, dchinst_df.index, dchinst_df.values, kind='linear')
    
    dch10s_df = cellcalib_fileobj.parse('DCH_10_SEC', header = 1, index_col = 1)
    dch10s_df.dropna(axis = 1, inplace = True)
    dch10s_from_soc_f = scipy.interpolate.interp2d(dch10s_df.columns, dch10s_df.index, dch10s_df.values, kind='linear')
    
    dchcont_df = cellcalib_fileobj.parse('DCH_CONT', header = 1, index_col = 1)
    dchcont_df.dropna(axis = 1, inplace = True)
    dchcont_from_soc_f = scipy.interpolate.interp2d(dchcont_df.columns, dchcont_df.index, dchcont_df.values, kind='linear')
    
    #=============================================================================#
    # Temperature sensor calibration file 
    #=============================================================================#
    global tsensorweight_df
    tsensorweight_df = tsensecalib_fileobj.parse('TempCal', header = 0, index_col = 0)
    tsensorweight_df.dropna(axis = 1, inplace = True)
    
    #=============================================================================#
    # Event matrix calibration file 
    #=============================================================================#
    global event_df
    event_df = eventcalib_fileobj.parse('Set_Points')
    
    print("Calibration file reading complete.")
    return restvolt_from_soc, soc_from_restvolt, r0_at_soc, r1_at_soc,chginst_from_soc_f,\
           chg10s_from_soc_f,chgcont_from_soc_f,dchinst_from_soc_f,dch10s_from_soc_f,\
           dchcont_from_soc_f