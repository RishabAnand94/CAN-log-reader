# -*- coding: utf-8 -*-
"""
Created on Mon Aug 17 15:22:24 2020

@author: ranand,jma
"""

import os
import pandas as pd
import easygui as eg
import matplotlib.pyplot as plt
import tkinter as tk
import tkinter.filedialog as filedialog
import warnings
warnings.filterwarnings("ignore")

from datetime import datetime,date
def write_error(message, err_path = r"" ):
    
        
    """ The Error/warning log creater (ex: missing temperature values, no such files, etc.)
        arguments : 
            message   : The error message to be logged
            err_path  : location to save error log 
    
    """

    file1 = open(err_path+"log.txt","a")#append mode 
    file1.write(str(datetime.now()) +" : " + message +"\n") 
    file1.close() 

from can_log_reader_v07_f import *

app=tk.Tk()
app.withdraw()
app.call('wm', 'attributes', '.', '-topmost', True) # This is the reason why filedialog will always come to the front
 
test_file_list = filedialog.askopenfilename(title = 'Select look-up table', default = '*', filetypes = [('*.xls', '*.xlsx')], multiple = False) 

#%%
input_file = pd.ExcelFile(test_file_list)
input_sheets = input_file.sheet_names

#%%

colname_executeperm = 'execute'
colname_testid = 'test#'
colname_batterySN = 'battSer#'
colname_testdesc = 'testDesc'
colname_testtemp = 'testTemp'
colname_calver = 'calVer'
colname_canlogfilename = 'CANLogFiles'
colname_testerlogfilename = 'testerLogFiles'

for sheet in input_sheets: 
    filelist_df =  input_file.parse(sheet)

    for testnum in range(0, len(filelist_df)):          
        if (filelist_df.loc[testnum][colname_executeperm] == 1):
            testid = filelist_df.loc[testnum][colname_testid]
            batterySN = filelist_df.loc[testnum][colname_batterySN]
            testdesc = filelist_df.loc[testnum][colname_testdesc]
            testtemp = filelist_df.loc[testnum][colname_testtemp]
            calver = filelist_df.loc[testnum][colname_calver]
                            
            canlog_filename = filelist_df.loc[testnum, colname_canlogfilename][2:-2].replace('\\\\', '\\').split("', '")
            testerlog_filename = filelist_df.loc[testnum, colname_testerlogfilename][2:-2].replace('\\\\', '\\').split("', '")
            
            print("\nTest:",testid)
            print("Pack:",batterySN)
            print("Test:",testdesc)
            print("Temperature",testtemp)
            print("calibration version:",calver)
            print("\n")
        
            try:    
                can_log_reader_v07_f(testid, batterySN, testdesc, testtemp, calver, canlog_filename, testerlog_filename)
                plt.close('all')
            except Exception as ex:
                print('Execution of %d failed ! due to' %testid,type(ex).__name__,ex.args)
                write_error('Execution of %d failed ! due to' %testid + str(type(ex).__name__) + str(ex.args))
                plt.close('all')
                continue
           