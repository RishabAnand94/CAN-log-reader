"""
Created on Tue May 18 16:47:12 2021

@author: josephma
"""


from pathlib import Path
import pandas as pd
import re
import os
from openpyxl import load_workbook, Workbook
import shutil
from datetime import datetime,date
import pandas as pd


df = pd.read_csv(r"location_LUT.csv")
dest_path    = os.getcwd()+r"\results"
bin_path     = dest_path + r"\bin"
LUT_file_name = r'\address_lookup_1.xlsx'

source_path = r""

if not os.path.exists(dest_path ):
                os.makedirs(dest_path )
                
                
def read_excel_log(files):   

    print('Reading existing log file ... \n')
    
    # Sort file names in ascending order so that merging is correct
    files.sort();
    
    i_d = pd.DataFrame()
  
    # Parse through all input data log files one-by-one
    for file_count in range(len(files)):
        input_file = pd.ExcelFile(files[file_count])
        input_sheets = input_file.sheet_names

        

        for sheet_count in range(len(input_sheets)):#len(input_sheets)
            
            input_df_segment = input_file.parse(input_sheets[sheet_count])

            start_row_data = input_df_segment[input_df_segment.columns[3]].first_valid_index()

            column_names = input_df_segment.loc[start_row_data]
     

            input_df_segment = pd.DataFrame(input_df_segment.values[start_row_data : ],columns = column_names.keys())
            i_d =  pd.concat([i_d,input_df_segment])

      
            
    print('Process complete ... \n')
    i_d = i_d.dropna(thresh = 5)
   
   
    #print(i_d[i_d["test#"].isnull()])
    op = i_d["test#"].unique()
    op = list(map(int,op))
    return op



def create_copy(source, dest = bin_path+ r"/dump" +str(date.today())+ ".xlsx"):
    shutil.copy2(source, dest)


def write_error(message, err_path = dest_path ):
    
        
    """ The Error/warning log creater (ex: missing temperature values, no such files, etc.)
        arguments : 
            message   : The error message to be logged
            err_path  : location to save error log 
    
    """

    
    file1 = open(err_path+"\log.txt","a")#append mode 
    file1.write(str(datetime.now()) +" : " + message +"\n") 
    file1.close() 





def log_file(update_list = [], target_address = source_path ,                        destination_address = dest_path + LUT_file_name,choice = 1):
    
 
    base_address            =  target_address

    address                 =  destination_address
    
    
    check = update_list
    
    #Column Names
    colname_Execute         = "execute"
    colname_Execute1         = "execute1"
    
    colname_Testnum         = "test#"
    colname_Battnum         = "battSer#"
    colname_Calibdata       = "calVer"
    colname_Temp            = "testTemp"
    colname_ExcelFilePath   = "testerLogFiles"
    colname_CANLogFilePath  = "CANLogFiles"
    colname_TestDesc        = "testDesc"

    #Initialisations

    dir_obj = Path(base_address)
    dict_f ={}
    data = []
    log_list =[]
    excel_list = []
    files_labels = []
    folder_labels = []
    
    

    for Test_folder in dir_obj.iterdir():
        log_list =[]
        excel_list = []
        folder_labels = []
        #print(Test_folder.stem,Test_folder.suffix)
        Test_folder_obj = Path(Test_folder)
        try:
            for files in Test_folder_obj.iterdir():
                
                dict_f = {}
                if files.is_file():
                    if files.suffix == ".log":
                        log_list.append(files.__str__())
                    
                    elif (files.suffix == ".xls" or files.suffix == ".xlsx"):
                        if (not files.match("*ummary*")):
                            excel_list.append(files.__str__())
         
                folder_labels = list((Test_folder.stem+Test_folder.suffix).split("_"))
                
                if folder_labels[0][1]!= "#":
                    print(Test_folder.stem)
                    raise IndexError
       
                    
                dict_f[colname_Execute]      =  ""
                dict_f[colname_Execute1]      =  ""
                dict_f[colname_Testnum]      =  int(folder_labels[0][2:])
                dict_f[colname_Battnum]      =  folder_labels[2]
        
                dict_f[colname_Calibdata]    =  "_".join(folder_labels[6][4:].split("-"))
                dict_f[colname_TestDesc]     =  folder_labels[3]
                dict_f[colname_Temp]         =  folder_labels[4][:-2]
                
                dict_f[colname_ExcelFilePath]    = excel_list
                dict_f[colname_CANLogFilePath]   = log_list
                
            data.append(dict_f)
        except NotADirectoryError:
            continue
        except IndexError:
            write_error("IndexError @ "+ Test_folder.stem)
            continue
        
        
    df = pd.DataFrame(data)
    a = df[colname_Battnum].unique().tolist()
    

                
    b = df[colname_Testnum].unique().tolist()
    
    
    
    if choice == 1:
       
        #Checks if the file exist
        if os.path.exists(address):
            writer= pd.ExcelWriter(address,engine = 'openpyxl', mode='a') 
            writer.book = load_workbook(address)
            writer.sheets = dict((ws.title,ws) for ws in writer.book.worksheets)
        
        else:
            writer =pd.ExcelWriter(address,engine = 'openpyxl', mode='w')
        
        
        #creating duplicate
        create_copy(address)
        
        write_error(" File copy was created in bin")
        #
        check1 = read_excel_log([dest_path + LUT_file_name])  
    
        
        check2 = list(set (b)-set(check1) )
        
        
        #Update all new folders if update list is empty
        edit = 0
        if (len(update_list)== 0):
            check = check2
            edit = 1
          
        
        file1 = open(bin_path + r"/test_values.txt","w")
        if file1.mode == 'w':
            if edit == 1:
                file1.write(str(b))
            else:
                file1.write(str(list(set(check1).union(set(update_list)))))
                
        file1.close()
        
        
       
        b = df[colname_Testnum].unique().tolist() # for check
        # write_test_values()
        # write b to txt
        # check  is difference of b1 and b
        df1 =pd.DataFrame()
        
 
        
        for i in range(len(a)):
            
            df1 = df.loc[df[colname_Battnum] == a[i]]  
            df2 = df1[df1[colname_Testnum].isin(check)]
            
        
            if a[i] not in writer.sheets:
                df2.to_excel(writer, sheet_name = a[i], startrow =0, index = False, header = True)
            else:
                startrow_val = writer.book[a[i]].max_row
                df2.to_excel(writer, sheet_name = a[i], startrow = startrow_val,startcol = 0, index = False, header = False)
                
           
            
             
     
        # save the excel
        writer.save()
        writer.close()
        print('DataFrame is successfully updated to Excel File.')
        write_error(str(check)  + "Data  must be successfully updated to the new Excel File.")       
    
    
    if choice ==0:
  
        #Checks if the file exist
        if os.path.exists(address):
            writer= pd.ExcelWriter(address,engine = 'openpyxl', mode='a') 
            writer.book = load_workbook(address)
            writer.sheets = dict((ws.title,ws) for ws in writer.book.worksheets)
            
        
        else:
            writer =pd.ExcelWriter(address,engine = 'openpyxl', mode='w')
            write_error("New file was created")
        

        if not os.path.exists(bin_path):
                os.makedirs(bin_path)
                

        
        df1 =pd.DataFrame()
        
        
        for i in range(len(a)):
            
            df1 = df.loc[df[colname_Battnum] == a[i]]
            df2 = df1
  
    
            startrow_val = 0    
            df2.to_excel(writer, sheet_name = a[i], startrow =startrow_val,startcol = 0, index = False)
      
    
        # save the excel
        writer.save()
        writer.close()
        print('DataFrame is written successfully to Excel File.')
        write_error('DataFrame is written successfully to the new Excel File. Files written:'+str(b))





list_of_tests_to_update = [] #leave empty for parsing all files


for source_path in df["loc"]:
    
    if Path(dest_path + LUT_file_name).exists():
        ch =1
    else:
        ch =0


    try:

        log_file(list_of_tests_to_update,source_path, choice=ch)
    except Exception as ex:
        write_error('Execution of %s failed ! due to' %Path(source_path).__str__() + str(type(ex).__name__) + str(ex.args))


del df


