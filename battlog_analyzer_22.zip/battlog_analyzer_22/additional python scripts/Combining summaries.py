#!/usr/bin/env python
# coding: utf-8

# In[39]:


# -*- coding: utf-8 -*-
"""
Created on Tue May 25 13:15:16 2021

@author: josephma
"""
from openpyxl import load_workbook, Workbook
import tkinter as tk
import tkinter.filedialog as filedialog
import pandas as pd



#open existing master summary sheet
#make list of all tests
app=tk.Tk()
app.withdraw()
app.call('wm', 'attributes', '.', '-topmost', True) # This is the reason why filedialog will always come to the front
main_sheet_address = filedialog.askopenfilename(title = 'Master Summary', default = '*', filetypes = [('*.xls', '*.xlsx')], multiple = False) 



#open the new summary segment
# check entries
#if the entry is new append.
#all pack parameters to the bottom, all cell params to the right.
 
new_sheet_address = filedialog.askopenfilename(title = 'New Summary', default = '*', filetypes = [('*.xls', '*.xlsx')], multiple = False) 


# In[40]:



input_file_m = pd.ExcelFile(main_sheet_address)
input_sheets_m = input_file_m.sheet_names

input_df_segment = input_file_m.parse(input_sheets_m[0])
start_row_data = input_df_segment[input_df_segment.columns[1]].first_valid_index()
column_names = input_df_segment.loc[start_row_data]
pack_hist_m = pd.DataFrame(input_df_segment.values[start_row_data + 1: ],columns = column_names)
pack_hist_m = pack_hist_m.dropna(thresh = 5)
pack_hist_m = pack_hist_m.set_index("test#")


# In[41]:


input_file_n = pd.ExcelFile(new_sheet_address)
input_sheets_n = input_file_n.sheet_names

input_df_segment = input_file_n.parse(input_sheets_n[0])
start_row_data = input_df_segment[input_df_segment.columns[1]].first_valid_index()
column_names = input_df_segment.loc[start_row_data]
pack_hist_n = pd.DataFrame(input_df_segment.values[start_row_data + 1: ],columns = column_names)
pack_hist_n =pack_hist_n.drop_duplicates(keep = "last")
pack_hist_n = pack_hist_n.dropna(thresh = 5)
pack_hist_n = pack_hist_n.set_index("test#")


# In[42]:


pack_hist_m.index[-60:-40]


# In[43]:


set(pack_hist_n.reset_index()["test#"])


# In[44]:


tbu = set(pack_hist_n.reset_index()["test#"])-set(pack_hist_m.reset_index()["test#"])


# In[45]:


tbu =list(map(int,tbu))
tbu


# In[ ]:





# In[49]:


pack_hist_n =pack_hist_n[pack_hist_n.index.astype(int).isin(tbu)]

input_df_segment = input_file_n.parse(input_sheets_n[1])
start_row_data = input_df_segment[input_df_segment.columns[1]].first_valid_index()
column_names = input_df_segment.loc[start_row_data]
pack_soc_n = pd.DataFrame(input_df_segment.values[start_row_data + 1: ],columns = column_names)
pack_soc_n = pack_soc_n.dropna(thresh = 15)
pack_soc_n  = pack_soc_n.set_index("test#")
pack_soc_n  = pack_soc_n[pack_soc_n.index.astype(int).isin(tbu)]
pack_soc_n =pack_soc_n.drop_duplicates(keep = "last")

input_df_segment = input_file_n.parse(input_sheets_n[2])
start_row_data = input_df_segment[input_df_segment.columns[1]].first_valid_index()
column_names = input_df_segment.loc[start_row_data]
pack_sohc_n= pd.DataFrame(input_df_segment.values[start_row_data + 1: ],columns = column_names)
pack_sohc_n = pack_sohc_n.dropna(thresh = 15)
pack_sohc_n = pack_sohc_n.set_index("test#")
pack_sohc_n  = pack_sohc_n[pack_sohc_n.index.astype(int).isin(tbu)]
pack_sohc_n =pack_sohc_n.drop_duplicates(keep = "last")


input_df_segment = input_file_n.parse(input_sheets_n[3])
start_row_data = input_df_segment[input_df_segment.columns[1]].first_valid_index()
column_names = input_df_segment.loc[start_row_data]
pack_soe_n = pd.DataFrame(input_df_segment.values[start_row_data + 1: ],columns = column_names)
pack_soe_n = pack_soe_n.dropna(thresh = 15)
pack_soe_n =pack_soe_n.set_index("test#")
pack_soe_n  = pack_soe_n[pack_soe_n.index.astype(int).isin(tbu)]
pack_soe_n =pack_soe_n.drop_duplicates(keep = "last")

input_df_segment = input_file_n.parse(input_sheets_n[4])
start_row_data = input_df_segment[input_df_segment.columns[1]].first_valid_index()
column_names = input_df_segment.loc[start_row_data]
pack_temp_n = pd.DataFrame(input_df_segment.values[start_row_data + 1: ],columns = column_names)
pack_temp_n = pack_temp_n.dropna(thresh = 15)
pack_temp_n = pack_temp_n.set_index("test#")
pack_temp_n  = pack_temp_n[pack_temp_n.index.astype(int).isin(tbu)]
pack_temp_n =pack_temp_n.drop_duplicates(keep = "last")


# In[50]:


pack_sohc_n


# In[51]:


input_df_segment = input_file_n.parse(input_sheets_n[5])
start_row_data = input_df_segment[input_df_segment.columns[0]].first_valid_index()
t_input_df = input_df_segment.transpose()
t_input_df.columns = t_input_df.iloc[0]
t_cell_soc_n = t_input_df[1:]
t_cell_soc_n = t_cell_soc_n .dropna(thresh=20)
t_cell_soc_n  = t_cell_soc_n[t_cell_soc_n.index.astype(int).isin(tbu)]
t_cell_soc_n =t_cell_soc_n.drop_duplicates(keep = "last")

input_df_segment = input_file_n.parse(input_sheets_n[6])
start_row_data = input_df_segment[input_df_segment.columns[0]].first_valid_index()
t_input_df = input_df_segment.transpose()
t_input_df.columns = t_input_df.iloc[0]
t_cell_sohc_n = t_input_df[1:]
t_cell_sohc_n = t_cell_sohc_n .dropna(thresh=20)
t_cell_sohc_n  = t_cell_sohc_n[t_cell_sohc_n.index.astype(int).isin(tbu)]
t_cell_sohc_n =t_cell_sohc_n.drop_duplicates(keep = "last")

input_df_segment = input_file_n.parse(input_sheets_n[7])
start_row_data = input_df_segment[input_df_segment.columns[0]].first_valid_index()
t_input_df = input_df_segment.transpose()
t_input_df.columns = t_input_df.iloc[0]
t_cell_bal_n = t_input_df[1:]
t_cell_bal_n = t_cell_bal_n .dropna(thresh=20)
t_cell_bal_n  = t_cell_bal_n[t_cell_bal_n.index.astype(int).isin(tbu)]
t_cell_bal_n =t_cell_bal_n.drop_duplicates(keep = "last")


input_df_segment = input_file_n.parse(input_sheets_n[8])
start_row_data = input_df_segment[input_df_segment.columns[0]].first_valid_index()
t_input_df = input_df_segment.transpose()
t_input_df.columns = t_input_df.iloc[0]
t_cell_temp_n = t_input_df[1:]
t_cell_temp_n = t_cell_temp_n .dropna(thresh=20)
t_cell_temp_n  = t_cell_temp_n[t_cell_temp_n.index.astype(int).isin(tbu)]
t_cell_temp_n =t_cell_temp_n.drop_duplicates(keep = "last")


# In[137]:


#Checks if the file exist
#import os
#address = filedialog.asksaveasfilename(
          #      defaultextension='.xlsx', filetypes=[("Excel files", '*.xlsx')],
            #    initialdir=os.getcwd(),
              #  title="Choose filename")


# In[138]:


address= main_sheet_address
if os.path.exists(address):
    writer= pd.ExcelWriter(address,engine = 'openpyxl', mode='a') 
    writer.book = load_workbook(address)
    writer.sheets = dict((ws.title,ws) for ws in writer.book.worksheets)

else:
    writer =pd.ExcelWriter(address,engine = 'openpyxl', mode='w')


# In[139]:


writer.sheets


# In[140]:


startrow_val = writer.book['PackHistory'].max_row
pack_hist_n .to_excel(writer, sheet_name = 'PackHistory', startrow = startrow_val,startcol = 0, index = True, header = False)

startrow_val = writer.book['PackSoC'].max_row
pack_soc_n .to_excel(writer, sheet_name = 'PackSoC', startrow = startrow_val,startcol = 0, index = True, header = False)

startrow_val = writer.book['PackSoHC'].max_row
pack_sohc_n .to_excel(writer, sheet_name = 'PackSoHC', startrow = startrow_val,startcol = 0, index = True, header = False)

startrow_val = writer.book['PackSoE'].max_row
pack_soe_n .to_excel(writer, sheet_name = 'PackSoE', startrow = startrow_val,startcol = 0, index = True, header = False)

startrow_val = writer.book['PackTemp'].max_row
pack_temp_n .to_excel(writer, sheet_name = 'PackTemp', startrow = startrow_val,startcol = 0, index = True, header = False)


# In[141]:


startcol_val = writer.book['CellSoC'].max_column
t_cell_soc_n.transpose().to_excel(writer, sheet_name = 'CellSoC', startrow = 0,startcol = startcol_val, index = False, header = True)

startcol_val = writer.book['CellSoHC'].max_column
t_cell_sohc_n.transpose().to_excel(writer, sheet_name = 'CellSoHC', startrow = 0,startcol = startcol_val, index = False, header = True)

startcol_val = writer.book['CellBal'].max_column
t_cell_bal_n.transpose().to_excel(writer, sheet_name = 'CellBal', startrow = 0,startcol = startcol_val, index = False, header = True)

startcol_val = writer.book['CellTemp'].max_column
t_cell_temp_n.transpose().to_excel(writer, sheet_name = 'CellTemp', startrow = 0,startcol = startcol_val, index = False, header = True)


# In[142]:


writer.save()
writer.close()


# In[ ]:




