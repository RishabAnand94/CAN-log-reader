# -*- coding: utf-8 -*-
"""
Created on Mon Feb 15 16:32:00 2021

@author: ranand
"""
import sys
if 'mpl' not in sys.modules:
    import matplotlib as mpl 
if 'plt' not in sys.modules:
    import matplotlib.pyplot as plt
# if 'os' not in sys.modules:
#     import os

import os
import cellcalib

rcdict02 = {'ytick.labelsize': 14, 'axes.labelsize': 14}

#pass the necessary function
def plot_currentlim(chginst_from_soc_f,\
                    chg10s_from_soc_f,\
                    chgcont_from_soc_f,\
                    dchinst_from_soc_f,\
                    dch10s_from_soc_f,\
                    dchcont_from_soc_f,\
                    time_secs, \
                    bricksocs, tempsensorvals, \
                    idch_inst, idch_10s, idch_cont, \
                    ichg_inst, ichg_10s, ichg_cont, \
                    can_packcurrent, can_packsoc, \
                    savefig = False, fig_dir = '', fname_prefix = '' ):
    """
    

    Parameters
    ----------
    time_secs : TYPE
        DESCRIPTION.
    bricksocs : TYPE
        DESCRIPTION.
    tempsensorvals : TYPE
        DESCRIPTION.
    inst_dchcurrlim : TYPE
        DESCRIPTION.
    10s_dchcurrlim : TYPE
        DESCRIPTION.
    cont_dchcurrlim : TYPE
        DESCRIPTION.
    inst_chgcurrlim : TYPE
        DESCRIPTION.
    10s_chgcurrlim : TYPE
        DESCRIPTION.
    cont_chgcurrlim : TYPE
        DESCRIPTION.
    savefig : TYPE, optional
        DESCRIPTION. The default is False.
    fig_dir : TYPE, optional
        DESCRIPTION. The default is ''.
    fname_prefix : TYPE, optional
        DESCRIPTION. The default is ''.

    Returns
    -------
    None.

    """
    
    time_hrs = [tsec/3600 for tsec in time_secs]
    
    calib_chginstlim = []
    calib_chg10slim = []
    calib_chgcontlim = []
    
    calib_dchinstlim = []
    calib_dch10slim = []
    calib_dchcontlim = []
    
    # Compute minimum and maximum brick SoCs
    soc_min = bricksocs.min(axis=1)
    soc_max = bricksocs.max(axis=1)
    
    temperature_min = tempsensorvals.min(axis=1)
    temperature_max = tempsensorvals.max(axis=1)
    
    # Use minimum of (min SoC, max temperature) and (min SoC, min temperature)
    for index in range(1, len(tempsensorvals)):
        calib_chginstlim.append(18*min(chginst_from_soc_f(temperature_min[index], soc_max[index]/100), \
                                       chginst_from_soc_f(temperature_max[index], soc_max[index]/100)))
        calib_chg10slim.append(18*min(chg10s_from_soc_f(temperature_min[index], soc_max[index]/100), \
                                      chg10s_from_soc_f(temperature_max[index], soc_max[index]/100)))
        calib_chgcontlim.append(18*min(chgcont_from_soc_f(temperature_min[index], soc_max[index]/100), \
                                       chgcont_from_soc_f(temperature_max[index], soc_max[index]/100)))
    
        calib_dchinstlim.append(-18*min(dchinst_from_soc_f(temperature_min[index], soc_min[index]/100), \
                                        dchinst_from_soc_f(temperature_max[index], soc_min[index]/100)))
        calib_dch10slim.append(-18*min(dch10s_from_soc_f(temperature_min[index], soc_min[index]/100), \
                                       dch10s_from_soc_f(temperature_max[index], soc_min[index]/100)))
        calib_dchcontlim.append(-18*min(dchcont_from_soc_f(temperature_min[index], soc_min[index]/100), \
                                        dchcont_from_soc_f(temperature_max[index], soc_min[index]/100)))
    
    calib_chginstlim.append(calib_chginstlim[-1])
    calib_chg10slim.append(calib_chg10slim[-1])
    calib_chgcontlim.append(calib_chgcontlim[-1])
    
    calib_dchinstlim.append(calib_dchinstlim[-1])
    calib_dch10slim.append(calib_dch10slim[-1])
    calib_dchcontlim.append(calib_dchcontlim[-1])
    
    #TODO - Fix plot colours
    
    with mpl.rc_context(fname='RA_BMS.rc'):
        currentlimfig, currentlimfig_currentlimax = plt.subplots(num = 'Current_Limits')
        currentlimfig_currentlimax.plot(time_hrs, -idch_inst, label = "Inst. Dchg Limit")
        
        currentlimfig_currentlimax.plot(time_hrs, -idch_10s, label = "10 s Dchg Limit")
        currentlimfig_currentlimax.plot(time_hrs, (calib_dch10slim), label = "10 s Dchg Limit (Cal)", linestyle = '--')
        
        currentlimfig_currentlimax.plot(time_hrs, -idch_cont, label = "Cont. Dchg Limit", color = 'firebrick')
        currentlimfig_currentlimax.plot(time_hrs, (calib_dchcontlim), label = "Cont. Dchg Limit (Cal)", color = 'firebrick', linestyle = '--')
    
        currentlimfig_currentlimax.plot(time_hrs, ichg_inst, label = "Inst. Chg Limit")
        
        currentlimfig_currentlimax.plot(time_hrs, ichg_10s, label = "10 s Chg Limit")
        currentlimfig_currentlimax.plot(time_hrs, (calib_chg10slim), label = "10 s Chg Limit (Cal)", linestyle = '--')
        
        currentlimfig_currentlimax.plot(time_hrs, ichg_cont, label = "Cont. Chg Limit")
        currentlimfig_currentlimax.plot(time_hrs, (calib_chgcontlim), label = "Cont. Chg Limit (Cal)", linestyle = '--')
    
        currentlimfig_currentlimax.plot(time_hrs, can_packcurrent, label = "Meas. Pack Current", color = 'black')
    
        currentlimfig_currentlimax.set_xlabel("Time (hrs)")
        currentlimfig_currentlimax.set_ylabel("Current (A)")
    
    plt.xlim((min(time_hrs), max(time_hrs)))
    currentlimfig_currentlimax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)
    
    with mpl.rc_context(rcdict02):
        currentlimfig_socax = currentlimfig_currentlimax.twinx()
        currentlimfig_socax.plot(time_hrs, can_packsoc, label = "Battery SoC")
        currentlimfig_socax.set_ylabel("SoC (%)")
        currentlimfig_socax.grid(None)
    
        currentlimfig_temperatureax = currentlimfig_currentlimax.twinx()
        currentlimfig_temperatureax.plot(time_hrs, temperature_max, label = "Max. Pack Temperature", color = 'maroon')
        currentlimfig_temperatureax.set_ylabel(r"Max. Pack Temperature ($\degree$C)")
        currentlimfig_temperatureax.spines['right'].set_position(('outward', 60))
        currentlimfig_temperatureax.grid(None)
    
    with mpl.rc_context(fname='RA_BMS.rc'):
        # ask matplotlib for the plotted objects and their labels
        lines, labels = currentlimfig_currentlimax.get_legend_handles_labels()
        lines2, labels2 = currentlimfig_socax.get_legend_handles_labels()
        lines3, labels3 = currentlimfig_temperatureax.get_legend_handles_labels()
        currentlimfig_currentlimax.legend(lines + lines2 + lines3, labels + labels2 + labels3)
    
    plt.title("Battery Current Limits")
    currentlimfig.set_size_inches(16, 12)
    plt.show()
    
    if savefig:
        currentlimfig.savefig(os.path.join(fig_dir, fname_prefix + '_LimitsCurrent.png'),
                format='png',
                dpi=400,
                bbox_inches='tight')
      
def plot_voltlim(
    time_secs, \
    can_mod1voltage, \
    can_vdch_min_pack, can_vdch_min_mod1, \
    can_vchg_max_pack, can_vchg_max_mod1, \
    can_vcupowerreq, can_poweravl,  \
    savefig = False, fig_dir = '', fname_prefix = '' ):
    
    time_hrs = [tsec/3600 for tsec in time_secs]
    
    # Maximum charge and minimum discharge voltage
    with mpl.rc_context(fname='RA_BMS.rc'):
        voltlimfig, voltlimfig_voltlimax = plt.subplots(num = 'Voltage_Limits')
        voltlimfig_voltlimax.plot(time_hrs, can_mod1voltage, label = 'Pack Voltage on CAN')
        voltlimfig_voltlimax.plot(time_hrs, can_vchg_max_pack, label = "Max. Charge Voltage - Pack")
        voltlimfig_voltlimax.plot(time_hrs, can_vchg_max_mod1, label = "Max. Charge Voltage - Module 1")
        voltlimfig_voltlimax.plot(time_hrs, can_vdch_min_pack, label = "Min. Discharge Voltage - Pack")
        voltlimfig_voltlimax.plot(time_hrs, can_vdch_min_mod1, label = "Min. Discharge Voltage - Module 1")
        voltlimfig_voltlimax.set_xlabel("Time (sec)")
        voltlimfig_voltlimax.set_ylabel("Voltage (V)")
    
        plt.xlim((min(time_hrs), max(time_hrs)))
        voltlimfig_voltlimax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)
        voltlimfig_voltlimax.legend()
        plt.title("Battery Voltage Limits")
        voltlimfig.set_size_inches(16, 12)
        plt.show()
        
        if savefig:
            voltlimfig.savefig(os.path.join(fig_dir, fname_prefix + '_LimitsVoltage.png'),
                    format='png',
                    dpi=400,
                    bbox_inches='tight')
            
def plot_powerlim(
    time_secs, \
    idch_inst_mod1, \
    can_vdch_min_mod1, \
    can_vcupowerreq, \
    can_poweravl_pack, can_poweravl_mod1, \
    savefig = False, fig_dir = '', fname_prefix = '' ):
    
    time_hrs = [tsec/3600 for tsec in time_secs]
    
    # Available power and VCU requested power
    with mpl.rc_context(fname='RA_BMS.rc'):
        powerlimfig, powlimax = plt.subplots(num = 'Power_Availability')
        powlimax.plot(time_hrs, can_vcupowerreq, label = "VCU Power Request")
        if can_poweravl_pack is not None:
            powlimax.plot(time_hrs, can_poweravl_pack, label = "Available pack power")
            powlimax.plot(time_hrs, can_poweravl_mod1, label = "Available module 1 power")
            computed_dchpower = abs(idch_inst_mod1 * can_vdch_min_mod1)
            powlimax.plot(time_hrs, computed_dchpower, label = "Computed module 1 discharge power")
        powlimax.set_xlabel("Time (sec)")
        powlimax.set_ylabel("Power (W)")
    
    plt.xlim((min(time_hrs), max(time_hrs)))
    powlimax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)
    powlimax.legend()
    plt.title("Available Power and VCU Power Request")
    powerlimfig.set_size_inches(16, 12)
    plt.show()
    
    if savefig:
        powerlimfig.savefig(os.path.join(fig_dir, fname_prefix + '_PowerAvailable.png'),
                format='png',
                dpi=400,
                bbox_inches='tight')