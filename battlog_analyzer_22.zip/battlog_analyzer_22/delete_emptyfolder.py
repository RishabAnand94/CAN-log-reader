# -*- coding: utf-8 -*-
"""
Created on Thu Mar 11 19:17:26 2021

@author: josephma
"""

import os
import shutil

folder_path = r"\\10.20.4.180\ev_logs\ATB Testing\Log analysis upto 11Mar\results"

for entry in os.scandir(folder_path):
    try:
        
       if os.path.isdir(entry.path) and not os.listdir(entry.path) :
            os.rmdir(entry.path)
    except PermissionError:
        continue