# -*- coding: utf-8 -*-
"""
Created on Mon Feb 15 12:23:25 2021

@author: ranand
"""

import sys
if 'mpl' not in sys.modules:
    import matplotlib as mpl 
if 'plt' not in sys.modules:
    import matplotlib.pyplot as plt
# if 'os' not in sys.modules:
#     import os

import os
from helperfunc import pad

rcdict02 = {'ytick.labelsize': 14, 'axes.labelsize': 14}

def plot_packtemperatures(
        time_secs,
        tempsensorvals,
        can_packcurrent, can_packsoc,
        sp_war_overtemp = None, cp_war_overtemp = None,
        sp_mod_overtemp = None, cp_mod_overtemp = None,
        sp_sev_overtemp = None, cp_sev_overtemp = None,
        sp_war_undertemp = None, cp_war_undertemp = None,
        sp_mod_undertemp = None, cp_mod_undertemp = None,
        sp_sev_undertemp = None, cp_sev_undertemp = None,
        sp_tempimbal = None, cp_tempimbal = None,
        tempLim_max = None, tempLim_min = None,
        savefig = False, fig_dir = '', fname_prefix = '' ):
    """
    This function plots pack temperature sensor readings vs. time

    Parameters
    ----------
    time_secs : TYPE
        DESCRIPTION.
    tempsensorvals : TYPE
        DESCRIPTION.
    can_packcurrent : TYPE
        DESCRIPTION.
    can_packsoc : TYPE
        DESCRIPTION.
    sp_war_overtemp : TYPE, optional
        DESCRIPTION. The default is None.
    cp_war_overtemp : TYPE, optional
        DESCRIPTION. The default is None.
    sp_mod_overtemp : TYPE, optional
        DESCRIPTION. The default is None.
    cp_mod_overtemp : TYPE, optional
        DESCRIPTION. The default is None.
    sp_sev_overtemp : TYPE, optional
        DESCRIPTION. The default is None.
    cp_sev_overtemp : TYPE, optional
        DESCRIPTION. The default is None.
    sp_war_undertemp : TYPE, optional
        DESCRIPTION. The default is None.
    cp_war_undertemp : TYPE, optional
        DESCRIPTION. The default is None.
    sp_mod_undertemp : TYPE, optional
        DESCRIPTION. The default is None.
    cp_mod_undertemp : TYPE, optional
        DESCRIPTION. The default is None.
    sp_sev_undertemp : TYPE, optional
        DESCRIPTION. The default is None.
    cp_sev_undertemp : TYPE, optional
        DESCRIPTION. The default is None.
    savefig : TYPE, optional
        DESCRIPTION. The default is False.
    fig_dir : TYPE, optional
        DESCRIPTION. The default is ''.
    fname_prefix : TYPE, optional
        DESCRIPTION. The default is ''.

    Returns
    -------
    None.

    """
    
    time_hrs = [tsec/3600 for tsec in time_secs]
    
    # Compute min and max temperatures among all readings
    temperature_min = tempsensorvals.min(axis=1)
    temperature_max = tempsensorvals.max(axis=1)
    temperature_min_val = tempsensorvals.min(axis=1).min(axis=0)
    temperature_max_val = tempsensorvals.max(axis=1).max(axis=0)
    
    with mpl.rc_context(fname='RA_BMS.rc'):
        packtempfig, packtempfig_tempax = plt.subplots(num = 'Temperatures_Pack')
        for tsensor in range(0, len(tempsensorvals.columns)):
            packtempfig_tempax.plot(
                time_hrs, 
                pad(tempsensorvals.iloc[:, tsensor]), 
                label = "Sensor " + str(tsensor+1).zfill(1))
    
        packtempfig_tempax.set_xlabel("Time (hours)")
        packtempfig_tempax.set_ylabel(r"Temperature ($\degree$C)")
        
        if tempLim_max is not None:
            packtempfig_tempax.plot(
                time_hrs, 
                pad(tempLim_max), 
                label = "Max temperature limit")
        
        if tempLim_min is not None:
            packtempfig_tempax.plot(
                time_hrs, 
                pad(tempLim_min), 
                label = "Min temperature limit")
    
        # Module over-temperature warning, moderate and severe set points and clear points levels
        if sp_war_overtemp is not None and temperature_max_val >= sp_war_overtemp:
            packtempfig_tempax.hlines(
                y = sp_war_overtemp, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'gold')
            packtempfig_tempax.hlines(
                y = cp_war_overtemp, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'gold', linestyle = '--')
        
        if sp_mod_overtemp is not None and temperature_max_val >= sp_mod_overtemp:
            packtempfig_tempax.hlines(
                y = sp_mod_overtemp, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'darkorange')
            packtempfig_tempax.hlines(
                y = cp_mod_overtemp, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'darkorange', linestyle = '--')
        
        if sp_sev_overtemp is not None and temperature_max_val >= sp_sev_overtemp:
            packtempfig_tempax.hlines(
                y = sp_sev_overtemp, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'red')
            packtempfig_tempax.hlines(
                y = cp_sev_overtemp, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'red', linestyle = '--')
    
        # Under temperature warning, moderate and severe set points and clear points levels
        if sp_war_undertemp is not None and temperature_min_val <= sp_war_undertemp:
            packtempfig_tempax.hlines(
                y = sp_war_undertemp, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'lightskyblue')
            packtempfig_tempax.hlines(
                y = cp_war_undertemp, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'lightskyblue', linestyle = '--')
        if sp_mod_undertemp is not None and temperature_min_val <= sp_mod_undertemp:
            packtempfig_tempax.hlines(
                y = sp_mod_undertemp, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'deepskyblue')
            packtempfig_tempax.hlines(
                y = cp_mod_undertemp, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'deepskyblue', linestyle = '--')
        if sp_sev_undertemp is not None and temperature_min_val <= sp_sev_undertemp:
            packtempfig_tempax.hlines(
                y = sp_sev_undertemp, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'royalblue')
            packtempfig_tempax.hlines(
                y = cp_sev_undertemp, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'royalblue', linestyle = '--')
    
        # TODO Over temperature warning, moderate and severe flags - set and cleared
    
        # TODO Under temperature warning, moderate and severe flags - set and cleared
    
    with mpl.rc_context(rcdict02):
        # Another axis on the left to plot temperature delta within the pack
        packtempfig_tempdeltaax = packtempfig_tempax.twinx()
        packtempfig_tempdeltaax.spines["left"].set_position(("axes", -0.07))
        packtempfig_tempdeltaax.spines["left"].set_visible(True)
        packtempfig_tempdeltaax.yaxis.set_label_position('left')
        packtempfig_tempdeltaax.yaxis.set_ticks_position('left')
        packtempfig_tempdeltaax.plot(
            time_hrs, 
            temperature_max - temperature_min, 
            label = "Temperature Delta", 
            color = 'palevioletred')
        
        packtempfig_tempdeltaax.set_ylabel(r"Temperature Delta ($\degree$C)")
        plt.ylim(0, 5)
        packtempfig_tempdeltaax.grid(None)
    
        # Module temperature imbalance set and clear points
        if sp_tempimbal is not None and (temperature_max - temperature_min).min(axis = 0) >= sp_tempimbal:
            packtempfig_tempdeltaax.hlines(
                y = sp_tempimbal, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'gold')
            packtempfig_tempdeltaax.hlines(
                y = cp_tempimbal, 
                xmin = min(time_hrs), xmax = max(time_hrs), 
                color = 'gold', linestyle = '--')    
    
        #  Pack current
        packtempfig_currentax = packtempfig_tempax.twinx()
        packtempfig_currentax.plot(
            time_hrs, 
            can_packcurrent, 
            label = "Pack Current", 
            color = 'black')
        
        packtempfig_currentax.set_ylabel("Pack Current (A)")
        packtempfig_currentax.grid(None)
            
        # Pack SoC
        packtempfig_socax = packtempfig_tempax.twinx()
        packtempfig_socax.plot(
            time_hrs, 
            can_packsoc, 
            label = "Pack SoC")
        
        packtempfig_socax.set_ylabel('Pack SoC (%)')
        packtempfig_socax.spines['right'].set_position(('outward', 60))
        packtempfig_socax.grid(None)
        lines3, labels3 = packtempfig_socax.get_legend_handles_labels()
    
    with mpl.rc_context(fname='RA_BMS.rc'):
        # ask matplotlib for the plotted objects and their labels
        lines, labels = packtempfig_tempax.get_legend_handles_labels()
        lines2, labels2 = packtempfig_tempdeltaax.get_legend_handles_labels()
        lines3, labels3 = packtempfig_currentax.get_legend_handles_labels()
        lines4, labels4 = packtempfig_socax.get_legend_handles_labels()
        packtempfig_tempax.legend(lines + lines2 + lines3 + lines4, labels + labels2 + labels3 + labels4)
    
    plt.xlim(min(time_hrs), max(time_hrs))
    packtempfig_tempax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)
    
    plt.title("Pack Temperatures")
    packtempfig.set_size_inches(16, 12)
    plt.show()
    
    if savefig:
        packtempfig.savefig(
            os.path.join(fig_dir, fname_prefix + '_Temperatures_Pack.png'),
            format='png',
            dpi=400,
            bbox_inches='tight')

def plot_estbricktemp(
        time_secs,
        tempsensorvals,
        estbricktemps, 
        savefig = False, fig_dir = '', fname_prefix = '' ):
        """
        This function plots estimated brick temperatures vs. time

        Parameters
        ----------
        time_secs : TYPE
            DESCRIPTION.
        tempsensorvals : TYPE
            DESCRIPTION.
        estbricktemps : TYPE
            DESCRIPTION.
        savefig : TYPE, optional
            DESCRIPTION. The default is True.
        fig_dir : TYPE, optional
            DESCRIPTION. The default is fig_dir.
        fname_prefix : TYPE, optional
            DESCRIPTION. The default is fname_prefix.

        Returns
        -------
        None.

        """
        
        time_hrs = [tsec/3600 for tsec in time_secs]
        
        with mpl.rc_context(fname='RA_BMS.rc'):
    
            #tsensewt_df = cellcalib_fileobj.parse('OCV', header = 1, index_col = 1)
    
            bricktempfig, bricktempfig_tempax = plt.subplots(num = 'Temperatures_BrickEst')
            for tsensor in range(0, len(tempsensorvals.columns)):
                bricktempfig_tempax.plot(
                    time_hrs, 
                    pad(tempsensorvals.iloc[:, tsensor]), 
                    label = "Sensor " + str(tsensor+1).zfill(1))
    
            for brick in range(0, len(estbricktemps.columns)):
                bricktempfig_tempax.plot(
                    time_hrs, 
                    pad(estbricktemps.iloc[:, brick]), 
                    label = "Brick " + str(brick+1).zfill(2))
    
            bricktempfig_tempax.set_xlabel("Time (hrs)")
            bricktempfig_tempax.set_ylabel(r"Temperature ($\degree$C)")
    
        plt.xlim(min(time_hrs), max(time_hrs))
        bricktempfig_tempax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)
        # Put legend on top left
        plt.legend(loc = 'upper left', fontsize = 'small')
    
        plt.title("Estimated Brick Temperatures")
        bricktempfig.set_size_inches(16, 12)
        plt.show()
    
        if savefig:
            bricktempfig.savefig(
                os.path.join(fig_dir, fname_prefix + '_Temperatures_BrickEstimated.png'),
                format='png',
                dpi=400,
                bbox_inches='tight')