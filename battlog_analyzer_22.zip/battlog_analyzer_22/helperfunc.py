# -*- coding: utf-8 -*-
"""
Created on Mon Jan 25 12:26:04 2021

@author: ranand
"""
import sys 
if 'np' not in sys.modules:
    import numpy as np
if 'pd' not in sys.modules:
    import pandas as pd
if 'dt' not in sys.modules:
    import datetime as dt

#%%
def isNaN(num):
    return num != num

#%% Padding function to remove invalid values (zeroes right now)
def pad(data):
    bad_indexes = np.where(data == 0)[0]
    good_indexes = np.where(data != 0)[0]
    interpolated = np.interp(bad_indexes, good_indexes, data[good_indexes])
    data_copy = data.copy()
    data_copy[bad_indexes] = interpolated
    return data_copy

#%% Strip function to pull first value out of a series
def strip(data):
    return (data[0] if isinstance(data, pd.Series) else data) 

#%% Function to write error logs to a txt file
def write_error(message, err_path = r"" ):
    """ 
    The Error/warning log creater (ex: missing temperature values, no such files, etc.)
    arguments : 
                    message   : The error message to be logged
                    err_path  : location to save error log 
    
    """
    
    file1 = open(err_path+"log.txt","a")
    file1.write(str(dt.datetime.now()) +" : " + message +"\n") 
    file1.close() 
