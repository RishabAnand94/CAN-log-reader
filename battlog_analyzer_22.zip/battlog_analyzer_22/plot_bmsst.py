# -*- coding: utf-8 -*-
"""
Created on Mon Jan 25 14:38:21 2021

@author: ranand
"""

import sys
if 'mpl' not in sys.modules:
    import matplotlib as mpl 
if 'plt' not in sys.modules:
    import matplotlib.pyplot as plt
# if 'os' not in sys.modules:
#     import os

import os

rcdict02 = {'ytick.labelsize': 14, 'axes.labelsize': 14}

def plot_bms_state(
    time_secs, 
    vcu_streq, 
    bms_st,
    bm1_st,
    bm2_st = None, 
    bm3_st = None,
    bm4_st = None,
    savefig = True, fig_dir = '', fname_prefix = ''):
    """
    This function plots the VCU state request and the actual BMS state vs. time

    Parameters
    ----------
    time_sec : TYPE
        DESCRIPTION.
    sig_vcu_streq : TYPE
        DESCRIPTION.
    sig_bms_st : TYPE
        DESCRIPTION.
    savefig : TYPE, optional
        DESCRIPTION. The default is True.
    fig_dir : TYPE, optional
        DESCRIPTION. The default is ''.
    fname_prefix : TYPE, optional
        DESCRIPTION. The default is ''.

    Returns
    -------
    None.

    """
    
    time_hrs = [tsec/3600 for tsec in time_secs]
    
    with mpl.rc_context(fname='RA_BMS.rc'):
        battstfig, battstfig_reqax = plt.subplots(num = 'Battery_State')
        # VCU Requested State
        battstfig_reqax.plot(
            time_hrs, 
            vcu_streq, 
            label = 'VCU Request')
        
        battstfig_reqax.set_xlabel('Time (hours)')
        battstfig_reqax.set_ylabel('VCU State Request')
                    
    with mpl.rc_context(rcdict02): 
        battstfig_stax = battstfig_reqax.twinx()
        # Aggregated State
        battstfig_stax.plot(
            time_hrs, 
            bms_st, 
            label = 'BMS State')
        # Module 1 State
        battstfig_stax.plot(
            time_hrs, 
            bm1_st, 
            label = 'BM1 State')
        # Module 2 State
        if bm2_st is not None:
            battstfig_stax.plot(
                time_hrs, 
                bm2_st, 
                label = 'BM2 State')
        # Module 3 State
        if bm3_st is not None:
            battstfig_stax.plot(
                time_hrs, 
                bm3_st, 
                label = 'BM3 State')
        # Module 4 State
        if bm4_st is not None:
            battstfig_stax.plot(
                time_hrs, 
                bm4_st, 
                label = 'BM4 State')
        
        battstfig_stax.set_ylabel('BMS State')
        battstfig_stax.grid(None)
    
    with mpl.rc_context(fname='RA_BMS.rc'):        
        # ask matplotlib for the plotted objects and their labels
        lines, labels = battstfig_stax.get_legend_handles_labels()
        lines2, labels2 = battstfig_reqax.get_legend_handles_labels()
        battstfig_stax.legend(lines + lines2, labels + labels2)
        
    plt.xlim(min(time_hrs), max(time_hrs))    
    battstfig_stax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)
    
    plt.title("Requested and Actual BMS States")
    battstfig.set_size_inches(16, 12)
    plt.show()
    
    if savefig:
        battstfig.savefig(
            os.path.join(fig_dir, fname_prefix + '_State_BMS.png'),
            format='png',
            dpi=400,
            bbox_inches='tight')