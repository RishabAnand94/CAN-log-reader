# -*- coding: utf-8 -*-
"""
Created on Fri Jan 29 10:41:35 2021

@author: ranand
"""

import sys
if 'mpl' not in sys.modules:
    import matplotlib as mpl 
if 'plt' not in sys.modules:
    import matplotlib.pyplot as plt
# if 'os' not in sys.modules:
#     import os

import os

rcdict02 = {'ytick.labelsize': 14, 'axes.labelsize': 14}

def plot_pack_volt_current(
    time_secs,
    can_packvoltage, can_loadvoltage, can_packcurrent,
    can_modvoltage1 = None, can_loadvoltage1 = None, can_modcurrent1 = None,
    can_modvoltage2 = None, can_loadvoltage2 = None, can_modcurrent2 = None,
    can_modvoltage3 = None, can_loadvoltage3 = None, can_modcurrent3 = None,
    can_modvoltage4 = None, can_loadvoltage4 = None, can_modcurrent4 = None,
     
    tester_voltage = None,
    tester_current = None,
    index_cyclebegin = None, index_cycleend = None, index_rv_postcycle = None, \
    savefig = True, fig_dir = '', fname_prefix = ''):
    """
    This function plots pack voltage and current from the CAN logs against
    those from the pack tester.

    Parameters
    ----------
    time_secs : TYPE
        DESCRIPTION.
    can_modvoltage : TYPE
        DESCRIPTION.
    can_loadvoltage : TYPE
        DESCRIPTION.
    can_modcurrent : TYPE
        DESCRIPTION.
    tester_voltage : TYPE, optional
        DESCRIPTION. The default is None.
    tester_current : TYPE, optional
        DESCRIPTION. The default is None.
    index_cyclebegin : TYPE, optional
        DESCRIPTION. The default is None.
    index_cycleend : TYPE, optional
        DESCRIPTION. The default is None.
    index_rv_postcycle : TYPE, optional
        DESCRIPTION. The default is None.
    savefig : TYPE, optional
        DESCRIPTION. The default is True.
    fig_dir : TYPE, optional
        DESCRIPTION. The default is ''.
    fname_prefix : TYPE, optional
        DESCRIPTION. The default is ''.

    Returns
    -------
    None.

    """
    
    time_hrs = [tsec/3600 for tsec in time_secs]

    with mpl.rc_context(fname='RA_BMS.rc'):
        packvoltfig, packvoltfig_voltax = plt.subplots(num = 'Voltage_Pack')
        if tester_voltage is not None:
            packvoltfig_voltax.plot(
                time_hrs, 
                tester_voltage, 
                label = "Pack Voltage - Tester")
        
        packvoltfig_voltax.plot(
            time_hrs, 
            can_packvoltage, 
            label = 'Pack Voltage - CAN')
        
        packvoltfig_voltax.plot(
            time_hrs, 
            can_loadvoltage, 
            label = 'Load Voltage - CAN')
        
        if can_modvoltage1 is not None:
            packvoltfig_voltax.plot(
                time_hrs, 
                can_modvoltage1, 
                label = 'Module1 Voltage - CAN')
    
            packvoltfig_voltax.plot(
                time_hrs, 
                can_loadvoltage1, 
                label = 'Load Voltage 1 - CAN')
        
        if can_modvoltage2 is not None:
            packvoltfig_voltax.plot(
            time_hrs, 
            can_modvoltage2, 
            label = 'Module2 Voltage - CAN')
            
            packvoltfig_voltax.plot(
            time_hrs, 
            can_loadvoltage2, 
            label = 'Load Voltage 2 - CAN')
        
        if can_modvoltage3 is not None:
            packvoltfig_voltax.plot(
            time_hrs, 
            can_modvoltage3, 
            label = 'Module3 Voltage - CAN')
            
            packvoltfig_voltax.plot(
            time_hrs, 
            can_loadvoltage3, 
            label = 'Load Voltage 3 - CAN')
            
        if can_modvoltage4 is not None:
            packvoltfig_voltax.plot(
            time_hrs, 
            can_modvoltage4, 
            label = 'Module4 Voltage - CAN')
              
            packvoltfig_voltax.plot(
            time_hrs, 
            can_loadvoltage4, 
            label = 'Load Voltage 4 - CAN')
        
        plt.ylim(45, 55)
        #plt.autoscale(axis = 'y', tight = None)
        
        packvoltfig_voltax.set_xlabel('Time (hours)')
        packvoltfig_voltax.set_ylabel('Pack Voltage (V)')

    with mpl.rc_context(rcdict02):
        packvoltfig_currentax = packvoltfig_voltax.twinx()
        if tester_current is not None:
            packvoltfig_currentax.plot(
                time_hrs, 
                tester_current, 
                label = "Pack Current - Tester")
        
        packvoltfig_currentax.plot(
            time_hrs, 
            can_packcurrent, 
            label = "Pack Current - CAN")
        
        if can_modcurrent1 is not None:
            packvoltfig_currentax.plot(
            time_hrs, 
            can_modcurrent1, 
            label = "Module1 Current - CAN")
        
        if can_modcurrent2 is not None:
            packvoltfig_currentax.plot(
            time_hrs, 
            can_modcurrent2, 
            label = "Module2 Current - CAN")
            
        if can_modcurrent3 is not None:
            packvoltfig_currentax.plot(
            time_hrs, 
            can_modcurrent3, 
            label = "Module3 Current - CAN")
            
        if can_modcurrent4 is not None:
            packvoltfig_currentax.plot(
            time_hrs, 
            can_modcurrent4, 
            label = "Module4 Current - CAN")
        
        packvoltfig_currentax.set_ylabel("Pack Current (A)")
        packvoltfig_currentax.grid(None)

        if index_cyclebegin is not None:
            plt.axvline(time_secs[index_cyclebegin]/3600)   # ymin = 2.5*14, ymax = 4.2*14
            # text(index_tester_cyclebegin, 20, 'Cycle Start', rotation=90, verticalalignment='center')
        if index_cycleend is not None:
            plt.axvline(time_secs[index_cycleend]/3600)
            # text(index_tester_cycleend, 20, 'Cycle End', rotation=90, verticalalignment='center')
        if index_rv_postcycle is not None:
            plt.axvline(time_secs[index_rv_postcycle]/3600)

    with mpl.rc_context(fname='RA_BMS.rc'):
        lines, labels = packvoltfig_voltax.get_legend_handles_labels()
        lines2, labels2 = packvoltfig_currentax.get_legend_handles_labels()
        packvoltfig_voltax.legend(lines + lines2, labels + labels2)

    plt.xlim(min(time_hrs), max(time_hrs))
    packvoltfig_voltax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)

    plt.title("Pack Voltage and Current")
    packvoltfig.set_size_inches(16, 12)
    plt.show()

    if savefig:
        packvoltfig.savefig(
            os.path.join(fig_dir, fname_prefix + '_Voltage_Pack.png'),
            format='png',
            dpi=400,
            bbox_inches='tight')