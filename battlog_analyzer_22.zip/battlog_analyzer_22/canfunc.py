# -*- coding: utf-8 -*-
"""
Created on Mon Jan 25 09:06:39 2021

@author: ranand
"""
import sys

if 'pd' not in sys.modules:
    import pandas as pd
    
# if 'cantools' not in sys.modules:
#     import cantools
# if 'operator' not in sys.modules:
#     import operator

import can
import cantools
import operator
    
#%% CAN log file reader 
def read_canlog(canlog_filePath, logtype = 'log'):
    
    print("Reading CAN log file ...")
    # Sort file names in ascending order so that merging is correct
    canlog_filePath.sort()
    
    # Parse through all input data log files one-by-one
    for file_count in range(len(canlog_filePath)):
        if logtype == 'asc':
            log = can.ASCReader(canlog_filePath[file_count])    # Iterator of CAN messages from ASC log file
        elif logtype == 'log':   # Assumed to be a busmaster log file     
            log = can.io.CanutilsLogReader(canlog_filePath[file_count])    # Iterator of CAN messages from busmaster log file
        else:
            print('Unknown CAN log file format !')
            return -1
        
        candf_seg = pd.DataFrame(data = map(operator.attrgetter('timestamp', 'arbitration_id', 'data'), log), \
                                 columns = ['timestamp', 'arbitration_id', 'data'])
        print(candf_seg.iloc[1,:])
        
        if logtype == 'asc':
            # Make sure that the dataframe indices start from zero
            candf_seg.set_index(pd.to_datetime(candf_seg['timestamp'], unit = 's'), inplace = True)
            #candf.drop('timestamp', inplace = True)
            
        elif logtype == 'log':
            #candf.reset_index(inplace = True, drop = True)        
            #print(candf.loc[0, 'timestamp'])
            temp_candate = candf_seg.loc[0, 'timestamp'].split(' ')[0]  # First date only
            temp_candate = pd.to_datetime(temp_candate, dayfirst = True)
            
            if pd.to_timedelta(candf_seg.loc[0, 'timestamp'].split(' ')[1]).floor('1 d') > pd.to_timedelta('0 days'):
                print("Start time greater than 24:00 hrs in CAN log ...")
                temp_candate = temp_candate - pd.to_timedelta(candf_seg.loc[0, 'timestamp'].split(' ')[1]).floor('1 d')
            
            candf_seg['timestamp'] = temp_candate + pd.to_timedelta([ts.split(' ')[1] for ts in candf_seg['timestamp']])
            candf_seg.set_index('timestamp', inplace = True, drop = False)
            
            # TODO - Remove timestamp column from candf after fixing dependencies in error log and state change log extraction
            
            del temp_candate
            
            # Subtract time offset so that timestamps start from zero 
            # candf['timestamp'] -= candf.loc[0, 'timestamp']
            
        if file_count == 0:    
            # The complete dataframe does not exist when reading the first worksheet in the first file 
            candf = candf_seg
        else:
            # Concatenate the new dataframe piece to the complete dataframe
            candf = pd.concat([candf, candf_seg])
    
    # Clear up the last piece !            
    del candf_seg
    
    print("CAN log file reading complete.")
    return candf

#%% CAN message decoder 
def get_sigval_ts(logdf, candb, msg_name, signame, min_time, max_time):
    
    # Get message arbitration ID from message name 
    msg_obj = candb.get_message_by_name(msg_name)
    arb_id = msg_obj.frame_id

    # Separate relevant messages from the CAN log using the arbitration ID
    msgdf = logdf.loc[logdf['arbitration_id'] == arb_id]
    
    # Resample at 1 second frequency. Use forward fill (Value at or before time instant) for replacing missing values 
    msgdf = msgdf[~msgdf.index.duplicated(keep='first')]
    msgdf = msgdf.resample('1S').ffill()
    msgdf = msgdf.truncate(before = min_time, after = max_time)
    # Drop elements with missing values - cannot be decoded 
    msgdf.dropna(axis = 0, subset = ['arbitration_id', 'data'], inplace = True)

    # Create a dictionary of lists to store physical values of signals 
    sigval = {}
    for sig in signame:
        sigval[sig] = []
    
    # Now decode messages to extract signal physical values 
    for msgdf_index in msgdf.index:
        # Decode message to obtain physical values of all signals in that message
        allsigvals = candb.decode_message(msgdf.loc[msgdf_index, 'arbitration_id'], msgdf.loc[msgdf_index, 'data'])
        # Now append signals in relevant list 
        for sig in signame:
            sigval[sig].append(allsigvals[sig])
            
    return pd.DataFrame(sigval, index = msgdf.index)

#%% State change log creator
def get_statechangelog(logdf, candb, msg_name, signame):
    
    # Get message arbitration ID from message name 
    msg_obj = candb.get_message_by_name(msg_name)
    arb_id = msg_obj.frame_id

    # Separate relevant messages from the CAN log using the arbitration ID
    msgdf = logdf.loc[logdf['arbitration_id'] == arb_id]
    msgdf = msgdf[~msgdf.index.duplicated(keep='first')]
    
    # Create an empty list to store error flag set and clear points
    statechangelog = []
    
    # Check for non-existing signal resulting in empty list     
    if len(msgdf) > 0:
        # Read state values in the first message
        prev_allsigvals = candb.decode_message(msgdf.loc[msgdf.index[0], 'arbitration_id'], msgdf.loc[msgdf.index[0], 'data'])
        for sig in signame:
            # Add a flag set log if the first value itself is set
            statechangelog.append([msgdf.loc[msgdf.index[0], 'timestamp'], sig, prev_allsigvals[sig]])
            #statechangelog.append([msgdf.loc[msgdf.index[0], 'timestamp'], sig, prev_allsigvals[sig]])
                
        # Now decode second message onwards to extract signal values 
        for msgdf_index in msgdf.index[1 : len(msgdf.index)-1]:
            # Decode message to obtain physical values of all signals in that message
            allsigvals = candb.decode_message(msgdf.loc[msgdf_index, 'arbitration_id'], msgdf.loc[msgdf_index, 'data'])
            # Now append signals in relevant list 
            for sig in signame:
                if (allsigvals[sig] != prev_allsigvals[sig]):
                    statechangelog.append([msgdf.loc[msgdf_index, 'timestamp'], sig, allsigvals[sig]])
                    
            prev_allsigvals = allsigvals
       
    return statechangelog

#%% Error log creator
def get_errorlog(logdf, candb, msg_name, signame):
    
    # Get message arbitration ID from message name 
    msg_obj = candb.get_message_by_name(msg_name)
    arb_id = msg_obj.frame_id

    # Separate relevant messages from the CAN log using the arbitration ID
    msgdf = logdf.loc[logdf['arbitration_id'] == arb_id]
    msgdf = msgdf[~msgdf.index.duplicated(keep='first')]
    
    # Create an empty list to store error flag set and clear points
    errorlog = []
    
    # Check for non-existing signal resulting in empty list     
    if len(msgdf) > 0:
        # Read error flag values in the first fault/event message
        prev_allsigvals = candb.decode_message(msgdf.loc[msgdf.index[0], 'arbitration_id'], msgdf.loc[msgdf.index[0], 'data'])
        for sig in signame:
            if (prev_allsigvals[sig]):
                # Add a flag set log is the first value itself is set
                errorlog.append([msgdf.loc[msgdf.index[0], 'timestamp'], sig, 'SET'])
                
        # Now decode second message onwards to extract signal values 
        for msgdf_index in msgdf.index[1 : len(msgdf.index)-1]:
            # Decode message to obtain physical values of all signals in that message
            allsigvals = candb.decode_message(msgdf.loc[msgdf_index, 'arbitration_id'], msgdf.loc[msgdf_index, 'data'])
            # Now append signals in relevant list 
            for sig in signame:
                if (allsigvals[sig] and (not(prev_allsigvals[sig]))):
                    errorlog.append([msgdf.loc[msgdf_index, 'timestamp'], sig, 'SET'])
                elif (not(allsigvals[sig]) and (prev_allsigvals[sig])):
                    errorlog.append([msgdf.loc[msgdf_index, 'timestamp'], sig, 'CLEAR'])
                    
            prev_allsigvals = allsigvals
       
    return errorlog
