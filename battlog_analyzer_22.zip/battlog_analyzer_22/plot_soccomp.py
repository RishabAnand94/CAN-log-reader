# -*- coding: utf-8 -*-
"""
Created on Tue Feb 16 09:40:31 2021

@author: ranand
"""

import sys
if 'mpl' not in sys.modules:
    import matplotlib as mpl 
if 'plt' not in sys.modules:
    import matplotlib.pyplot as plt
# if 'os' not in sys.modules:
#     import os

import os
from helperfunc import pad

rcdict02 = {'ytick.labelsize': 14, 'axes.labelsize': 14}

def plot_socs(
    time_secs, \
    can_packvolt, \
    bricksocs = None, can_packsoc = None, \
    soctrim_min = None, soctrim_max = None, trimmed_packsoc = None, \
    savefig = False, fig_dir = '', fname_prefix = '' ):
    
    time_hrs = [tsec/3600 for tsec in time_secs]
    
    with mpl.rc_context(fname='RA_BMS.rc'):
        socfig, socfig_socax = plt.subplots(num = 'SoC_Pack')
        
        if bricksocs is not None:
            for brick in range(0, len(bricksocs.columns)):
                socfig_socax.plot(time_hrs, pad(bricksocs.iloc[:, brick]), label = "Brick " + str(brick+1).zfill(2), linewidth = 0.5)
    
        socfig_socax.plot(time_hrs, can_packsoc, label = "Pack SoC", color = 'black')
        if soctrim_min is not None:
            socfig_socax.plot(time_hrs, soctrim_min, label = "SoC Trim - Min")
            socfig_socax.plot(time_hrs, soctrim_max, label = "SoC Trim - Max")
            socfig_socax.plot(time_hrs, trimmed_packsoc, label = "Pack SoC - Trimmed")
    
        socfig_socax.set_xlabel("Time (hrs)")
        socfig_socax.set_ylabel("SoC (%)")
    
    with mpl.rc_context(rcdict02):
        socfig_voltax = socfig_socax.twinx()
        socfig_voltax.plot(time_hrs, can_packvolt, label = "Pack Voltage")
        socfig_voltax.set_ylabel("Voltage (V)")
        socfig_voltax.grid(None)
    
    plt.xlim((min(time_hrs), max(time_hrs)))
    socfig_socax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)
    
    with mpl.rc_context(fname='RA_BMS.rc'):
        lines, labels = socfig_socax.get_legend_handles_labels()
        lines2, labels2 = socfig_voltax.get_legend_handles_labels()
        socfig_socax.legend(lines + lines2, labels + labels2)
    
    plt.title("Brick and Pack SoCs")
    socfig.set_size_inches(16, 12)
    plt.show()
    
    if savefig:
        socfig.savefig(
            os.path.join(fig_dir, fname_prefix + '_SoC_Pack.png'),
            format='png',
            dpi=400,
            bbox_inches='tight')


def plot_compsoc(
    time_secs, \
    bricksocs, \
    init_ocvsocs, \
    init_cellcaps, \
    can_ah, \
    tester_ah = None, \
    savefig = False, fig_dir = '', fname_prefix = '' ):

    time_hrs = [tsec/3600 for tsec in time_secs]
    
    socbrickfig1, ((ax01, ax02), (ax03, ax04)) = plt.subplots(2, 2, num = 'SoCs_Bricks1to4')
    socbrickfig2, ((ax05, ax06), (ax07, ax08)) = plt.subplots(2, 2, num = 'SoCs_Bricks5to8')
    socbrickfig3, ((ax09, ax10), (ax11, ax12)) = plt.subplots(2, 2, num = 'SoCs_Bricks9to12')
    socbrickfig4, ((ax13, ax14), (ax15, ax16)) = plt.subplots(2, 2, num = 'SoCs_Bricks13to14')
    axdict = {1: ax01, 2: ax02, 3: ax03, 4: ax04, \
              5: ax05, 6: ax06, 7: ax07, 8: ax08, \
              9: ax09, 10: ax10, 11: ax11, 12: ax12, \
              13: ax13, 14: ax14 }
    
    
    for brick in range(1, len(bricksocs.columns)+1):
        with mpl.rc_context(fname='RA_BMS.rc'):
            axname = axdict[brick]
            axname.plot(time_hrs, pad(bricksocs.iloc[:, brick-1]), label = "SoC - CAN", linewidth = 0.5)
    
            axname.plot(time_hrs, init_ocvsocs[brick] + (100/18)*can_ah/init_cellcaps[brick], label = "SoC - CAN Current", linewidth = 0.5)
            if tester_ah is not None:
                axname.plot(time_hrs, init_ocvsocs[brick] + (100/18)*tester_ah/init_cellcaps[brick], label = "SoC - Tester Current", linewidth = 0.5)
    
            axname.title.set_text('Brick '+ str(brick).zfill(2))
            axname.set_xlabel("Time (hrs)", fontsize = 8)
            axname.set_ylabel("CAN SoC (%)", fontsize = 8)
            axname.set_xlim((min(time_hrs), max(time_hrs)))
    
        with mpl.rc_context(rcdict02):
            twinaxname = axname.twinx()
            twinaxname.plot(time_hrs, (init_ocvsocs[brick] + (100/18)*can_ah/init_cellcaps[brick]) - pad(bricksocs.iloc[:, brick-1]), label = "SoC Error - CAN", linewidth = 0.5)
            if tester_ah is not None:
                twinaxname.plot(time_hrs, (init_ocvsocs[brick] + (100/18)*tester_ah/init_cellcaps[brick]) - pad(bricksocs.iloc[:, brick-1]), label = "SoC Error - Tester", linewidth = 0.5)
            twinaxname.set_ylabel("SoC Estimation Error (%)", fontsize = 8)
            twinaxname.grid(None)
    
        with mpl.rc_context(fname='RA_BMS.rc'):
            lines, labels = axname.get_legend_handles_labels()
            lines2, labels2 = twinaxname.get_legend_handles_labels()
            axname.legend(lines + lines2, labels + labels2, fontsize = 8)
    
    ax15.axis('off')
    ax16.axis('off')
    
    socbrickfig1.set_size_inches(16, 12)
    socbrickfig2.set_size_inches(16, 12)
    socbrickfig3.set_size_inches(16, 12)
    socbrickfig4.set_size_inches(16, 12)
    
    if savefig:
        socbrickfig1.savefig(
            os.path.join(fig_dir, fname_prefix + '_SoC_Bricks1to4.png'),
            format='png',
            dpi=400,
            bbox_inches='tight')
        
        socbrickfig2.savefig(
            os.path.join(fig_dir, fname_prefix + '_SoC_Bricks5to8.png'),
            format='png',
            dpi=400,
            bbox_inches='tight')
        
        socbrickfig3.savefig(
            os.path.join(fig_dir, fname_prefix + '_SoC_Bricks9to12.png'),
            format='png',
            dpi=400,
            bbox_inches='tight')
        
        socbrickfig4.savefig(
            os.path.join(fig_dir, fname_prefix + '_SoC_Bricks13to14.png'),
            format='png',
            dpi=400,
            bbox_inches='tight')

def plot_comppacksoc(
    time_secs, \
    packsoc, \
    init_ocvsoc, \
    init_cellcaps, \
    can_ah, \
    tester_ah = None, \
    savefig = False, fig_dir = '', fname_prefix = '' ):

    time_hrs = [tsec/3600 for tsec in time_secs]
    
    socbrickfig1, ((ax01, ax02), (ax03, ax04)) = plt.subplots(2, 2, num = 'SoCs_Bricks1to4')
    socbrickfig2, ((ax05, ax06), (ax07, ax08)) = plt.subplots(2, 2, num = 'SoCs_Bricks5to8')
    socbrickfig3, ((ax09, ax10), (ax11, ax12)) = plt.subplots(2, 2, num = 'SoCs_Bricks9to12')
    socbrickfig4, ((ax13, ax14), (ax15, ax16)) = plt.subplots(2, 2, num = 'SoCs_Bricks13to14')
    axdict = {1: ax01, 2: ax02, 3: ax03, 4: ax04, \
              5: ax05, 6: ax06, 7: ax07, 8: ax08, \
              9: ax09, 10: ax10, 11: ax11, 12: ax12, \
              13: ax13, 14: ax14 }
    
    
    for brick in range(1, len(bricksocs.columns)+1):
        with mpl.rc_context(fname='RA_BMS.rc'):
            axname = axdict[brick]
            axname.plot(time_hrs, pad(bricksocs.iloc[:, brick-1]), label = "SoC - CAN", linewidth = 0.5)
    
            axname.plot(time_hrs, init_ocvsocs[brick] + (100/18)*can_ah/init_cellcaps[brick], label = "SoC - CAN Current", linewidth = 0.5)
            if tester_ah is not None:
                axname.plot(time_hrs, init_ocvsocs[brick] + (100/18)*tester_ah/init_cellcaps[brick], label = "SoC - Tester Current", linewidth = 0.5)
    
            axname.title.set_text('Brick '+ str(brick).zfill(2))
            axname.set_xlabel("Time (hrs)", fontsize = 8)
            axname.set_ylabel("CAN SoC (%)", fontsize = 8)
            axname.set_xlim((min(time_hrs), max(time_hrs)))
    
        with mpl.rc_context(rcdict02):
            twinaxname = axname.twinx()
            twinaxname.plot(time_hrs, (init_ocvsocs[brick] + (100/18)*can_ah/init_cellcaps[brick]) - pad(bricksocs.iloc[:, brick-1]), label = "SoC Error - CAN", linewidth = 0.5)
            if tester_ah is not None:
                twinaxname.plot(time_hrs, (init_ocvsocs[brick] + (100/18)*tester_ah/init_cellcaps[brick]) - pad(bricksocs.iloc[:, brick-1]), label = "SoC Error - Tester", linewidth = 0.5)
            twinaxname.set_ylabel("SoC Estimation Error (%)", fontsize = 8)
            twinaxname.grid(None)
    
        with mpl.rc_context(fname='RA_BMS.rc'):
            lines, labels = axname.get_legend_handles_labels()
            lines2, labels2 = twinaxname.get_legend_handles_labels()
            axname.legend(lines + lines2, labels + labels2, fontsize = 8)
    
    ax15.axis('off')
    ax16.axis('off')
    
    socbrickfig1.set_size_inches(16, 12)
    socbrickfig2.set_size_inches(16, 12)
    socbrickfig3.set_size_inches(16, 12)
    socbrickfig4.set_size_inches(16, 12)
    
    if savefig:
        socbrickfig1.savefig(
            os.path.join(fig_dir, fname_prefix + '_SoC_Bricks1to4.png'),
            format='png',
            dpi=400,
            bbox_inches='tight')
        
        socbrickfig2.savefig(
            os.path.join(fig_dir, fname_prefix + '_SoC_Bricks5to8.png'),
            format='png',
            dpi=400,
            bbox_inches='tight')
        
        socbrickfig3.savefig(
            os.path.join(fig_dir, fname_prefix + '_SoC_Bricks9to12.png'),
            format='png',
            dpi=400,
            bbox_inches='tight')
        
        socbrickfig4.savefig(
            os.path.join(fig_dir, fname_prefix + '_SoC_Bricks13to14.png'),
            format='png',
            dpi=400,
            bbox_inches='tight')

