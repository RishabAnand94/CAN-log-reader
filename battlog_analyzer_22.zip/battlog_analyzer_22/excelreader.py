# -*- coding: utf-8 -*-
"""
Created on Thu Jan 21 10:40:50 2021

@author: ranand
"""

def read_excel(
    testerlog_filePath, collist, timestampIndex = False, 
    start_sheet = 0, start_row = 0, 
    end_sheet = -1, end_row = 0,
    max_sampletime_thr = '61S'):

#------------------------------------------------------------------------------
#   Current Version - 0.3, Date - 19 Mar 2021
#------------------------------------------------------------------------------
#   Version - 0.2, Date - 21 Jan 2021
#   - Initial Release
#   Version - 0.3, Date - 19 Mar 2021
#   - Fix for correctly merging total capacity and energy columns 
#     across multiple log files
#   - Current and terminal voltage are reported as zero for missing entries
#     in resampled data  
#------------------------------------------------------------------------------
#   Inputs to function 
#   1. [List] of log file paths 
#   2. [Boolean] Whether a timestamp indexed dataframe is to be returned 
#   TODO - [List] of columns in file to be read 
#   3. Start sheet number in first workbook in list
#   4. Start row in first sheet of first workbook in list 
#   5. End sheet number in last workbook in list
#   6. End row in last sheet of last workbook in list 
#   7. Max sampletime threshold to check for broken logs

#   Outputs from function 
#   1. Pandas dataframe containing relevant data
#------------------------------------------------------------------------------
    import sys
    if 'pd' not in sys.modules:
        import pandas as pd
    
    # Data column names 
    colname_datetime = "TEST TIME"
    colname_time = "Real Time(ms)"                  # Time elapsed in ms 
    # colname_stepmode = "Step Mode"                  # Step mode 
    colname_terminalvoltage = "Voltage(V)"          # Terminal voltage 
    colname_current = "Current(A)"                  # Cell current 
    colname_totalcapacity = "Total Capacity(Ah)"    # Cumulative capacity
    colname_totalenergy = "Total KWh(KWh)"               # Cumulative energy
    
    # collist = [colname_datetime, colname_time, colname_stepmode, \
    #            colname_terminalvoltage, colname_current, \
    #            colname_totalcapacity, colname_energy]
    
    # Need datetime and real time columns to return a timestamped dataframe    
    if timestampIndex:
        if colname_datetime not in collist:
            collist.append(colname_datetime)
        if colname_time not in collist:
            collist.append(colname_time)
    
    # Sort file names in ascending order so that merging is correct
    testerlog_filePath.sort();
       
    print("Reading tester log file ... ")
    # Parse through all input data log files one-by-one
    for file_count in range(len(testerlog_filePath)):
        testerlog_file = pd.ExcelFile(testerlog_filePath[file_count])
        input_sheets = testerlog_file.sheet_names
        
        if file_count < (len(testerlog_filePath)-1) or end_sheet == -1: # If end sheet at default value 
            end_sheet = len(input_sheets)-1
       
        # Parse through all sheets in the input file one-by-one
        #print(start_sheet, ' ', end_sheet)
        for sheet_count in range(start_sheet, end_sheet+1):
            #print(sheet_count)
            tester_df_segment = testerlog_file.parse(input_sheets[sheet_count])
            
            # Delete banner added by the cell/pack tester control software
            # Assumed that banner information is not present in column 4
            try:
                first_row = tester_df_segment[tester_df_segment.columns[4]].first_valid_index()
            except IndexError:
                print(sheet_count +1  , "th sheet does not have valid data")
                continue
            #print(first_row)
            column_names = tester_df_segment.loc[first_row]
            first_row += 1  # Move to first row containing data
            #print(column_names)
            
            if file_count == 0 and sheet_count == 0:    # First worksheet of first workbook
                if start_row-2 > first_row:   # Specified start row larger than first row
                    first_row = start_row-2
                    
                if (file_count < len(testerlog_filePath)-1) or (sheet_count < end_sheet):   # Not the last sheet in the last workbook
                    tester_df_segment = pd.DataFrame(tester_df_segment.values[first_row: ], columns = column_names)
                else:   # Also the last sheet in the last workbook - single workbook with single sheet
                    tester_df_segment = pd.DataFrame(tester_df_segment.values[first_row: end_row-1], columns = column_names)
                   
                # Get rid of unwanted columns - assumed that the surface temperature values are present in the last column
                tester_df_segment = tester_df_segment[collist]
                # The complete dataframe does not exist when reading the first worksheet in the first file 
                tester_df = tester_df_segment  
                
            else:   # Not the first worksheet of the first workbook
                if file_count == len(testerlog_filePath)-1 and sheet_count == end_sheet:    # Last sheet of last workbook - last workbook may have single sheet
                    tester_df_segment = pd.DataFrame(tester_df_segment.values[first_row: end_row-1], columns = column_names)
                    
                else:   # Neither the first sheet of the first workbook nor the last sheet of the last workbook
                    tester_df_segment = pd.DataFrame(tester_df_segment.values[first_row: ], columns = column_names)
                    
                if sheet_count == 0:    # First sheet in a file other than the first file - last workbook may have single sheet
                    # Total energy and total capacity columns should be added across multiple tester log files
                    # Total kWh and total energy do not reset across sheets in the same file
                    if (tester_df_segment.loc[0, colname_time] < tester_df.loc[len(tester_df) - 1, colname_time]) :    
                            if colname_totalcapacity in collist:    
                                tester_df_segment.loc[:, colname_totalcapacity] \
                                    += tester_df.loc[len(tester_df) - 1, colname_totalcapacity]
                            if colname_totalenergy in collist:
                                tester_df_segment.loc[:, colname_totalenergy] \
                                    += tester_df.loc[len(tester_df) - 1, colname_totalenergy]
            
                tester_df_segment = tester_df_segment[collist]
                # Concatenate the new dataframe piece to the complete dataframe
                tester_df = pd.concat([tester_df, tester_df_segment])
                # Reset index after every merge to keep last index consistent
                tester_df.reset_index(inplace = True, drop = True)
                
    # Clear up the last piece !            
    del tester_df_segment
    del file_count, testerlog_file, input_sheets, sheet_count, first_row, column_names
    
    # Need to adjust timestamps based on real time to avoid entries with the same timestamp 
    # Timestamp should be adjusted based on real time each time it resets to zero
    # Real Time in tester log does not shift back to zero if test is resumed
    
    #TODO - Return Date-Time column elements as Pandas datetime objects 
    
    if timestampIndex:
        print("Adjusting timestamps ...")
        
        timestamp_base = pd.to_datetime(tester_df[colname_datetime][0])
        realtime_base = tester_df[colname_time][0]
        tester_df.loc[0, 'adjusted_datetime'] = timestamp_base \
            + pd.to_timedelta((tester_df[colname_time][0] - realtime_base)/1000, unit = 's')
        
        temp_df = pd.DataFrame(columns = collist)
        for index in range(1, len(tester_df)):
            if (pd.to_datetime(tester_df[colname_datetime][index]) \
                - pd.to_datetime(tester_df[colname_datetime][index-1]) > pd.to_timedelta(max_sampletime_thr)):
                
                # Tester current must be zero if log entry is missing !!
                line = tester_df.iloc[index-1, :]
                if colname_current in collist:
                    line[colname_current] = 0
                if colname_terminalvoltage in collist:
                    line[colname_terminalvoltage] = 0
                line['adjusted_datetime'] = line['adjusted_datetime'] + pd.to_timedelta('1S')
                temp_df = temp_df.append(line)
                
                # Shift timestamp base
                timestamp_base = pd.to_datetime(tester_df[colname_datetime][index])
                realtime_base = tester_df[colname_time][index]
                
            tester_df.loc[index, 'adjusted_datetime'] = timestamp_base \
                + pd.to_timedelta((tester_df[colname_time][index] - realtime_base)/1000, unit = 's')
        
        del timestamp_base, realtime_base
        tester_df = pd.concat([tester_df, temp_df])
        tester_df.sort_index(inplace = True)
        del temp_df
        
        # Set datetime column as the index of the input dataframe    
        tester_df.set_index('adjusted_datetime', inplace = True, drop = True)
        tester_df.drop([colname_datetime], axis = 1, inplace = True)
        
        print("Resampling data ...")
        # Remove rows with duplicate indices before resampling 
        tester_df = tester_df[~tester_df.index.duplicated(keep='first')]
        # Resample to 1 sec smapling rate
        min_time = tester_df.index[0].ceil('1S')
        max_time = tester_df.index[-1].floor('1S')
        #tester_df = tester_df.resample('1S')
        tester_df = tester_df.resample('1S').ffill()
        tester_df = tester_df.truncate(before = min_time, after = max_time)
        del min_time, max_time
    
        # Eliminate date information from tester log timestamp 
        #date_tester = tester_df.index[0] - (tester_df.index[0] - tester_df.index[0].floor('1D'))
        #tester_df.index = tester_df.index - (tester_df.index[0] - pd.to_datetime(0)).floor('1D')
    
    # tester_df['time_sec_tester'] = (tester_df.index - tester_df.index[0].floor('1D')).total_seconds()
    
    print("Tester log file reading complete. ")
    return tester_df 
    
 