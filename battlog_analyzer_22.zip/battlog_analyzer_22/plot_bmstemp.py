# -*- coding: utf-8 -*-
"""
Created on Mon Feb 15 12:43:04 2021

@author: ranand
"""
import sys
if 'mpl' not in sys.modules:
    import matplotlib as mpl 
if 'plt' not in sys.modules:
    import matplotlib.pyplot as plt
# if 'os' not in sys.modules:
#     import os

import os

rcdict02 = {'ytick.labelsize': 14, 'axes.labelsize': 14}

def plot_othertemperatures(time_secs, \
                           can_packcurrent, balance_count = None, \
                           fettemp = None, ambtemp = None, shunttemp = None, prechargetemp = None, \
                           sp_fetovertemp = None, cp_fetovertemp = None, \
                           savefig = False, fig_dir = '', fname_prefix = ''):
    
    time_hrs = [tsec/3600 for tsec in time_secs]
    temperaturefet_max_val = fettemp.max(axis=0)
    
    with mpl.rc_context(fname='RA_BMS.rc'):
        boardtempfig, boardtempfig_tempax = plt.subplots(num = 'Temperatures_Board')
        boardtempfig_tempax.plot(time_hrs, fettemp, label = "Main FET")
        if ambtemp is not None:
            boardtempfig_tempax.plot(time_hrs, ambtemp, label = "Ambient")
        if shunttemp is not None:
            boardtempfig_tempax.plot(time_hrs, shunttemp, label = "Shunt")
        if prechargetemp is not None:
            boardtempfig_tempax.plot(time_hrs, prechargetemp, label = "Precharge Resistors")
    
        if temperaturefet_max_val >= sp_fetovertemp:
            boardtempfig_tempax.hlines(y = sp_fetovertemp, xmin = min(time_hrs), xmax = max(time_hrs), color = 'red')
            boardtempfig_tempax.hlines(y = cp_fetovertemp, xmin = min(time_hrs), xmax = max(time_hrs), color = 'red', linestyle = '--')
    
        boardtempfig_tempax.set_xlabel("Time (hours)")
        boardtempfig_tempax.set_ylabel(r"Temperature ($\degree$C)")
        lines, labels = boardtempfig_tempax.get_legend_handles_labels()
    
    # twin object for two different y-axis on the sample plot
    with mpl.rc_context(rcdict02):
        boardtempfig_currentax = boardtempfig_tempax.twinx()
        boardtempfig_currentax.plot(time_hrs, can_packcurrent, label = "Pack Current", color = 'black')
        boardtempfig_currentax.set_ylabel("Pack Current (A)")
        boardtempfig_currentax.grid(None)
        lines2, labels2 = boardtempfig_currentax.get_legend_handles_labels()
    
        # Plot this only if in charging
        if balance_count is not None:
            boardtempfig_nbalax = boardtempfig_tempax.twinx()
            boardtempfig_nbalax.plot(time_hrs, balance_count, label = "Balancing Count", color = 'navy')
            boardtempfig_nbalax.set_ylabel('Cell Balancing Count')
            boardtempfig_nbalax.spines['right'].set_position(('outward', 60))
            boardtempfig_nbalax.grid(None)
            lines3, labels3 = boardtempfig_nbalax.get_legend_handles_labels()
    
    with mpl.rc_context(fname='RA_BMS.rc'):
        if balance_count is not None:
            boardtempfig_tempax.legend(lines + lines2 + lines3, labels + labels2 + labels3)
        else:
            boardtempfig_tempax.legend(lines + lines2, labels + labels2)
    
    plt.xlim((min(time_hrs), max(time_hrs)))
    boardtempfig_tempax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)
    
    plt.title("BMS PCB Temperatures")
    boardtempfig.set_size_inches(16, 12)
    plt.show()
    
    if savefig:
        boardtempfig.savefig(os.path.join(fig_dir, fname_prefix + '_Temperatures_BMS_PCB.png'),
                format='png',
                dpi=400,
                bbox_inches='tight')

