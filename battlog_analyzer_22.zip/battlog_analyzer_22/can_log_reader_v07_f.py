# -*- coding: utf-8 -*-
"""
Created on Mon Aug 31 13:34:43 2020

@author: ranand,jma

version 080621

"""

#%% Usage SOP
# CAN DBC file should be provided
# CAN log file in .asc format to be provided
# Chroma log file to be provided


#%%

import os

import easygui as eg

import numpy as np
import scipy.integrate

import matplotlib as mpl
import matplotlib.pyplot as plt
plt.style.use("RA01")


from IPython import get_ipython
get_ipython().run_line_magic('matplotlib', 'qt')

import pandas as pd
import datetime as dt

import cantools

import openpyxl as op
from openpyxl import load_workbook

from helperfunc import pad
from helperfunc import strip
from helperfunc import isNaN
from helperfunc import write_error

import warnings
warnings.filterwarnings("ignore")


import cellcalib

#%%NOT DYNAMIC YET
HW_VER = 2.1
SW_VER = ''


#%% RC parameter dictionaries for plots
rcdict02 = {'ytick.labelsize': 14, 'axes.labelsize': 14}


#%%  Signal List

# def can_log_reader_v07_f(testid, batterySN, testdesc, testtemp, calver, canlog_filename, testerlog_filename):  

#%% Read test details     
TSTR_PR = 0
MOD = 1
NP = 18

print('Reading test details ...')    

msg = "Enter test details ..."
title = "BAL Traction Battery Testing"
fieldNames = ["Test #", "Battery Serial Number", "Test Description", "Test Temperature", "Calibration Ver"]
default_fieldValues = ["", "SN01", "1C_Dch", "25degC"]
fieldValues = eg.multenterbox(msg, title, fieldNames, default_fieldValues)
print("Reply was: %s \n" % str(fieldValues))

testid = fieldValues[0]
batterySN = fieldValues[1]
testdesc = fieldValues[2]
testtemp = fieldValues[3]
calver = fieldValues[4]

# fieldValues[0] = str(testid)
# fieldValues[1] = batterySN
# fieldValues[2] = testdesc
# fieldValues[3] = testtemp

fname_prefix = 'Test#' + fieldValues[0] + '_' + fieldValues[1] + '_' + fieldValues[2] + '_' + str(fieldValues[3])

# Create directory to save generated figures and test report
fig_dir = "results\\" + fname_prefix
try:
    os.makedirs(fig_dir)
    print("Directory '% s' created ..." % fname_prefix)
except FileExistsError:
    print("The directory for %d already exist. Files may be overwritten !" %testid)

# TODO Read calibration version and fetch suitable LUTs
print("Calibration version is ", calver)
# global cal_ver
# cal_ver = calver
   
restvolt_from_soc, soc_from_restvolt, \
    r0_at_soc, r1_at_soc, \
    chginst_from_soc_f, chg10s_from_soc_f, chgcont_from_soc_f, \
    dchinst_from_soc_f, dch10s_from_soc_f, dchcont_from_soc_f \
        = cellcalib.cell_calib(calver)

del msg, title, fieldNames, default_fieldValues

#%% Read CAN and tester log file paths 
print("Reading CAN log file path ...")
# print(canlog_filename,"\n")
canlog_filePath = eg.fileopenbox(
    msg = 'Select CAN log file', 
    title = 'Charge / Discharge Test', 
    default = '*', 
    filetypes = ['*.asc'], 
    multiple = True)

# canlog_filePath = canlog_filename

# Read tester log file only if pack tester is present
if TSTR_PR:
    print("Reading tester log file path ...")
    # print(testerlog_filename,"\n")
    testerlog_filePath = eg.fileopenbox(
        msg = 'Select data log file', 
        title = 'Charge / Discharge Test', 
        default = '*', 
        filetypes = ['*.xls', '*.xlsx'], 
        multiple = True)
    
    # testerlog_filePath = testerlog_filename

#%% Load CAN log file
import canfunc
# Returns a timestamp indexed dataframe containing can messages
#candf = canfunc.read_canlog(canlog_filePath, logtype = 'log')
candf = canfunc.read_canlog(canlog_filePath, logtype = 'asc')

#%% Load CAN message database
print("\nLoading CAN DBC files ...")

# Find app version
appvermsg_id = 0x15700000
appvermsgdf = candf.loc[candf['arbitration_id'] == appvermsg_id]
if len(appvermsgdf) == 0:
    appvermsg_id = 0x15700010
    appvermsgdf = candf.loc[candf['arbitration_id'] == appvermsg_id]
appver = str(appvermsgdf['data'][1][0]) + '_' + str(appvermsgdf['data'][1][1]) + '_' + str(appvermsgdf['data'][1][2])
del appvermsgdf

# Check whether function available in application version
SOC_TRIM = 0        # Whether the module SoC signal is trimmed
SOC_TRIM_PACK = 0   # Whether the aggregated pack SoC signal is trimmed
DCH_POWAVL = 0      # Whether the discharge power limit is available on CAN 

print('Application version is ' + appver)

input_file = pd.ExcelFile(os.getcwd() + r"\lookup\Signal_list_new.xlsx")
df_dbc = input_file.parse("DBC_map")
try:
    # Select appropriate dbc files
    candb_filename      = df_dbc[df_dbc["app_ver"] == appver]["can_dbc"].values[0]
    diagdbc_filename    = df_dbc[df_dbc["app_ver"] == appver]["diag_dbc"].values[0]
    DCH_POWAVL          = df_dbc[df_dbc["app_ver"] == appver]["dch_powavl"].values[0]
    SOC_TRIM            = df_dbc[df_dbc["app_ver"] == appver]["soc_trim"].values[0]
    SOC_TRIM_PACK       = df_dbc[df_dbc["app_ver"] == appver]["soc_trim_pack"].values[0]
    
except:
    candb_filename = "dbc_BMS_v0.3.0.dbc"
    diagdbc_filename = "amp_debug_v5.dbc"   

del input_file, df_dbc     

candb_relfilepath = '\\candbc\\pack\\'
diagdbc_relfilepath = '\\candbc\\debug\\'

# Read BMS DBC file
candb = cantools.database.load_file(os.getcwd() + candb_relfilepath + candb_filename)
# Read BMS diagnostics DBC file
with open (os.getcwd()+diagdbc_relfilepath+diagdbc_filename, 'r') as diagdbc:
    candb.add_dbc(diagdbc)

del diagdbc
#del candb_filename, diagdbc_filename

print("CAN DBC files loaded:",candb_filename,diagdbc_filename)

#%% Extract pack current, pack voltage, CAN SoC, module temperatures, FET temperatures

#TODO - Put rampdown timer under state change tracker
  
# Create an array of time indices by looking at the min and max times
min_time = candf.index.min().ceil(freq = '1S') #+ pd.Timedelta('1S')
max_time = candf.index.max().floor(freq = '1S') #- pd.Timedelta('1S')
time_sec = pd.date_range(start = min_time, end = max_time, freq = '1S')

# Create a dataframe to save extracted signal values
signal_df = pd.DataFrame(index = time_sec)
del time_sec

print('Creating CAN signal list ...')
from canlist import *

# Aggregate signal list
signal_list = get_signal_list_aggr(candb_filename, diagdbc_filename)
# Template signal list for individual modules
signal_template = get_signal_list(candb_filename,diagdbc_filename)

# Determine number of modules in parallel
try:
    num_mods = canfunc.get_sigval_ts(candf, candb, "BMS_TerminalState", ["ESS_BMS_ParallelDet_Act_count"], min_time, max_time).iloc[0].values[0]
except Exception as ex:
    num_mods = 0

print("Expected modules: ",num_mods)

if (int(appver.split('_')[0])== 0 and int(appver.split('_')[1])<= 5 and int(appver.split('_')[2])<= 22):
    num_mods = 0
    signal_list.update(get_sig(signal_template, mod_id=0))  
else:
    num_mods = 1#????????????????????
    for mod_id_ in range(1,num_mods+1):
        signal_list.update(get_sig(signal_template, mod_id=mod_id_))

# if (int(appver.split('_')[0])== 0 and int(appver.split('_')[1])== 5 and int(appver.split('_')[2])== 37):
#     signal_list["VCU_Command_BMS"].pop("ETS_VCU_VCUDchgPwrExp_Act_W")
#     signal_list["VCU_Command_BMS"].append("ETS_VCU_VCUDchgPwrExp_Act_kW")

if candb_filename in ["dbc_BMS_v0.3.0.dbc", "dbc_BMS_v0.3.2.dbc", "dbc_BAL_BMS_v0.4.6.dbc"]: 
    DCH_vlim_label = 'ESS_BM*_DchgLimit_Max_V'
    DCH_vlim_label_pack = 'ESS_BMS_DchgLimit_Max_V'
else:
     DCH_vlim_label = 'ESS_BM*_DchgLimit_Min_V'
     DCH_vlim_label_pack = 'ESS_BMS_DchgLimit_Min_V'
     
vcu_exp_power = 'ETS_VCU_VCUDchgPwrExp_Act_W'
if appver in ["0_5_37", "0_5_38", "0_5_39", "0_6_2", "0_6_3", "0_6_5", "0_6_7", "0_6_10", "0_6_255"]:
    vcu_exp_power = 'ETS_VCU_VCUDchgPwrExp_Act_kW'
     
print("Signal list generated ...")

print('Extracting signal values ...')
# Now decode CAN messages 
for msg in signal_list.keys():
        signal_df_seg = canfunc.get_sigval_ts(candf, candb, msg, signal_list[msg], min_time, max_time)
        signal_df = signal_df.join(signal_df_seg, how='outer')

del signal_df_seg

# Remove date information from timestamps
signal_df.index = signal_df.index - (signal_df.index[0] - pd.to_datetime(0)).floor('1D')

# Find time instants for beginning and end of cycle in the CAN log
curr_diff = np.diff(signal_df.loc[:, 'ESS_BM1_iMod_Act_A'])
currdelta_vals = [x for x in curr_diff if abs(x) > 0.5]
if len(currdelta_vals) > 0:
    index_can_cyclebegin = np.where(curr_diff == currdelta_vals[0])[0][0] + 1
    index_can_cyclebegin = signal_df.index[index_can_cyclebegin]
    index_can_cycleend = np.where(curr_diff == currdelta_vals[-1])[0][-1]
    index_can_cycleend = signal_df.index[index_can_cycleend]
else:
    index_can_cyclebegin = signal_df.index[1]
    index_can_cycleend = signal_df.index[-2]
#TODO

del curr_diff, currdelta_vals

print('Signal value extraction complete.\n')

#%% Load Chroma Log File
if(TSTR_PR):
    import excelreader
    
    print("Calling tester log file reader ... ")

    # Data column names
    colname_datetime = "TEST TIME"
    colname_time = "Real Time(ms)"                  # Time elapsed in ms
    colname_stepmode = "Step Mode"                  # Step mode
    colname_terminalvoltage = "Voltage(V)"          # Terminal voltage
    colname_current = "Current(A)"                  # Cell current
    colname_totalcapacity = "Total Capacity(Ah)"    # Cumulative capacity
    colname_energy = "Total KWh(KWh)"               # Cumulative energy

    collist = [colname_datetime, colname_time, colname_stepmode, \
                colname_terminalvoltage, colname_current, \
                colname_totalcapacity, colname_energy]

    # Function to parse tester log files and put data into a pandas dataframe
    tester_df = excelreader.read_excel(testerlog_filePath, collist, timestampIndex = True)

    # Eliminate date information from tester log timestamp
    date_tester = tester_df.index[0] - (tester_df.index[0] - tester_df.index[0].floor('1D'))
    tester_df.index = tester_df.index - (tester_df.index[0] - pd.to_datetime(0)).floor('1D')

    # tester_df['time_sec_tester'] = (tester_df.index - tester_df.index[0].floor('1D')).total_seconds()

    print("Extracting start/stop points from tester data ... ")
    # Determine cycle start and cycle end points
    # Determine first start point only and last end point
    index_tester_cyclebegin = tester_df.index[0]
    start_detected = False
    for index in range(len(tester_df)-1):
        if tester_df[colname_stepmode][index] == 'REST' and \
            (   (tester_df[colname_stepmode][index + 1] == 'CC Discharge') \
             or (tester_df[colname_stepmode][index + 1] == 'CC-CV Discharge') \
             or (tester_df[colname_stepmode][index + 1]== 'CC Charge') \
             or (tester_df[colname_stepmode][index + 1] == 'CC-CV Charge') \
             or (tester_df[colname_stepmode][index + 1] == 'Waveform(A)')):
            if (start_detected == False):       # Record the begining of the first pulse only
                index_tester_cyclebegin = tester_df.index[index + 1]    # Beginning of cycle
                start_detected = True

        elif (abs(tester_df[colname_current][index]) > 0.5 and tester_df[colname_stepmode][index + 1] == 'REST'):
                index_tester_cycleend = tester_df.index[index]    # End of cycle
    
    if (abs(tester_df[colname_current][len(tester_df)-1]) > 0.5):
        # Last entry in tester log has non-zero current
        index_tester_cycleend = tester_df.index[len(tester_df)-1]    # End of cycle not in log

    del start_detected

else:
    print("Pack tester not present.")
    date_tester = signal_df.index[0].date()
    colname_current = "ESS_BM1_iMod_Act_A"
    colname_terminalvoltage = "ESS_BM1_Voltage_Act_V"
    colname_totalcapacity = "cum_Ah_can" # Cumulative capacity
    colname_energy = "cum_kWh_can"
    index_tester_cyclebegin = index_can_cyclebegin
    index_tester_cycleend = index_can_cycleend

#%% Time synchronize and merge CAN and pack tester logs
#tester_df[colname_energy] = tester_df[colname_energy].astype(float)

if(TSTR_PR):
    print('Merging CAN and pack tester logs ...')

    # Additional logic in case the time stamps are skewed - adjust tester log to match CAN timestamps
    clock_skew = index_can_cyclebegin - index_tester_cyclebegin
    clock_skew2 = index_can_cycleend - index_tester_cycleend

    tester_df.index = tester_df.index + clock_skew
    index_tester_cyclebegin += clock_skew
    index_tester_cycleend += clock_skew

    signal_df = signal_df.join(tester_df, how = 'outer')
    del tester_df

    print('CAN and pack tester log merge complete.')
  
# Drop rows for which BMS state or VCU command is missing
print('Deleting rows with missing state signals ...')
signal_df.dropna(axis = 0, subset = ['ETS_VCU_VCUBMSReqMode_Req_enum', \
                                     'ESS_BMS_State_St_enum', \
                                     'ESS_BM1_State_St_enum'], inplace = True)

# Index one sample before beginning of cycle
index_beforecycle = index_tester_cyclebegin - pd.Timedelta('1S')

# Determine end of rest period after cycle for determining "at rest" quantities
if max(signal_df.index) > (index_tester_cycleend +  pd.Timedelta('60 min')):
    index_tester_rested = min(signal_df[signal_df.index > (index_tester_cycleend +  pd.Timedelta('60 min'))].index)
else:
    index_tester_rested = max(signal_df.index) - pd.Timedelta('1S')

signal_df['time_sec_can'] = (signal_df.index - signal_df.index[0]).total_seconds()

# Adjust offset in the CAN log so that cycle begins at t = 0
if TSTR_PR:
    signal_df['time_sec_can'] -= signal_df.loc[index_tester_cyclebegin, 'time_sec_can']

# Use for time axis in all plots
time_hrs = [i/3600 for i in signal_df['time_sec_can']]

# Compute accumulated capacity using can current
print('\nComputing accumulated capacity using CAN current ...')
cum_Ah_can = scipy.integrate.cumtrapz(signal_df['ESS_BMS_iPack_Act_A'], x = signal_df['time_sec_can'])/3600
cum_Ah_can = np.append(cum_Ah_can, cum_Ah_can[-1])
signal_df['cum_Ah_can'] = cum_Ah_can
del cum_Ah_can

# Compute accumulated energy using can voltage and current
print('Computing accumulated energy using CAN voltage and current ...')
dkWh = [a*b/1000 for a,b in zip(signal_df['ESS_BMS_Voltage_Act_V'], signal_df['ESS_BMS_iPack_Act_A'])]
cum_kWh_can = scipy.integrate.cumtrapz(dkWh, x = signal_df['time_sec_can'])/3600
cum_kWh_can = np.append(cum_kWh_can, cum_kWh_can[-1])
signal_df['cum_kWh_can'] = cum_kWh_can
del dkWh, cum_kWh_can

# Dtermine if the pack is in charge or specifically in CC discharge
PACK_IN_CCDISCH = 1
PACK_IN_CHARGE = 0
      
if ~TSTR_PR:
    PACK_IN_CCDISCH = 0
elif testdesc in ['WMTCD+1_DCH', 'WOTD_DCH_FanOff', 'WOTD+1_DCH', \
                'Drivecycle_DCH', 'DrvCyc-DCH', 'WOTd+1_DCH_Fan100%', \
                'WOTd+1_DCH_3.567 kW_CP', 'WMTC_DCH','WOTd+1_DCH_FanOff']:
    PACK_IN_CCDISCH = 0
    
if (strip(signal_df.loc[index_can_cyclebegin, 'ESS_BM1_State_St_enum']) == 'CHARGE'):
    PACK_IN_CHARGE = 1
    PACK_IN_CCDISCH = 0

# Check whether the SoC trim function is implemented and recreate true SoC if so
BATT_soc_trim_max_label='BATT_soc_trim_max'
BATT_soc_trim_min_label='BATT_soc_trim_min'
if num_mods !=0:
     BATT_soc_trim_max_label='BATT_soc_trim_max_0'
     BATT_soc_trim_min_label='BATT_soc_trim_min_0'
        
# Remove SoC trim from estimated SoC signal in SoX message
print('Computing true SoC from trimmed SoC ...')
if SOC_TRIM:    # Individual module SoC is trimmed
    if not isNaN(signal_df.loc[index_tester_cyclebegin, BATT_soc_trim_max_label]):
        signal_df['PackSoC_Trimmed'] = signal_df['ESS_BM1_Soc_Est_perc']
        signal_df['ESS_BM1_Soc_Est_perc'] = 0.01*signal_df['PackSoC_Trimmed']*(signal_df[BATT_soc_trim_max_label] - signal_df[ BATT_soc_trim_min_label]) + signal_df[ BATT_soc_trim_min_label]

if SOC_TRIM_PACK:   # Aggregated pack SoC is trimmed
    if not isNaN(signal_df.loc[index_tester_cyclebegin, BATT_soc_trim_max_label]):
        signal_df['PackSoC_Trimmed'] = signal_df['ESS_BMS_Soc_Est_perc']

#%% Save parameters of interest as time-series for comparison among tests
print('Saving pack parameters as time-series ...')
save_filename = fig_dir + '\\' + fname_prefix + '_rsdata.xlsx'

items=[
        'time_sec_can', 
        'ETS_VCU_VCUBMSReqMode_Req_enum', 'ESS_BM*_State_St_enum', 
        'ESS_BM*_Voltage_Act_V', 'ESS_BM*_vLoad_Act_V', 'ESS_BM*_iMod_Act_A',
        'ESS_BM*_ChgLimitCont_Max_A', 'ESS_BM*_ChgLimit10sec_Max_A', 'BATT_iChgInst_@', 
        'ESS_BM*_DchgLimitCont_Max_A', 'ESS_BM*_DchgLimit10sec_Max_A', 'BATT_iDchInst_@',
        'ESS_BM*_Soc_Est_perc', 'ESS_BM*_nBal_Act_count',
        'ESS_BM*_MinCell_Act_V', 'ESS_BM*_MaxCell_Act_V',
        'ESS_BM*_TempMin_Act_degC', 'ESS_BM*_TempMax_Act_degC',
        'BATT_tFET_@', 'BATT_tAmbient_@']   
   
items_seg = update_list_names(items,num_mods)
        
signal_df.to_excel(
    excel_writer = save_filename, 
    sheet_name='Sheet1', 
    na_rep='nan',
    inf_rep='inf',
    float_format=None, 
    columns=items_seg, 
    header=True, 
    index=True, index_label=None, 
    merge_cells=True
    )

#%% Need visual indication of cycle begin and end time for assurance
print("Plotting pack voltage and current ...")
import plot_packvoltcurr

plot_packvoltcurr.plot_pack_volt_current(
    time_secs = signal_df['time_sec_can'],
    can_packvoltage = pad(signal_df['ESS_BMS_Voltage_Act_V']),
    can_loadvoltage = pad(signal_df['ESS_BMS_vLoad_Act_V']),
    can_packcurrent = pad(signal_df['ESS_BMS_iPack_Act_A']),
    
    can_modvoltage1 = pad(signal_df['ESS_BM1_Voltage_Act_V']),
    can_loadvoltage1 = pad(signal_df['ESS_BM1_vLoad_Act_V']),
    can_modcurrent1 = signal_df['ESS_BM1_iMod_Act_A'],
    
    can_modvoltage2 = pad(signal_df['ESS_BM2_Voltage_Act_V']) if MOD >= 2 else None,
    can_loadvoltage2 = pad(signal_df['ESS_BM2_vLoad_Act_V']) if MOD >= 2 else None,
    can_modcurrent2 = signal_df['ESS_BM2_iMod_Act_A'] if MOD >= 2 else None,
    
    can_modvoltage3 = pad(signal_df['ESS_BM3_Voltage_Act_V']) if MOD >= 3 else None,
    can_loadvoltage3 = pad(signal_df['ESS_BM3_vLoad_Act_V']) if MOD >= 3 else None,
    can_modcurrent3 = signal_df['ESS_BM3_iMod_Act_A'] if MOD >= 3 else None,
    
    can_modvoltage4 = pad(signal_df['ESS_BM4_Voltage_Act_V']) if MOD >= 4 else None,
    can_loadvoltage4 = pad(signal_df['ESS_BM4_vLoad_Act_V']) if MOD >= 4 else None,
    can_modcurrent4 = signal_df['ESS_BM4_iMod_Act_A'] if MOD >= 4 else None,
    
    tester_voltage = signal_df[colname_terminalvoltage] if TSTR_PR else None, 
    tester_current = signal_df[colname_current] if TSTR_PR else None,
    index_cyclebegin = index_can_cyclebegin,
    index_cycleend = index_tester_cycleend,
    index_rv_postcycle = index_tester_rested,
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )

#%% Plot of brick voltages
print("Plotting brick voltages ...")
import plot_brickvolt

event_df = cellcalib.event_df

#TODO - Plot brick voltages for all modules
bricklist = ['BATT_vBrick' + str(brick).zfill(2)+"_@" for brick in range(1, 14+1)]
bricklist = update_list_names(bricklist, num_mods)

plot_brickvolt.plot_brick_voltage(
    time_secs = signal_df['time_sec_can'],
    brickvoltages = signal_df[bricklist],
    balance_count = signal_df.loc[:, 'ESS_BM1_nBal_Act_count'],
    sp_war_overvolt = event_df.loc[event_df['Event Name'] == 'Brick Overvoltage Warning']['Set Point Value'].iloc[0],
    cp_war_overvolt = event_df.loc[event_df['Event Name'] == 'Brick Overvoltage Warning']['Clearpoint'].iloc[0],
    sp_mod_overvolt = event_df.loc[event_df['Event Name'] == 'Brick Overvoltage Moderate']['Set Point Value'].iloc[0],
    cp_mod_overvolt = event_df.loc[event_df['Event Name'] == 'Brick Overvoltage Moderate']['Clearpoint'].iloc[0],
    sp_sev_overvolt = event_df.loc[event_df['Event Name'] == 'Brick Overvoltage Severe']['Set Point Value'].iloc[0],
    cp_sev_overvolt = event_df.loc[event_df['Event Name'] == 'Brick Overvoltage Severe']['Clearpoint'].iloc[0],
    sp_war_undervolt = event_df.loc[event_df['Event Name'] == 'Brick Undervoltage Warning' ]['Set Point Value'].iloc[0],
    cp_war_undervolt = event_df.loc[event_df['Event Name'] == 'Brick Undervoltage Warning']['Clearpoint'].iloc[0],
    sp_mod_undervolt = event_df.loc[event_df['Event Name'] == 'Brick Undervoltage Moderate']['Set Point Value'].iloc[0],
    cp_mod_undervolt = event_df.loc[event_df['Event Name'] == 'Brick Undervoltage Moderate']['Clearpoint'].iloc[0],
    sp_sev_undervolt = event_df.loc[event_df['Event Name'] == 'Brick Undervoltage Severe']['Set Point Value'].iloc[0],
    cp_sev_undervolt = event_df.loc[event_df['Event Name'] == 'Brick Undervoltage Severe']['Clearpoint'].iloc[0],
    sp_voltimbalance = event_df.loc[event_df['Event Name'] == 'Battery Brick Voltage Imbalance']['Set Point Value'].iloc[0],
    cp_voltimbalance = event_df.loc[event_df['Event Name'] == 'Battery Brick Voltage Imbalance']['Clearpoint'].iloc[0],
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )

del bricklist

#%% Plot VCU requested state, BMS state and error 
print("Plotting bms states ...")
import plot_bmsst

plot_bmsst.plot_bms_state(
    time_secs = signal_df['time_sec_can'], 
    vcu_streq = signal_df['ETS_VCU_VCUBMSReqMode_Req_enum'], 
    bms_st = signal_df['ESS_BMS_State_St_enum'],
    bm1_st = signal_df['ESS_BM1_State_St_enum'],
    bm2_st = signal_df['ESS_BM2_State_St_enum'] if MOD >= 2 else None,
    bm3_st = signal_df['ESS_BM3_State_St_enum'] if MOD >= 3 else None,
    bm4_st = signal_df['ESS_BM4_State_St_enum'] if MOD >= 4 else None,
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )
  
#%% If in charge, monitor charge state
#TODO - Get rid of excess grid lines
print("Plotting charge state ...")
import plot_chgst

bricklist = ['BATT_vBrick' + str(brick).zfill(2)+"_@" for brick in range(1, 14+1)]
bricklist = update_list_names(bricklist, num_mods)    
#TODO - Update for multipack configuration
plot_chgst.plot_charge_state(
    time_secs = signal_df['time_sec_can'], 
    bms_chgen = signal_df['ESS_BMS_ChgEnable_St_enum'],
    bm1_chgen = signal_df['ESS_BM1_ChgEnable_St_enum'],
    bms_chmode = signal_df['ESS_BMS_ChgMode_St_enum'],
    bm1_chmode = signal_df['ESS_BM1_ChgMode_St_enum'], 
    brickvoltages = signal_df[bricklist], 
    can_packcurrent = signal_df['ESS_BM1_iMod_Act_A'],
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix)

#%% Plot of pack temperature sensor readings vs. time
print("Plotting pack tempearture readings ...")
import plot_packtemp

event_df = cellcalib.event_df
tempsensorlist = ['BATT_tModule' + str(sensor).zfill(1)+"_@" for sensor in range(1, 6+1)]
tempsensorlist = update_list_names(tempsensorlist, num_mods)     
 
plot_packtemp.plot_packtemperatures(   
    time_secs = signal_df['time_sec_can'],
    tempsensorvals = signal_df[tempsensorlist],
    can_packcurrent = signal_df[update_name('ESS_BM*_iMod_Act_A', num_mods)], 
    can_packsoc = signal_df[update_name('ESS_BM*_Soc_Est_perc', num_mods)],
    sp_war_overtemp = None,
    cp_war_overtemp = None,
    sp_mod_overtemp = None,
    cp_mod_overtemp = None,
    sp_sev_overtemp = None,
    cp_sev_overtemp = None,
    sp_war_undertemp = None,
    cp_war_undertemp = None,
    sp_mod_undertemp = None,
    cp_mod_undertemp = None,
    sp_sev_undertemp = None,
    cp_sev_undertemp = None,
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )

del tempsensorlist

#%% Estimated brick temperatures vs. time
if (HW_VER >= 2.1):
    print("Plotting estimated brick temperatures ...")
    tempsensorlist = ['BATT_tModule' + str(sensor).zfill(1)+"_@" for sensor in range(1, 6+1)]
    bricklist = ['BATT_tBrick' + str(brick).zfill(2)+"_@" for brick in range(1, 14+1)]
    tempsensorlist = update_list_names(tempsensorlist, num_mods)    
    bricklist = update_list_names(bricklist, num_mods)       
    
    plot_packtemp.plot_estbricktemp(
            time_secs = signal_df['time_sec_can'],
            tempsensorvals = signal_df[tempsensorlist],
            estbricktemps = signal_df[bricklist], 
            savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )

#%% Predicted ROCT vs. "true" ROCT
if (HW_VER >= 2.1) :
    roctfig, roctfig_roctax = plt.subplots()
    roctfig_roctax.plot(time_hrs, pad(signal_df['ESS_BM1_roctPerMin_Act_degC']), label = 'Predicted ROCT')

    roctfig_roctax.set_xlabel('Time (hours)')
    roctfig_roctax.set_ylabel('Rate of change of temperature (degC/min)')

#%%
# #%% Temperature vs. SoC
# print("Plotting temperature at each SoC ...")
# with mpl.rc_context(fname='RA_BMS.rc'):
#     soctempfig, soctempfig_tempax = plt.subplots(num = 'Temperatures_SoC')
#     for tsensor in range(1, 6+1):
#         soctempfig_tempax.plot(
#             pad(signal_df.loc[:, 'ESS_BM1_Soc_Est_perc']), 
#             pad(signal_df[update_name('BATT_tModule' + str(tsensor).zfill(1)+"_@",num_mods)]), 
#             label = update_name("Sensor " + str(tsensor).zfill(1) +"_@",num_mods))

#     soctempfig_tempax.set_xlabel("SoC (%)")
#     soctempfig_tempax.set_ylabel(r"Temperature ($\degree$C)")

# plt.xlim(0, 100)
# soctempfig_tempax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)

# plt.show()

#%% Plot of other temperature sensor readings
#TODO Limits for ambient temperature
print("Plotting PCB temperatures ...")
import plot_bmstemp

plot_bmstemp.plot_othertemperatures(
    time_secs = signal_df['time_sec_can'], \
    fettemp = pad(signal_df[update_name('BATT_tFET_@',num_mods)]), \
    ambtemp = pad(signal_df[update_name('BATT_tAmbient_@',num_mods)]), \
    shunttemp = pad(signal_df[update_name('BATT_tShunt_@',num_mods)]), \
    prechargetemp = pad(signal_df[update_name('BATT_tPrecharge_@',num_mods)]) if (HW_VER >= 2.1) else None, \
    sp_fetovertemp = cellcalib.event_df.loc[event_df['Event Name'] == 'FET Overheated']['Set Point Value'].iloc[0], \
    cp_fetovertemp = cellcalib.event_df.loc[event_df['Event Name'] == 'FET Overheated']['Clearpoint'].iloc[0], \
    can_packcurrent = signal_df[update_name('ESS_BM*_iMod_Act_A', num_mods)], \
    balance_count = signal_df[update_name('ESS_BM*_nBal_Act_count', num_mods)] if PACK_IN_CHARGE else None, \
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )

#%% Plot actual pack current vs. charge and discharge current limits
print("Plotting pack current limits ...")

import plot_limits

bricklist = ['BATT_socBrick' + str(brick).zfill(2)+"_@" for brick in range(1, 14+1)]
tempsensorlist = ['BATT_tModule' + str(sensor).zfill(1)+"_@" for sensor in range(1, 6+1)]
tempsensorlist = update_list_names(tempsensorlist, num_mods)    
bricklist = update_list_names(bricklist, num_mods)           

plot_limits.plot_currentlim(chginst_from_soc_f,\
    chg10s_from_soc_f,chgcont_from_soc_f,dchinst_from_soc_f,dch10s_from_soc_f,\
    dchcont_from_soc_f,\
    time_secs = signal_df['time_sec_can'], \
    bricksocs = signal_df[bricklist], \
    tempsensorvals = signal_df[tempsensorlist], \
    idch_inst = pad(signal_df[update_name('BATT_iDchInst_@', num_mods)]), \
    idch_10s = pad(signal_df[update_name('ESS_BM*_DchgLimit10sec_Max_A', num_mods)]), \
    idch_cont = pad(signal_df[update_name('ESS_BM*_DchgLimitCont_Max_A', num_mods)]), \
    ichg_inst = pad(signal_df[update_name('BATT_iChgInst_@', num_mods)]), \
    ichg_10s = pad(signal_df[update_name('ESS_BM*_ChgLimit10sec_Max_A', num_mods)]), \
    ichg_cont = pad(signal_df[update_name('ESS_BM*_ChgLimitCont_Max_A', num_mods)]), \
    can_packcurrent = pad(signal_df[update_name('ESS_BM*_iMod_Act_A', num_mods)]), \
    can_packsoc = pad(signal_df[update_name('ESS_BM*_Soc_Est_perc', num_mods)]), \
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix,)

plot_limits.plot_voltlim(
    time_secs = signal_df['time_sec_can'], \
    can_mod1voltage = pad(signal_df['ESS_BM1_Voltage_Act_V']), \
    can_vdch_min_pack = signal_df[DCH_vlim_label_pack], \
    can_vdch_min_mod1 = signal_df[update_name(DCH_vlim_label, mod_id = 1)], \
    can_vchg_max_pack = signal_df['ESS_BMS_ChgLimit_Max_V'], \
    can_vchg_max_mod1 = signal_df['ESS_BM1_ChgLimit_Max_V'], \
    can_vcupowerreq = signal_df[vcu_exp_power], \
    can_poweravl = signal_df[update_name('BATT_dch_pwr_available_W_@',num_mods)] if DCH_POWAVL else None, \
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix,)
    
plot_limits.plot_powerlim(
    time_secs = signal_df['time_sec_can'], \
    idch_inst_mod1 = signal_df[update_name('BATT_iDchInst_@', num_mods)], \
    can_vdch_min_mod1 = signal_df[update_name(DCH_vlim_label, mod_id = 1)], \
    can_vcupowerreq  = signal_df[vcu_exp_power], \
    can_poweravl_pack  = signal_df[update_name('BATT_dch_pwr_available_W_@',num_mods)] if DCH_POWAVL else None, \
    can_poweravl_mod1 = signal_df[update_name('BATT_dch_pwr_available_W_@',num_mods)], \
    savefig = False, fig_dir = '', fname_prefix = '' )
    
#%% Plot of CAN current vs. tester current
print("Plotting pack current comparison ...")
import plot_currcomp
if(TSTR_PR):
    plot_currcomp.compare_current(
        time_secs = signal_df['time_sec_can'], \
        can_packcurrent = pad(signal_df['ESS_BMS_iPack_Act_A']), \
        can_modcurrent = pad(signal_df['ESS_BM1_iMod_Act_A']), \
        tester_packcurrent = signal_df['Current(A)'], \
        tshunt = pad(signal_df[update_name('BATT_tShunt_@',num_mods)]), \
        savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )
              
# Check capacity from Ah discharged and SoC at begining and end of 
plot_currcomp.plot_ahcomp(
    time_secs = signal_df['time_sec_can'], \
    cancurr_ah = signal_df['cum_Ah_can'], \
    can_capavl = signal_df['ESS_BM1_CapAvailable_Est_Ah'], \
    index_can_cyclebegin = index_can_cyclebegin, \
    tester_ah = signal_df[colname_totalcapacity] if TSTR_PR else None, \
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )

#%% Check estimated SoC against that calculated from CAN reported pack current and battery tester current
# Compute SoC from OCV before and after cycle
# TODO - Fix hysteresis assumptions
print("Computing brick metrics ...")

soccheck_df = pd.DataFrame(columns = ['AhCellCAN_init', 'AhCellCAN_end', \
                                      'voltCell_init', 'socCellOCV_init', 'socCellCAN_init', \
                                      'voltCell_rested', 'socCellOCV_cycleEnd', 'socCellCAN_cycleEnd', 'socCellCAN_corrected', \
                                      'AhCellEst_CANCurr', 'AhCellEst_tester', \
                                      'WhCellCycle', \
                                      'tempCellEst_min', 'tempCellEst_init', 'tempCellEst_max', 'tempCellEst_cycleEnd', 'tempCellEst_rested', \
                                     ], index = range(1, 14+1))

tempsensorlist = [update_name('BATT_tModule' + str(sensor).zfill(1)+"_@",num_mods) for sensor in range(1, 6+1)]
temperature_min_val = signal_df.loc[index_tester_cyclebegin: index_tester_cycleend, tempsensorlist].min(axis=1).min(axis=0)
temperature_max_val = signal_df.loc[index_tester_cyclebegin: index_tester_cycleend, tempsensorlist].max(axis=1).max(axis=0)

for brick in range(1, 14+1):
    # Temperature variation
    if(HW_VER >= 2.1):
        soccheck_df.loc[brick, 'tempCellEst_min'] =  signal_df.loc[index_tester_cyclebegin: index_tester_cycleend, update_name('BATT_tBrick' + str(brick).zfill(2)+"_@",num_mods)].min(axis=0)
        soccheck_df.loc[brick, 'tempCellEst_max'] =  signal_df.loc[index_tester_cyclebegin: index_tester_cycleend, update_name('BATT_tBrick' + str(brick).zfill(2)+"_@",num_mods)].max(axis=0)
        soccheck_df.loc[brick, 'tempCellEst_init'] =  strip(signal_df.loc[index_beforecycle, update_name('BATT_tBrick' + str(brick).zfill(2)+"_@",num_mods)])
        soccheck_df.loc[brick, 'tempCellEst_cycleEnd'] =  strip(signal_df.loc[index_tester_cycleend, update_name('BATT_tBrick' + str(brick).zfill(2)+"_@",num_mods)])
        soccheck_df.loc[brick, 'tempCellEst_rested'] = strip(signal_df.loc[index_tester_rested, update_name('BATT_tBrick' + str(brick).zfill(2)+"_@",num_mods)])
        soccheck_df.loc[brick, 'tempCellEst_avg'] = signal_df.loc[index_tester_cyclebegin: index_tester_cycleend, update_name('BATT_tBrick' + str(brick).zfill(2)+"_@",num_mods)].mean(axis=0)
    else:
        soccheck_df.loc[brick, 'tempCellEst_min'] =  temperature_min_val
        soccheck_df.loc[brick, 'tempCellEst_max'] =  temperature_max_val
        # OCV calculation using the max temperature is inferior to using average temperature
        soccheck_df.loc[brick, 'tempCellEst_init'] =  strip(signal_df.loc[index_beforecycle, tempsensorlist]).max(axis = 1)
        soccheck_df.loc[brick, 'tempCellEst_cycleEnd'] =  strip(signal_df.loc[index_tester_cycleend, tempsensorlist]).max(axis = 1)
        soccheck_df.loc[brick, 'tempCellEst_rested'] = strip(signal_df.loc[index_tester_rested, tempsensorlist]).max(axis = 1)
        soccheck_df.loc[brick, 'tempCellEst_avg'] = signal_df.loc[index_tester_rested, tempsensorlist].max(axis = 1).mean(axis=0)

    soccheck_df.loc[brick, 'AhCellCAN_init'] = (1/18)*strip(signal_df.loc[index_beforecycle, update_name('BATT_capBrick' + str(brick).zfill(2)+"_@",num_mods)])
    soccheck_df.loc[brick, 'AhCellCAN_end'] = (1/18)*signal_df[update_name('BATT_capBrick' + str(brick).zfill(2)+"_@",num_mods)][len(signal_df)-2]

    soccheck_df.loc[brick, 'voltCell_init'] = strip(signal_df.loc[index_beforecycle, update_name('BATT_vBrick' + str(brick).zfill(2)+"_@",num_mods)])
    soccheck_df.loc[brick, 'socCellOCV_init'] = round(100*soc_from_restvolt(soccheck_df.loc[brick, 'tempCellEst_init'], soccheck_df.loc[brick, 'voltCell_init'], 1), 3)
    soccheck_df.loc[brick, 'socCellCAN_init'] = strip(signal_df.loc[index_beforecycle, update_name('BATT_socBrick' + str(brick).zfill(2)+"_@",num_mods)])

    soccheck_df.loc[brick, 'voltCell_cycleEnd'] = strip(signal_df.loc[index_tester_cycleend, update_name('BATT_vBrick' + str(brick).zfill(2)+"_@",num_mods)])
    # SoC from terminal voltage after rest following end of cycle
    soccheck_df.loc[brick, 'voltCell_rested'] = strip(signal_df.loc[index_tester_rested, update_name('BATT_vBrick' + str(brick).zfill(2)+"_@",num_mods)])
    soccheck_df.loc[brick, 'socCellOCV_cycleEnd'] = round(100*soc_from_restvolt(soccheck_df.loc[brick, 'tempCellEst_rested'], soccheck_df.loc[brick, 'voltCell_rested'], 1), 3)
    soccheck_df.loc[brick, 'socCellCAN_cycleEnd'] = strip(signal_df.loc[index_tester_cycleend, update_name('BATT_socBrick' + str(brick).zfill(2)+"_@",num_mods)])
    soccheck_df.loc[brick, 'socCellCAN_corrected'] = signal_df[update_name('BATT_socBrick' + str(brick).zfill(2)+"_@",num_mods)][len(signal_df)-2]

    # SoH from Ah discharged between two rest voltages
    soccheck_df.loc[brick, 'AhCellEst_CANCurr'] = 100*(1/18)*(strip(signal_df.loc[index_beforecycle, 'cum_Ah_can']) - strip(signal_df.loc[index_tester_cycleend, 'cum_Ah_can']))/(soccheck_df.loc[brick, 'socCellCAN_init'] - soccheck_df.loc[brick, 'socCellCAN_corrected'])
    if TSTR_PR:
        soccheck_df.loc[brick, 'AhCellEst_tester'] = 100*(1/18)*(strip(signal_df.loc[index_beforecycle, colname_totalcapacity]) - strip(signal_df.loc[index_tester_cycleend, colname_totalcapacity]))\
                                                            /(soccheck_df.loc[brick, 'socCellOCV_init'] - soccheck_df.loc[brick, 'socCellOCV_cycleEnd'])
    else:
        soccheck_df.loc[brick, 'AhCellEst_tester'] = 'NA'

    # Energy added / removed
    temp_df = signal_df[['time_sec_can', update_name('BATT_balStatusBrick' + str(brick).zfill(2)+"_@",num_mods)]].copy()
    temp_df['denergy'] = [a*b for a,b in zip(signal_df[update_name('BATT_vBrick' + str(brick).zfill(2)+"_@",num_mods)], signal_df['ESS_BM1_iMod_Act_A'])]
    temp_df['dbalAh'] = [(1/113)*a*b for a,b in zip(signal_df[update_name('BATT_vBrick' + str(brick).zfill(2)+"_@",num_mods)], signal_df[update_name('BATT_balStatusBrick' + str(brick).zfill(2)+"_@",num_mods)])]
    temp_df['dbalWh'] = [(1/113)*a*a*b for a,b in zip(signal_df[update_name('BATT_vBrick' + str(brick).zfill(2)+"_@",num_mods)], signal_df[update_name('BATT_balStatusBrick' + str(brick).zfill(2)+"_@",num_mods)])]
    temp_df.dropna(axis = 0, subset = ['denergy', 'dbalAh', 'dbalWh', update_name('BATT_balStatusBrick' + str(brick).zfill(2)+"_@",num_mods)], inplace = True)
    soccheck_df.loc[brick, 'WhCellCycle'] = scipy.integrate.trapz(temp_df['denergy'], x = temp_df['time_sec_can'])/3600

    # Available Ah
    soccheck_df.loc[brick, 'InitialAhfromCANSoC'] = (1/100)*soccheck_df.loc[brick, 'socCellCAN_init']*18*soccheck_df.loc[brick, 'AhCellCAN_init']
    soccheck_df.loc[brick, 'InitialAhfromOCVSoC'] = (1/100)*soccheck_df.loc[brick, 'socCellOCV_init']*18*soccheck_df.loc[brick, 'AhCellCAN_init']
    soccheck_df.loc[brick, 'CycleEndAh'] = (1/100)*soccheck_df.loc[brick, 'socCellCAN_cycleEnd']*18*soccheck_df.loc[brick, 'AhCellCAN_init']
    soccheck_df.loc[brick, 'CorrectedAh'] = (1/100)*soccheck_df.loc[brick, 'socCellCAN_corrected']*18*soccheck_df.loc[brick, 'AhCellCAN_end']

    # Balancing figures
    soccheck_df.loc[brick, 'balMinutesCell'] = scipy.integrate.trapz(temp_df[update_name('BATT_balStatusBrick' + str(brick).zfill(2)+"_@",num_mods)], x = temp_df['time_sec_can'])/60
    soccheck_df.loc[brick, 'balAhCell'] = scipy.integrate.trapz(temp_df['dbalAh'], x = temp_df['time_sec_can'])/3600
    soccheck_df.loc[brick, 'balWhCell'] = scipy.integrate.trapz(temp_df['dbalWh'], x = temp_df['time_sec_can'])/3600

del temp_df

# Monitor imbalance propagation
InitialMinBrickAh = soccheck_df.loc[:, 'InitialAhfromCANSoC'].min(axis = 0)
InitialMinBrickAh1 = soccheck_df.loc[:, 'InitialAhfromOCVSoC'].min(axis = 0)
FinalMinBrickAh = soccheck_df.loc[:, 'CycleEndAh'].min(axis = 0)
EndMinBrickAh = soccheck_df.loc[:, 'CorrectedAh'].min(axis = 0)

for brick in range(1, 14+1):
    # Coulomb difference from cell with least Ah
    soccheck_df.loc[brick, 'balCoulDiffCellCANSoc_init'] = (soccheck_df.loc[brick, 'InitialAhfromCANSoC'] - InitialMinBrickAh)*3600
    soccheck_df.loc[brick, 'balCoulDiffCellOCVSoc_init'] = (soccheck_df.loc[brick, 'InitialAhfromOCVSoC'] - InitialMinBrickAh1)*3600
    # TODO Imbalance perceived by the BMS at cycle end as per its own metrics - !! balancing continues in rest period
    soccheck_df.loc[brick, 'balCoulDiffCellCANSoc_cycleEnd'] = (soccheck_df.loc[brick, 'CycleEndAh'] - FinalMinBrickAh)*3600
    # Actual imbalance - to be compared against perceived imbalance
    soccheck_df.loc[brick, 'balCoulDiffCellCANSoc_corrected'] = (soccheck_df.loc[brick, 'CorrectedAh'] - EndMinBrickAh)*3600

# soccheck_df.to_excel('key_metrics.xlsx', sheet_name = 'Sheet1', startrow = 2, startcol = 2, header = True)

#%% Charge / Discharge Times
print("Computing pack metrics ...")

df_hist = pd.DataFrame()
df_psoc = pd.DataFrame()
df_ptime = pd.DataFrame()
df_pbal = pd.DataFrame()
df_psohc = pd.DataFrame()
df_psoe = pd.DataFrame()
df_ptemp = pd.DataFrame()

df_csoc = pd.DataFrame()
df_csohc = pd.DataFrame()
df_cbal = pd.DataFrame()
df_ctemp = pd.DataFrame()

#packmetrics_df2 = pd.DataFrame()

# Pack history data
# --------------------------------------------------------------------------------------------------------------------------------
# "Test #", "Battery Serial Number", "Test Description", "Test Temperature"
m_id = 'ESS_BM1'
i_id = ''
try:
    df_hist.loc[1, 'test#'] = int(fieldValues[0])
except:
    df_hist.loc[1, 'test#'] = fieldValues[0]
    
df_hist.loc[1, 'testDesc'] = fieldValues[2]
df_hist.loc[1, 'testTemp'] = fieldValues[3]
df_hist.loc[1, 'packSN'] = fieldValues[1]

# TODO - Extract HW, App and Cal versions for a single sample
df_hist.loc[1, 'bmsHWVer'] = signal_df.loc[index_tester_cyclebegin, update_name('BATT_hardwareVersion_@', num_mods)]

if signal_df.loc[index_tester_cyclebegin, update_name('BATT_appMajor_@', num_mods)] != signal_df.loc[index_tester_cyclebegin, update_name('BATT_appMajor_@', num_mods)]:  # is nan
    df_hist.loc[1, 'bmsAppVer'] = str(float('nan'))
else:   # not nan
    df_hist.loc[1, 'bmsAppVer'] = str(int(signal_df.loc[index_tester_cyclebegin, update_name('BATT_appMajor_@', num_mods)])) + '_' \
                                + str(int(signal_df.loc[index_tester_cyclebegin, update_name('BATT_appMinor_@', num_mods)])) + '_' \
                                + str(int(signal_df.loc[index_tester_cyclebegin, update_name('BATT_appRevision_@', num_mods)]))

if signal_df.loc[index_tester_cyclebegin, update_name('BATT_calMajor_@', num_mods)] != signal_df.loc[index_tester_cyclebegin, update_name('BATT_calMajor_@', num_mods)]:
    df_hist.loc[1, 'bmsAppVer'] = str(float('nan'))
else:
    df_hist.loc[1, 'bmsCalVer'] = str(int(signal_df.loc[index_tester_cyclebegin, update_name('BATT_calMajor_@', num_mods)])) + '_' \
                                + str(int(signal_df.loc[index_tester_cyclebegin, update_name('BATT_calMinor_@', num_mods)])) + '_' \
                                + str(int(signal_df.loc[index_tester_cyclebegin, update_name('BATT_calRevision_@', num_mods)]))

df_hist.loc[1, 'accChgCyclesCAN'] = signal_df.loc[index_beforecycle, m_id+'_ChgCycle_Act_count']
df_hist.loc[1, 'Cycle#'] = ' '

if PACK_IN_CHARGE:
    df_hist.loc[1, 'dirCurr'] = 'CHG'
else:
    df_hist.loc[1, 'dirCurr'] = 'DCH'

df_hist.loc[1, 'dateTime_start'] = str(date_tester + (index_tester_cyclebegin - pd.to_datetime(0)))
df_hist.loc[1, 'dateTime_end'] = str(date_tester + (index_tester_cycleend - pd.to_datetime(0)))


df_hist.loc[1, 'dateTimeRTC_start'] = ' '
df_hist.loc[1, 'dateTimeRTC_end'] = ' '

df_hist.loc[1, 'sleepTimeMinutes'] = signal_df.loc[index_beforecycle, update_name('BATT_timeSleepCycle_@', num_mods)]/60

# Pack SoC data
# --------------------------------------------------------------------------------------------------------------------------------
df_psoc.loc[1, 'voltPackCAN_init'] = signal_df.loc[index_beforecycle, m_id+'_Voltage_Act_V']
df_psoc.loc[1, 'voltPackCAN_cycleEnd'] = signal_df.loc[index_tester_cycleend, m_id+'_Voltage_Act_V']
df_psoc.loc[1, 'voltPackCAN_rested'] = signal_df.loc[index_tester_rested, m_id+'_Voltage_Act_V']
df_psoc.loc[1, 'restMinutes_cycleEnd'] = (index_tester_rested - index_tester_cycleend).total_seconds()/60

df_psoc.loc[1, 'socPackCAN_init'] = signal_df.loc[index_beforecycle, m_id+'_Soc_Est_perc']
df_psoc.loc[1, 'socPackCAN_cycleEnd'] = signal_df.loc[index_tester_cycleend, m_id+'_Soc_Est_perc']
df_psoc.loc[1, 'socPackCAN_corrected'] = signal_df.loc[index_tester_rested, m_id+'_Soc_Est_perc']

# TODO - Subtract interrupt durations 
df_ptime.loc[1, 'cycleMinutes'] = (index_tester_cycleend - index_tester_cyclebegin).total_seconds()/60

df_ptime.loc[1, 'chgMinutesEst_init'] = signal_df.loc[index_tester_cyclebegin, m_id+'_ChgRemainingTime_Est_min']

# Pack SoHC data
# --------------------------------------------------------------------------------------------------------------------------------
df_psohc.loc[1, 'accChgAhCAN'] = signal_df.loc[index_beforecycle, update_name('BATT_ahChgTotal_@', num_mods)]
df_psohc.loc[1, 'accDchAhCAN'] = signal_df.loc[index_beforecycle, update_name('BATT_ahDchTotal_@', num_mods)]

df_psohc.loc[1, 'sohcCANPack_init'] = signal_df.loc[index_beforecycle, m_id+'_Sohc_Est_perc']

df_psohc.loc[1, 'AhFullChgPack_init'] = signal_df.loc[index_beforecycle, m_id+'_CapFulCharge_Est_Ah']

df_psohc.loc[1, 'AhAvlPack_init'] = signal_df.loc[index_tester_cyclebegin, m_id+'_CapAvailable_Est_Ah']
df_psohc.loc[1, 'AhAvlPack_cycleEnd'] = signal_df.loc[index_tester_cycleend, m_id+'_CapAvailable_Est_Ah']
df_psohc.loc[1, 'AhCyclePack'] = abs(signal_df.loc[index_tester_cycleend, colname_totalcapacity] \
                                     - signal_df.loc[index_tester_cyclebegin, colname_totalcapacity])

if (~PACK_IN_CHARGE):
    df_psohc.loc[1, 'AhDchPack'] = abs(scipy.integrate.trapz(
        [a*b for a,b in zip((signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current] <= 0),
                             signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current])], 
        x = signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, 'time_sec_can'])/3600)
    
    df_psohc.loc[1, 'AhRegPack'] = abs(scipy.integrate.trapz(
        [a*b for a,b in zip((signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current] > 0),
                             signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current])], 
        x = signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, 'time_sec_can'])/3600)
else:
    df_psohc.loc[1, 'AhDchPack'] = 'NA'
    df_psohc.loc[1, 'AhRegPack'] = 'NA'

# Pack SoE data
# --------------------------------------------------------------------------------------------------------------------------------
df_psoe.loc[1, 'accChgkWhCAN'] = signal_df.loc[index_beforecycle, m_id+'_AccChgEnergy_Est_kWh']
df_psoe.loc[1, 'accDchkWhCAN'] = signal_df.loc[index_beforecycle, m_id+'_AccDchgEnergy_Est_kWh']

df_psoe.loc[1, 'kWhFullChgPack_init'] = signal_df.loc[index_tester_cyclebegin, m_id+'_EnergyFulCharge_Est_kWh']

df_psoe.loc[1, 'kWhAvlPack_init'] = signal_df.loc[index_tester_cyclebegin, m_id+'_EnergyAvailable_Est_kWh']
df_psoe.loc[1, 'kWhAvlPack_cycleEnd'] = signal_df.loc[index_tester_cycleend, m_id+'_EnergyAvailable_Est_kWh']
df_psoe.loc[1, 'kWhCyclePack'] = abs(signal_df.loc[index_tester_cycleend, colname_energy] \
                                     - signal_df.loc[index_tester_cyclebegin, colname_energy])

if (~PACK_IN_CHARGE):
    df_psoe.loc[1, 'kWhDchPack'] = (1/1000)*abs(scipy.integrate.trapz(
        [a*b*c for a,b,c in zip((signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current] <= 0),
                                 signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current],
                                 signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_terminalvoltage])], 
        x = signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, 'time_sec_can'])/3600)
    df_psoe.loc[1, 'kWhRegPack'] = (1/1000)*abs(scipy.integrate.trapz(
        [a*b*c for a,b,c in zip((signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current] > 0),
                                 signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current], \
                                 signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_terminalvoltage])], 
        x = signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, 'time_sec_can'])/3600)
else:
    df_psoe.loc[1, 'kWhDchPack'] = 'NA'
    df_psoe.loc[1, 'kWhRegPack'] = 'NA'

df_psoe.loc[1, 'soePackCAN_init'] = signal_df.loc[index_tester_cyclebegin, m_id+'_Soe_Est_perc']
df_psoe.loc[1, 'soePackCAN_cycleEnd'] = signal_df.loc[index_tester_cycleend, m_id+'_Soe_Est_perc']

if (PACK_IN_CHARGE):
    index_CCend = index_tester_cycleend
    for index in signal_df.index[1:len(signal_df)-1]:
        if ((signal_df.loc[index, m_id+'_ChgMode_St_enum'] == 'CC') and \
            (signal_df.loc[index + pd.Timedelta('1s'), m_id+'_ChgMode_St_enum'] == 'CV')):
            index_CCend = index

    # CV Start SoC
    df_psoc.loc[1, 'chgCVStSocPackCAN'] = signal_df.loc[index_CCend, m_id+'_Soc_Est_perc']
    
    df_ptime.loc[1, 'chgMinutesCC'] = (index_CCend - index_tester_cyclebegin).total_seconds()/60
    df_ptime.loc[1, 'chgMinutesCV'] = (index_tester_cycleend - index_CCend + pd.Timedelta('1s')).total_seconds()/60
    
    df_psohc.loc[1, 'chgAhCC'] = abs(signal_df.loc[index_CCend, colname_totalcapacity] \
                                     - signal_df.loc[index_tester_cyclebegin, colname_totalcapacity])
    df_psohc.loc[1, 'chgAhCV'] = abs(signal_df.loc[index_tester_cycleend, colname_totalcapacity] \
                                     - signal_df.loc[index_CCend + pd.Timedelta('1s'), colname_totalcapacity])
    
    df_psoe.loc[1, 'chgkWhCC'] = abs(signal_df.loc[index_CCend, colname_energy] \
                                     - signal_df.loc[index_tester_cyclebegin, colname_energy])
    df_psoe.loc[1, 'chgkWhCV'] = abs(signal_df.loc[index_tester_cycleend, colname_energy] \
                                     - signal_df.loc[index_CCend + pd.Timedelta('1s'), colname_energy])

else: # Battery not in charge mode
    df_psoc.loc[1, 'chgCVStSocPackCAN'] = 'NA'
    df_ptime.loc[1, 'chgMinutesCC'] = 'NA'
    df_ptime.loc[1, 'chgMinutesCV'] = 'NA'
    df_psohc.loc[1, 'chgAhCC'] = 'NA'
    df_psohc.loc[1, 'chgAhCV'] = 'NA'
    df_psoe.loc[1, 'chgkWhCC'] = 'NA'
    df_psoe.loc[1, 'chgkWhCV'] = 'NA'

bricklist = [update_name('BATT_vBrick' + str(brick).zfill(2)+"_@", num_mods) for brick in range(1,14+1)]
# TODO - This probably results in large apparent voltage deltas  
voltagedelta = signal_df[bricklist].max(axis=1) - signal_df[bricklist].min(axis=1)
voltagedelta_max_val = voltagedelta.max(axis = 0)

df_pbal.loc[1, 'balErr_max'] = signal_df[m_id+'_BalErr_Act_perc'].max()
df_pbal.loc[1, 'balVoltDelta_init'] = voltagedelta[index_beforecycle]
df_pbal.loc[1, 'balVoltDelta_max'] = voltagedelta_max_val
df_pbal.loc[1, 'balCount_max'] = signal_df[m_id+'_nBal_Act_count'].max()

# Pack temperature data
# --------------------------------------------------------------------------------------------------------------------------------
df_ptemp.loc[1, 'currPack_avg'] = signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current].mean(axis=0)
df_ptemp.loc[1, 'currPack_rms'] = np.sqrt(sum(n*n for n in signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current])\
                                          /len(signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current]))
df_ptemp.loc[1, 'curPack_max'] = signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current].max(axis=0)
df_ptemp.loc[1, 'curPack_min'] = signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, colname_current].min(axis=0)

df_ptemp.loc[1, 'impPackBoL'] = signal_df.loc[index_beforecycle, m_id+'_InitImpedance_Act_mohm']
df_ptemp.loc[1, 'sohrPackCAN_init'] = signal_df.loc[index_beforecycle, m_id+'_Sohr_Est_perc']
df_ptemp.loc[1, 'sohrPackCAN_min'] = signal_df.loc[:, m_id+'_Sohr_Est_perc'].min(axis=0)
df_ptemp.loc[1, 'sohrPackCAN_max'] = signal_df.loc[:, m_id+'_Sohr_Est_perc'].max(axis=0)

# Compute min and max temperatures among all readings
tempsensorlist = [update_name('BATT_tModule' + str(sensor).zfill(1) +"_@", num_mods) for sensor in range(1, 6+1)]

df_ptemp.loc[1, 'tempPackMax_init'] = signal_df.loc[index_tester_cyclebegin, tempsensorlist].max(axis=0)
df_ptemp.loc[1, 'tempPackMax_min'] = signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, tempsensorlist].min(axis=1).min(axis=0)
df_ptemp.loc[1, 'tempPackMax_max'] = signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, tempsensorlist].max(axis=1).max(axis=0)
df_ptemp.loc[1, 'tempPackDelta_max'] = (signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, tempsensorlist].max(axis=1) \
                                        - signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, tempsensorlist].min(axis=1)).max(axis=0)
df_ptemp.loc[1, 'tempPackMax_cycleEnd'] = signal_df.loc[index_tester_cycleend, tempsensorlist].max(axis=0)
df_ptemp.loc[1, 'tempPackMax_avg'] = signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, tempsensorlist].mean(axis=1).mean(axis=0)
df_ptemp.loc[1, 'tempPackMax_rested'] = signal_df.loc[index_tester_rested, tempsensorlist].max(axis=0)

df_ptemp.loc[1, 'roctPack_max'] = signal_df.loc[index_tester_cyclebegin:index_tester_cycleend, m_id+'_roctPerMin_Act_degC'].max(axis=0)

df_ptemp.loc[1, 'tempFET_init'] = signal_df.loc[index_tester_cyclebegin, update_name('BATT_tFET_@', num_mods)]
df_ptemp.loc[1, 'tempFET_max'] = signal_df[update_name('BATT_tFET_@', num_mods)].max()
df_ptemp.loc[1, 'tempPCB_init'] = signal_df.loc[index_beforecycle, update_name('BATT_tAmbient_@', num_mods)]
df_ptemp.loc[1, 'tempPCB_max'] = signal_df[update_name('BATT_tAmbient_@', num_mods)].max()

if PACK_IN_CCDISCH:
    # Discharge current is negative by convention
    threshold_disch_curr = signal_df.loc[index_can_cyclebegin + pd.Timedelta('1S'), colname_current] + 0.1
    index_fullcurrdischend = index_tester_cycleend
    for index in signal_df.index[1:len(signal_df)-1]:
        if (strip(signal_df.loc[index, colname_current]) < threshold_disch_curr) \
            and (strip(signal_df.loc[index + pd.Timedelta('1s'), colname_current]) > threshold_disch_curr):
            index_fullcurrdischend = index
            
    # Derate start SoC and temperature
    df_ptime.loc[1, 'dchMinutesDerated'] = (index_tester_cycleend - index_fullcurrdischend).total_seconds()/60
    
    df_psohc.loc[1, 'dchAhFullCurr'] = -(signal_df.loc[index_fullcurrdischend, colname_totalcapacity] \
                                         - signal_df.loc[index_tester_cyclebegin, colname_totalcapacity])
    df_psohc.loc[1, 'dchAhDerated'] = -(signal_df.loc[index_tester_cycleend, colname_totalcapacity] \
                                        - signal_df.loc[index_fullcurrdischend + pd.Timedelta('1s'), colname_totalcapacity])
    
    df_psoe.loc[1, 'dchkWhFullCurr'] = -(signal_df.loc[index_fullcurrdischend, colname_energy] \
                                         - signal_df.loc[index_tester_cyclebegin, colname_energy])
    df_psoe.loc[1, 'dchkWhDerated'] = -(signal_df.loc[index_tester_cycleend, colname_energy] \
                                        - signal_df.loc[index_fullcurrdischend + pd.Timedelta('1s'), colname_energy])
    
    df_psoc.loc[1, 'dchSocDerate'] = signal_df.loc[index_fullcurrdischend, m_id+'_Soc_Est_perc']
    
    tempsensorlist = [update_name('BATT_tModule' + str(sensor).zfill(1) +"_@", num_mods) for sensor in range(1, 6+1)]
    df_ptemp.loc[1, 'dchTempDerate'] = signal_df.loc[index_fullcurrdischend, tempsensorlist].max(axis=0)

else:
    df_ptime.loc[1, 'dchMinutesDerated'] = 'NA'
    
    df_psohc.loc[1, 'dchAhFullCurr'] = 'NA'
    df_psohc.loc[1, 'dchAhDerated'] = 'NA'
    
    df_psoe.loc[1, 'dchkWhFullCurr'] = 'NA'
    df_psoe.loc[1, 'dchkWhDerated'] = 'NA'
    
    df_psoc.loc[1, 'dchSocDerate'] = 'NA'
    
    df_ptemp.loc[1, 'dchTempDerate'] = 'NA'


df_psohc.loc[1, 'effCoul'] = ' '     # To be computed in the excel sheet
df_psohc.loc[1, 'accChgAhCAN_end'] = signal_df.loc[index_tester_rested, update_name('BATT_ahChgTotal_@', num_mods)]
df_psohc.loc[1, 'accDchAhCAN_end'] = signal_df.loc[index_tester_rested, update_name('BATT_ahDchTotal_@', num_mods)]
df_psoe.loc[1, 'effEner'] = ' '     # To be computed in the excel sheet
df_psoe.loc[1, 'accChgkWhCAN_end'] = signal_df.loc[index_tester_rested, m_id+'_AccChgEnergy_Est_kWh']
df_psoe.loc[1, 'accDchkWhCAN_end'] = signal_df.loc[index_tester_rested, m_id+'_AccDchgEnergy_Est_kWh']

# Populate cell level metrics
for brick in range(1, 14+1):
    df_csoc.loc[1, 'voltCell_init_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'voltCell_init']
    df_csoc.loc[1, 'voltCell_cycleEnd_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'voltCell_cycleEnd']
    df_csoc.loc[1, 'voltCell_rested_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'voltCell_rested']
    df_csoc.loc[1, 'socCellOCV_init_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'socCellOCV_init']
    df_csoc.loc[1, 'socCellCAN_init_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'socCellCAN_init']
    df_csoc.loc[1, 'socCellCAN_cycleEnd_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'socCellCAN_cycleEnd']
    df_csoc.loc[1, 'socCellOCV_cycleEnd_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'socCellOCV_cycleEnd']
    df_csoc.loc[1, 'socCellCAN_corrected_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'socCellCAN_corrected']

    df_csohc.loc[1, 'AhCellCAN_init_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'AhCellCAN_init']
    # df_csohc.loc[1, 'AhCellCAN_end_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'AhCellCAN_end']
    df_csohc.loc[1, 'AhCellEst_CANCurr_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'AhCellEst_CANCurr']
    df_csohc.loc[1, 'AhCellEst_tester_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'AhCellEst_tester']
    df_csohc.loc[1, 'WhCellCycle_CANCurr_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'WhCellCycle']

    df_cbal.loc[1, 'balMinutesCell_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'balMinutesCell']
    df_cbal.loc[1, 'balAhCell_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'balAhCell']
    df_cbal.loc[1, 'balWhCell_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'balWhCell']
    df_cbal.loc[1, 'balCoulDiffCellCANSoc_init_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'balCoulDiffCellCANSoc_init']
    df_cbal.loc[1, 'balCoulDiffCellOCVSoc_init_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'balCoulDiffCellOCVSoc_init']
    df_cbal.loc[1, 'balCoulDiffCellCANSoc_cycleEnd' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'balCoulDiffCellCANSoc_cycleEnd']
    df_cbal.loc[1, 'balCoulDiffCellCANSoc_corrected_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'balCoulDiffCellCANSoc_corrected']
    #df_cbal.loc[1, 'balCoulDiffCellOCVSoc_cycleEnd_c' + str(brick).zfill(2)] = ''

    df_ctemp.loc[1, 'resCellCAN_init_c' + str(brick).zfill(2)] = signal_df.loc[index_beforecycle, update_name('BATT_resBrick' + str(brick).zfill(2)+"_@",num_mods)]
    df_ctemp.loc[1, 'resCellCAN_min_c' + str(brick).zfill(2)] = signal_df.loc[:, update_name('BATT_resBrick' + str(brick).zfill(2)+"_@",num_mods)].min(axis=0)
    df_ctemp.loc[1, 'resCellCAN_max_c' + str(brick).zfill(2)] = signal_df.loc[:, update_name('BATT_resBrick' + str(brick).zfill(2)+"_@",num_mods)].max(axis=0)
    df_ctemp.loc[1, 'resCellCAN_avg_c' + str(brick).zfill(2)] = signal_df.loc[:, update_name('BATT_resBrick' + str(brick).zfill(2)+"_@",num_mods)].mean(axis=0)

    df_ctemp.loc[1, 'tempCellEst_init_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'tempCellEst_init']
    df_ctemp.loc[1, 'tempCellEst_min_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'tempCellEst_min']
    df_ctemp.loc[1, 'tempCellEst_max_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'tempCellEst_max']
    df_ctemp.loc[1, 'tempCellEst_cycleEnd_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'tempCellEst_cycleEnd']
    df_ctemp.loc[1, 'tempCellEst_avg_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'tempCellEst_avg']
    df_ctemp.loc[1, 'tempCellEst_rested_c' + str(brick).zfill(2)] = soccheck_df.loc[brick, 'tempCellEst_rested']

# packmetrics_df.to_excel('key_metrics2.xlsx', sheet_name = 'Sheet1', startrow = 2, startcol = 2, header = True)

book = load_workbook('BatteryPack_CycleLife_TestSummary.xlsx')
writer = pd.ExcelWriter('BatteryPack_CycleLife_TestSummary.xlsx', engine='openpyxl')
writer.book = book
writer.sheets = {ws.title: ws for ws in book.worksheets}

HEADER_WR = False

df_hist.to_excel(
    writer, 
    sheet_name='PackHistory', startrow=writer.sheets['PackHistory'].max_row, 
    index = False, header = HEADER_WR)

df_hist[['test#']].join(df_psoc.join(df_ptime).join(df_pbal)).to_excel(
    writer, 
    sheet_name='PackSoC', startrow=writer.sheets['PackSoC'].max_row, 
    index = False, header = HEADER_WR)

df_hist[['test#']].join(df_psohc).to_excel(
    writer, 
    sheet_name='PackSoHC', startrow=writer.sheets['PackSoHC'].max_row, 
    index = False, header = HEADER_WR)

df_hist[['test#']].join(df_psoe).to_excel(
    writer, 
    sheet_name='PackSoE', startrow=writer.sheets['PackSoE'].max_row, 
    index = False, header = HEADER_WR)

df_hist[['test#']].join(df_ptemp).to_excel(
    writer, 
    sheet_name='PackTemp', startrow=writer.sheets['PackTemp'].max_row, 
    index = False, header = HEADER_WR)

templist = ['voltCell_init_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['voltCell_cycleEnd_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['voltCell_rested_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['socCellOCV_init_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['socCellCAN_init_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['socCellCAN_cycleEnd_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['socCellOCV_cycleEnd_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['socCellCAN_corrected_c' + str(brick).zfill(2) for brick in range(1, 14+1)]
df_hist[['test#']].join(df_csoc[templist]).transpose().to_excel(
    writer, 
    sheet_name='CellSoC', 
    startrow=writer.sheets['CellSoC'].min_row-1, 
    startcol=writer.sheets['CellSoC'].max_column, 
    index = HEADER_WR, header = False)

templist = ['AhCellCAN_init_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['AhCellEst_CANCurr_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['AhCellEst_tester_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['WhCellCycle_CANCurr_c' + str(brick).zfill(2) for brick in range(1, 14+1)]
df_hist[['test#']].join(df_csohc[templist]).transpose().to_excel(
    writer, 
    sheet_name='CellSoHC', 
    startrow=writer.sheets['CellSoHC'].min_row-1, 
    startcol=writer.sheets['CellSoHC'].max_column, 
    index = HEADER_WR, header = False)

templist = ['balMinutesCell_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['balAhCell_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['balWhCell_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['balCoulDiffCellCANSoc_init_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['balCoulDiffCellOCVSoc_init_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['balCoulDiffCellCANSoc_cycleEnd' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['balCoulDiffCellCANSoc_corrected_c' + str(brick).zfill(2) for brick in range(1, 14+1)]
df_hist[['test#']].join(df_cbal[templist]).transpose().to_excel(
    writer, 
    sheet_name='CellBal', 
    startrow=writer.sheets['CellBal'].min_row-1, 
    startcol=writer.sheets['CellBal'].max_column, 
    index = HEADER_WR, header = False)

templist = ['resCellCAN_init_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['resCellCAN_min_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['resCellCAN_max_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['resCellCAN_avg_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['tempCellEst_init_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['tempCellEst_min_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['tempCellEst_max_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['tempCellEst_cycleEnd_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['tempCellEst_avg_c' + str(brick).zfill(2) for brick in range(1, 14+1)] + \
           ['tempCellEst_rested_c' + str(brick).zfill(2) for brick in range(1, 14+1)]
df_hist[['test#']].join(df_ctemp[templist]).transpose().to_excel(
    writer, 
    sheet_name='CellTemp', 
    startrow=writer.sheets['CellTemp'].min_row-1, 
    startcol=writer.sheets['CellTemp'].max_column, 
    index = HEADER_WR, header = False)

#%% Plot of brick SoCs and pack SoC
print("Plotting SoC comparison ...")
import plot_soccomp

bricklist = [update_name('BATT_socBrick' + str(brick).zfill(2)+"_@",num_mods) for brick in range(1, 14+1)]

plot_soccomp.plot_socs(
    time_secs = signal_df['time_sec_can'], \
    can_packvolt = signal_df.loc[:, 'ESS_BM1_Voltage_Act_V'], \
    bricksocs = signal_df[bricklist], \
    can_packsoc = pad(signal_df.loc[:, 'ESS_BM1_Soc_Est_perc']), \
    soctrim_min = (signal_df.loc[:,  BATT_soc_trim_min_label]) if SOC_TRIM else None, \
    soctrim_max = (signal_df.loc[:, BATT_soc_trim_max_label]) if SOC_TRIM else None, \
    trimmed_packsoc = (signal_df.loc[:, 'PackSoC_Trimmed'] if SOC_TRIM else None), \
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )
    
#%% Check estimated SoC against that calculated from CAN reported pack current and battery tester current
print("Plotting Ah comparison ...")
bricklist = [update_name('BATT_socBrick' + str(brick).zfill(2)+"_@",num_mods) for brick in range(1, 14+1)]

plot_soccomp.plot_compsoc(
    time_secs = signal_df['time_sec_can'], \
    bricksocs = signal_df[bricklist], \
    init_ocvsocs = soccheck_df.loc[:, 'socCellOCV_init'], \
    init_cellcaps = soccheck_df.loc[:, 'AhCellCAN_init'], \
    can_ah = signal_df['cum_Ah_can'], \
    tester_ah = signal_df[colname_totalcapacity] if TSTR_PR else None, \
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )

#%% Check estimated SoC against that calculated from CAN reported pack current and battery tester current
import plot_RemainingCHGtime

if PACK_IN_CHARGE:
    print("Plotting Charge Time validation ...")
    #bricklist = [update_name('BATT_socBrick' + str(brick).zfill(2)+"_@",num_mods) for brick in range(1, 14+1)]
    print(signal_df.loc[:,"ESS_BM1_ChgRemainingTime_Est_min"].head(20)) 
    plot_RemainingCHGtime.plot_remChgTime(
        time_secs = signal_df['time_sec_can'], \
        can_remChgTime = signal_df.loc[:,"ESS_BM1_ChgRemainingTime_Est_min"], \
        actual_chgComplete = signal_df.loc[:,"ESS_BM1_ChgMode_St_enum"], \
        can_soc = pad(signal_df.loc[:, 'ESS_BM1_Soc_Est_perc']), \
        savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix ) 
    
#%% Check estimated SoE against actual energy available
print("Plotting capacity and energy comparison ...")
import plot_energyavl   

plot_energyavl.plot_capavl(
    time_secs = signal_df['time_sec_can'],
    can_fullchgcap = signal_df['ESS_BMS_CapFulCharge_Est_Ah'],
    can_capavl = signal_df['ESS_BMS_CapAvailable_Est_Ah'],
    can_soc = signal_df.loc[:, 'ESS_BM1_Soc_Est_perc'],
    tester_Ah = signal_df[colname_totalcapacity],
    index_cycleend = index_tester_cycleend,
    can_packcurrent = signal_df['ESS_BM1_iMod_Act_A'],
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )
  
plot_energyavl.plot_energyavl(
    time_secs = signal_df['time_sec_can'],
    can_fullchgenergy = signal_df['ESS_BM1_EnergyFulCharge_Est_kWh'],
    can_energyavl = signal_df['ESS_BM1_EnergyAvailable_Est_kWh'],
    can_soe = signal_df['ESS_BM1_Soe_Est_perc'],
    tester_kwh = signal_df[colname_energy],
    index_cycleend = index_tester_cycleend,
    can_packvolt = pad(signal_df['ESS_BM1_Voltage_Act_V']),
    can_packcurrent = signal_df['ESS_BM1_iMod_Act_A'],
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )

#%% Plot estimated cell capacities
print("Plotting cell capacities ...")
import plot_cellparams

bricklist = [update_name('BATT_capBrick' + str(brick).zfill(2)+"_@",num_mods) for brick in range(1, 14+1)]

plot_cellparams.plot_cellcap(
    time_secs = signal_df['time_sec_can'], \
    brickcaps = signal_df[bricklist], \
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix )

#%% Plot estimated cell resistances
print("Plotting cell DCR ...")
bricklist = [update_name('BATT_resBrick' + str(brick).zfill(2)+"_@",num_mods) for brick in range(1, 14+1)]
bricksoclist = [update_name('BATT_socBrick' + str(brick).zfill(2)+"_@",num_mods) for brick in range(1, 14+1)]
bricktemplist = [update_name('BATT_tBrick' + str(brick).zfill(2)+"_@", num_mods) for brick in range(1, 14+1)]   
          
plot_cellparams.plot_celldcr(
    r0_at_soc, \
    bricksoc = signal_df[bricksoclist], \
    bricktemp = signal_df[bricktemplist], \
    time_secs = signal_df['time_sec_can'], \
    brickres = signal_df[bricklist], \
    can_packsoc = pad(signal_df.loc[:, 'ESS_BM1_Soc_Est_perc']), \
    packtemp = pad(signal_df.loc[:, update_name('BATT_tModule1'+"_@",num_mods)]), \
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix)
    
print("Plotting cell impedance ...")
bricklist = [update_name('BATT_sohrBrick' + str(brick).zfill(2)+"_@",num_mods) for brick in range(1, 14+1)]

plot_cellparams.plot_cellimpedance(
    #r1_at_soc, \
    time_secs = signal_df['time_sec_can'], \
    brickres = signal_df[bricklist], \
    init_packimp = pad(signal_df['ESS_BM1_InitImpedance_Act_mohm']), \
    packimp = pad(signal_df['ESS_BM1_CurrImpedance_Act_mohm']), \
    can_packsoc = pad(signal_df.loc[:, 'ESS_BM1_Soc_Est_perc']), \
    packtemp = pad(signal_df.loc[:, update_name('BATT_tModule1'+"_@",num_mods)]), \
    savefig = True, fig_dir = fig_dir, fname_prefix = fname_prefix)

# Check resistance from BM1 Health and BM1 SoX
#['ESS_BM1_EnergyFulCharge_Est_kWh', 'ESS_BM1_CapFulCharge_Est_Ah', 'ESS_BM1_InitImpedance_Act_mohm', 'ESS_BM1_CurrImpedance_Act_mohm', 'ESS_BM1_ChgCycle_Act_count']

#%% Diagnostics measurements on the FETs
print("Plotting FET diagnostic measurements ...")
with mpl.rc_context(fname='RA_BMS.rc'):
    fetdiagfig, fetdiagfig_currax = plt.subplots(num = 'FET current measurement')
    fetdiagfig_currax.plot(time_hrs, signal_df.loc[:, update_name('BATT_fetChgDiagIMeas'+"_@",num_mods)], label = "ChgFET DiagI")
    fetdiagfig_currax.plot(time_hrs, signal_df.loc[:, update_name('BATT_fetDsgDiagIMeas'+"_@",num_mods)], label = "DsgFET DiagI")
    #fetdiagfig_currax.plot(time_hrs, (signal_df.loc[:, 'BATT_fetChgDiagVMeasPrime'] - signal_df.loc[:, 'BATT_fetChgDiagVMeas'])/signal_df.loc[:, 'BATT_fetChgDiagIMeas'], label = "ChgFET I Comp")

    fetdiagfig_currax.set_xlabel("Time (sec)")
    fetdiagfig_currax.set_ylabel("Current (A)")

with mpl.rc_context(rcdict02):
    fetdiagfig_voltax = fetdiagfig_currax.twinx()
    fetdiagfig_voltax.plot(time_hrs, signal_df.loc[:, update_name('BATT_fetChgDiagVMeas'+"_@",num_mods)], label = "ChgFET DiagV")
    fetdiagfig_voltax.plot(time_hrs, signal_df.loc[:, update_name('BATT_fetChgDiagVMeasPrime'+"_@",num_mods)], label = "ChgFET DiagVPrime")
    fetdiagfig_voltax.plot(time_hrs, signal_df.loc[:, update_name('BATT_fetDsgDiagVMeas'+"_@",num_mods)], label = "DsgFET DiagV")
    fetdiagfig_voltax.plot(time_hrs, signal_df.loc[:, update_name('BATT_fetDsgDiagVMeasPrime'+"_@",num_mods)], label = "DsgFET DiagVPrime")
    fetdiagfig_voltax.set_ylabel("Voltage (V)")

plt.xlim((min(time_hrs), max(time_hrs)))
fetdiagfig_currax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)
lines, labels = fetdiagfig_currax.get_legend_handles_labels()
lines2, labels2 = fetdiagfig_voltax.get_legend_handles_labels()
fetdiagfig_currax.legend(lines + lines2, labels + labels2)
plt.title("FET Diagnostic Measurements")
fetdiagfig.set_size_inches(16, 12)
plt.show()
fetdiagfig.savefig(os.path.join(fig_dir, fname_prefix + '_FET_Diags.png'),
        format='png',
        dpi=400,
        bbox_inches='tight')

#%% Raw voltage measurements from the ADC
#TODO
print("Plotting ADC raw measurements ...")
with mpl.rc_context(fname='RA_BMS.rc'):
    adcmeasfig, adcmeasfig_voltax = plt.subplots(num = 'Raw ADC Measurements')
    adcmeasfig_voltax.plot(time_hrs, signal_df.loc[:, update_name('BATT_boardADC_PACK'+"_@",num_mods)], label = "Pack")
    adcmeasfig_voltax.plot(time_hrs, signal_df.loc[:, update_name('BATT_boardADC_COMMON_DRAIN'+"_@",num_mods)], label = "Common Drain")
    adcmeasfig_voltax.plot(time_hrs, signal_df.loc[:, update_name('BATT_boardADC_LOAD'+"_@",num_mods)], label = "Load")
    adcmeasfig_voltax.plot(time_hrs, signal_df.loc[:, update_name('BATT_boardADC_PACK_PF'+"_@",num_mods)], label = "Pack PF")
    adcmeasfig_voltax.set_xlabel("Time (sec)")
    adcmeasfig_voltax.set_ylabel("Voltage (V)")

plt.xlim((min(time_hrs), max(time_hrs)))
adcmeasfig_voltax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)
lines, labels = adcmeasfig_voltax.get_legend_handles_labels()
adcmeasfig_voltax.legend(lines, labels)
plt.title("ADC Raw Measurements")
adcmeasfig.set_size_inches(16, 12)
plt.show()
adcmeasfig.savefig(os.path.join(fig_dir, fname_prefix + '_ADC_Raw.png'),
        format='png',
        dpi=400,
        bbox_inches='tight')


#plt.close('all')
writer.save()
writer.close()

print("CAN_log reader completed process")
write_error("Completed Processing %d" %testid)

