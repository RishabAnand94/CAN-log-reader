# -*- coding: utf-8 -*-
"""
Created on Fri Feb 19 17:01:10 2021

@author: ranand
"""

import sys
if 'mpl' not in sys.modules:
    import matplotlib as mpl 
if 'plt' not in sys.modules:
    import matplotlib.pyplot as plt
# if 'os' not in sys.modules:
#     import os

import os

import scipy.integrate
import numpy as np

rcdict02 = {'ytick.labelsize': 14, 'axes.labelsize': 14}

def plot_capavl(
    time_secs,
    can_fullchgcap,
    can_capavl,
    can_soc,
    tester_Ah,
    index_cycleend,
    can_packcurrent,
    savefig = False, fig_dir = '', fname_prefix = '' ):
    
    time_hrs = [tsec/3600 for tsec in time_secs]

    with mpl.rc_context(fname='RA_BMS.rc'):
        avlcapfig, avlcapfig_capax = plt.subplots(num = 'Capacity_Available')
        
        avlcapfig_capax.plot(
            time_hrs, 
            can_fullchgcap, 
            label = "Full Charge Capacity")
        
        avlcapfig_capax.plot(
            time_hrs, 
            can_capavl, 
            label = "Available Capacity - CAN")
#        print("----->\n",index_rested,can_energyavl[index_rested],tester_kwh[index_rested],"\n")
#        print("\n",tester_kwh,"\n")
        avlcapfig_capax.plot(
            time_hrs, 
            can_capavl[index_cycleend] + tester_Ah - tester_Ah[index_cycleend], 
            label = "Ah added - tester")
        plt.autoscale(axis = 'y', tight = None)
        
        # can_kwh = abs(scipy.integrate.cumtrapz([a*b/1000 for a,b in zip(can_packvolt, can_packcurrent)], x = time_secs)/3600)
        # can_kwh = np.append(can_kwh, can_kwh[-1])
        # avlenergyfig_enerax.plot(
        #     time_hrs, 
        #     can_energyavl[index_cycleend] + can_kwh - can_kwh[index_cycleend], 
        #     label = "Energy added - CAN")
        
        plt.autoscale(axis = 'y', tight = None)
        
        avlcapfig_capax.set_xlabel('Time (hours)')
        avlcapfig_capax.set_ylabel('Capacity (Ah)')
        
    with mpl.rc_context(rcdict02):
        socax = avlcapfig_capax.twinx()
        socax.spines["left"].set_position(("axes", -0.07))
        socax.spines["left"].set_visible(True)
        socax.yaxis.set_label_position('left')
        socax.yaxis.set_ticks_position('left')
        socax.plot(
            time_hrs, 
            can_soc, 
            label = 'SoC')
        
        socax.set_ylabel("SoC (%)")
        socax.grid(None)
        
        errorax = avlcapfig_capax.twinx()   
        errorax.plot(
            time_hrs, 
            can_capavl[index_cycleend] + tester_Ah - tester_Ah[index_cycleend] - can_capavl, label = "Est. Error")

        errorax.set_ylabel("Estimation Error (Ah)")
        errorax.grid(None)


    with mpl.rc_context(fname='RA_BMS.rc'):
        lines, labels = avlcapfig_capax.get_legend_handles_labels()
        lines2, labels2 = errorax.get_legend_handles_labels()
        avlcapfig_capax.legend(lines + lines2, labels + labels2)

    plt.xlim(min(time_hrs), max(time_hrs))
    avlcapfig_capax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)

    plt.title("Pack Available Capacity")
    avlcapfig.set_size_inches(16, 12)
    plt.show()

    if savefig:
        avlcapfig.savefig(
            os.path.join(fig_dir, fname_prefix + '_Capacity_Available.png'),
            format='png',
            dpi=400,
            bbox_inches='tight') 

def plot_energyavl(
    time_secs,
    can_fullchgenergy,
    can_energyavl, 
    can_soe,
    tester_kwh,
    index_cycleend,
    can_packvolt, 
    can_packcurrent,
    savefig = False, fig_dir = '', fname_prefix = '' ):
    
    time_hrs = [tsec/3600 for tsec in time_secs]

    with mpl.rc_context(fname='RA_BMS.rc'):
        avlenergyfig, avlenergyfig_enerax = plt.subplots(num = 'Energy_Available')
        
        avlenergyfig_enerax.plot(
            time_hrs, 
            can_fullchgenergy, 
            label = "Full Charge Energy")
        
        avlenergyfig_enerax.plot(
            time_hrs, 
            can_energyavl, 
            label = "Available Energy - CAN")
#        print("----->\n",index_rested,can_energyavl[index_rested],tester_kwh[index_rested],"\n")
#        print("\n",tester_kwh,"\n")
        avlenergyfig_enerax.plot(
            time_hrs, 
            can_energyavl[index_cycleend] + tester_kwh - tester_kwh[index_cycleend], 
            label = "Energy added - tester")
        plt.autoscale(axis = 'y', tight = None)
        
        # can_kwh = abs(scipy.integrate.cumtrapz([a*b/1000 for a,b in zip(can_packvolt, can_packcurrent)], x = time_secs)/3600)
        # can_kwh = np.append(can_kwh, can_kwh[-1])
        # avlenergyfig_enerax.plot(
        #     time_hrs, 
        #     can_energyavl[index_cycleend] + can_kwh - can_kwh[index_cycleend], 
        #     label = "Energy added - CAN")
        
        plt.autoscale(axis = 'y', tight = None)
        
        avlenergyfig_enerax.set_xlabel('Time (hours)')
        avlenergyfig_enerax.set_ylabel('Energy (kWh)')
        
    with mpl.rc_context(rcdict02):
        soeax = avlenergyfig_enerax.twinx()
        soeax.spines["left"].set_position(("axes", -0.07))
        soeax.spines["left"].set_visible(True)
        soeax.yaxis.set_label_position('left')
        soeax.yaxis.set_ticks_position('left')
        soeax.plot(
            time_hrs, 
            can_soe, 
            label = 'SoE')
        
        soeax.set_ylabel("SoE (%)")
        soeax.grid(None)
        
        errorax = avlenergyfig_enerax.twinx()   
        errorax.plot(
            time_hrs, 
            can_energyavl[index_cycleend] + tester_kwh - tester_kwh[index_cycleend] - can_energyavl, 
            label = "Est. Error")

        errorax.set_ylabel("Estimation Error (kWh)")
        errorax.grid(None)
        
    # with mpl.rc_context(rcdict02):
    #     packvoltfig_currentax = packvoltfig_voltax.twinx()
    #     if tester_current is not None:
    #         packvoltfig_currentax.plot(
    #             time_hrs, 
    #             tester_current, 
    #             label = "Pack Current - Tester")
        
    #     packvoltfig_currentax.plot(
    #         time_hrs, 
    #         can_packcurrent, 
    #         label = "Pack Current - CAN", 
    #         color = 'black')
        
    #     packvoltfig_currentax.set_ylabel("Pack Current (A)")
    #     packvoltfig_currentax.grid(None)

        # if index_cyclebegin is not None:
        #     plt.axvline(time_secs[index_cyclebegin]/3600)   # ymin = 2.5*14, ymax = 4.2*14
        #     # text(index_tester_cyclebegin, 20, 'Cycle Start', rotation=90, verticalalignment='center')
        # if index_cycleend is not None:
        #     plt.axvline(time_secs[index_cycleend]/3600)
        #     # text(index_tester_cycleend, 20, 'Cycle End', rotation=90, verticalalignment='center')
        # if index_rv_postcycle is not None:
        #     plt.axvline(time_secs[index_rv_postcycle]/3600)

    with mpl.rc_context(fname='RA_BMS.rc'):
        lines, labels = avlenergyfig_enerax.get_legend_handles_labels()
        lines2, labels2 = errorax.get_legend_handles_labels()
        lines3, labels3 = soeax.get_legend_handles_labels()
        avlenergyfig_enerax.legend(lines + lines2 + lines3, labels + labels2 + labels3)

    plt.xlim(min(time_hrs), max(time_hrs))
    avlenergyfig_enerax.tick_params(which = 'minor', grid_linestyle = ':', grid_alpha = 0.8)

    plt.title("Pack Available Energy")
    avlenergyfig.set_size_inches(16, 12)
    plt.show()

    if savefig:
        avlenergyfig.savefig(
            os.path.join(fig_dir, fname_prefix + '_Energy_Available.png'),
            format='png',
            dpi=400,
            bbox_inches='tight') 