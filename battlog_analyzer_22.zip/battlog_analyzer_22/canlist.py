# -*- coding: utf-8 -*-
"""
Created on Tue Jun 29 09:52:53 2021

@author: jma / ranand
"""

import copy
import pandas as pd
import os 

#%%
def update_name(name, mod_id):
    """
    Accepts a single signal name template and modifies it according to the module number

    Parameters
    ----------
    name : CAN signal name
    mod_id : module ID within multi-pack configuration
    
    Returns
    -------
    name : instanced CAN signal name
    
    """
    if mod_id == 0: # Expected modules is zero or the signal does not exist - only single pack connected
        if name[-2:] =="_@":
            name = name[:-2]    # No instances in diagnostics messages
        mod_id = 1
    
    name = name.replace("*",str(mod_id))
    name = name.replace("@",str(mod_id-1))
    return name

#%%
def update_list_names(items,num_mods):
    """
    Update list of CAN signals in template

    Parameters
    ----------
    items : list; List of CAN signal name templates.
    num_mods : TYPE; Number of modules in pack.

    Returns
    -------
    items_seg : list; list of instanced CAN signals.

    """
    items_seg = []
    if num_mods == 0:
        items_seg = [update_name(item,mod_id = num_mods) for item in items] 
    else:
        for id_ in range(1,num_mods+1):
            items_seg = items_seg + [update_name(item,mod_id = id_) for item in items] 
    return items_seg

#%%
def get_sig(sig_list_template, mod_id):
    
    print("Generating signal list for battery module number %d.." %mod_id)
    sig_list_copy = copy.deepcopy(sig_list_template)
    key_list =[]
    val_list = []
    
    for message in sig_list_copy.keys():
        key_list.append(update_name(message, mod_id))
        temp= []
        for signal in sig_list_copy[message]:
            temp.append(update_name(signal, mod_id))    
        val_list.append(temp)
    
    sig_list_copy  = {k:v for k,v in zip(key_list,val_list)}      
                
    print("Signal list for battery module number %d generated." %mod_id)
    return sig_list_copy

#%%
def get_signal_list_aggr(
        candb_filename,
        diagdb_filename):
    print("executing function get_signal_list_aggr...")
    input_file = pd.ExcelFile(os.getcwd()+r"\lookup\Signal_list_new.xlsx")
    df_aggr = input_file.parse("Signal_aggr")
    df_aggr = df_aggr[df_aggr["Selection"]==1]
    df_aggr = df_aggr[["Message","Signal"]]
    df_aggr=df_aggr.set_index("Message")
    signal_aggr_dict = {}
    for i in range(len(df_aggr)):
        signal_aggr_dict[df_aggr.iloc[i].name] =  df_aggr.iloc[i][0].split("\n")
    
        
    if candb_filename in ["dbc_BMS_v0.3.0.dbc", "dbc_BMS_v0.3.2.dbc"]:
        
            signal_aggr_dict['VCU_Command_BMS'].append('ETS_VCU_VCUMaxChrgSOC_Ref_enum')
            signal_aggr_dict['BMS_Health'].append('ESS_BMS_PcbTempAmbient_Act_degC')
    
    elif candb_filename in ["dbc_BAL_BMS_v0.4.6.dbc"]:

            signal_aggr_dict['VCU_Command_BMS'].append('ETS_VCU_UsrDfMaxChrgSOC_Ref_enum')
            signal_aggr_dict['BMS_Health'].append('ESS_BMS_PcbTemp_Act_degC')
        
    
    
    if candb_filename in ["dbc_BMS_v0.3.0.dbc", "dbc_BMS_v0.3.2.dbc","dbc_BAL_BMS_v0.4.6.dbc"]: 
            signal_aggr_dict['BMS_Discharge'] =  ['ESS_BMS_DchgLimit_Max_V',
                                                          'ESS_BMS_DchgLimitCont_Max_A',
                                                          'ESS_BMS_DchgLimit10sec_Max_A']
    else:
        
             signal_aggr_dict['BMS_Discharge'] = ['ESS_BMS_DchgLimit_Min_V',
                                                          'ESS_BMS_DchgLimitCont_Max_A',
                                                          'ESS_BMS_DchgLimit10sec_Max_A']
        
    return signal_aggr_dict

#%%
def get_signal_list(
        candb_filename,
        diagdb_filename,
        mod_num = 1):
    print("Executing function get_signal_list...")
    
    input_file = pd.ExcelFile(os.getcwd()+r"\lookup\Signal_list_new.xlsx")
    df_temp = input_file.parse("Signal_template")   # Read signal template sheet
    df_temp = df_temp[df_temp["Selection"]==1]      # Only keep selected signals
    df_temp = df_temp[["Message","Signal"]]         # Remove selection column
    df_temp = df_temp.set_index("Message")

    signal_temp_dict ={}
    for i in range(len(df_temp)):
        # Each signal contained in a new line
        signal_temp_dict[df_temp.iloc[i].name] =  df_temp.iloc[i][0].split("\n")

    if candb_filename in ["dbc_BMS_v0.3.0.dbc", "dbc_BMS_v0.3.2.dbc"]:
        
            signal_temp_dict['BM*_Health'].append('ESS_BM*_PcbTempAmbient_Act_degC')
    
    elif candb_filename in ["dbc_BAL_BMS_v0.4.6.dbc"]:
        
            signal_temp_dict['BM*_Health'].append('ESS_BM*_PcbTemp_Act_degC')
    
    if diagdb_filename in ["amp_debug_v7.dbc", "amp_debug_v8.dbc", "amp_debug_v9.dbc"]:

            signal_temp_dict['BATT_iLimitInst_@']+= ['BATT_dch_pwr_available_W_@']
            signal_temp_dict['BATT_diagnosticSOCBricksD_@'] +=  ['BATT_soc_trim_max_@',
                                                                    'BATT_soc_trim_min_@']
    if diagdb_filename in ["amp_debug_v11_instanced.dbc"]:
        # Debug dbc V11 additional signals (brick SoHR)
        signal_temp_dict['BATT_diagnosticSOHRBricksA_@']  = ['BATT_sohrBrick01_@', 'BATT_sohrBrick02_@', 'BATT_sohrBrick03_@', 'BATT_sohrBrick04_@']
        signal_temp_dict['BATT_diagnosticSOHRBricksB_@']  = ['BATT_sohrBrick05_@', 'BATT_sohrBrick06_@', 'BATT_sohrBrick07_@', 'BATT_sohrBrick08_@']
        signal_temp_dict['BATT_diagnosticSOHRBricksC_@']  = ['BATT_sohrBrick09_@', 'BATT_sohrBrick10_@', 'BATT_sohrBrick11_@', 'BATT_sohrBrick12_@']
        signal_temp_dict['BATT_diagnosticSOHRBricksD_@']  = ['BATT_sohrBrick13_@', 'BATT_sohrBrick14_@']  
        signal_temp_dict['BATT_diagnosticSOCBricksD_@']   += ['BATT_soc_trim_max_@','BATT_soc_trim_min_@']
        signal_temp_dict['BATT_iLimitInst_@']+= ['BATT_dch_pwr_available_W_@']                   

    if candb_filename in ["dbc_BMS_v0.3.0.dbc", "dbc_BMS_v0.3.2.dbc", "dbc_BAL_BMS_v0.4.6.dbc"]: 
        signal_temp_dict['BM*_Discharge']       = ['ESS_BM*_DchgLimit_Max_V',
                                                          'ESS_BM*_DchgLimitCont_Max_A',
                                                          'ESS_BM*_DchgLimit10sec_Max_A']
    else:
        signal_temp_dict['BM*_Discharge']       = ['ESS_BM*_DchgLimit_Min_V',
                                                          'ESS_BM*_DchgLimitCont_Max_A',
                                                          'ESS_BM*_DchgLimit10sec_Max_A']
    return signal_temp_dict